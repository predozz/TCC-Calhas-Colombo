<?php
// agenda de instalacoes: calendario mensal mostrando as obras com
// data prevista de instalacao. Facilita pro calheiro ver aonde
// precisa ir e pro dono planejar a equipe.
//
// Por que nao usei biblioteca de calendario (FullCalendar etc):
//   - sao pesadas (300kb+)
//   - exigem jQuery ou similar
//   - o que a gente precisa e simples: grid de 7 colunas com
//     os dias do mes e badges por status. CSS Grid resolve.
//
// Regra de visibilidade:
//   - admin e gerente veem tudo
//   - calheiro e campo veem so as instalacoes onde sao responsaveis
//     (mesma logica da listagem de orcamentos)

require_once __DIR__ . '/inclui/auth.php';
exigir_login();

$u = usuario_logado();
$pdo = bd();
$verFinanceiro = pode('ver_financeiro');

// Mes selecionado (GET ?mes=YYYY-MM), padrao = mes atual
$mesParam = $_GET['mes'] ?? date('Y-m');
if (!preg_match('/^\d{4}-\d{2}$/', $mesParam)) {
    $mesParam = date('Y-m');
}

$primeiroDia = $mesParam . '-01';
$ultimoDia   = date('Y-m-t', strtotime($primeiroDia));
$hoje        = date('Y-m-d');

// Navegacao entre meses
$mesAnterior = date('Y-m', strtotime($primeiroDia . ' -1 month'));
$mesProximo  = date('Y-m', strtotime($primeiroDia . ' +1 month'));
$ehMesAtual  = $mesParam === date('Y-m');

// Consulta: instalacoes do mes
$params = [':de' => $primeiroDia, ':ate' => $ultimoDia];
$filtroResp = '';
if (!$verFinanceiro) {
    $filtroResp = ' AND o.responsavel_id = :meu_id';
    $params[':meu_id'] = $u['id'];
}

$st = $pdo->prepare(
    "SELECT o.id, o.numero, o.status, o.valor_total, o.data_entrega_prevista,
            o.tipo_telhado, o.forma_pagamento,
            c.nome AS cliente, c.telefone AS cliente_telefone,
            c.endereco, c.numero AS cliente_numero, c.bairro, c.cidade, c.uf,
            us.nome AS responsavel
     FROM orcamentos o
     JOIN clientes c ON c.id = o.cliente_id
     JOIN usuarios us ON us.id = o.responsavel_id
     WHERE o.data_entrega_prevista BETWEEN :de AND :ate
       AND o.status IN ('aprovado', 'em_producao', 'concluido')
       $filtroResp
     ORDER BY o.data_entrega_prevista ASC, o.id ASC"
);
$st->execute($params);
$instalacoes = $st->fetchAll();

// Agrupa por dia do mes
$porDia = [];
foreach ($instalacoes as $inst) {
    $dia = (int) date('j', strtotime($inst['data_entrega_prevista']));
    if (!isset($porDia[$dia])) {
        $porDia[$dia] = [];
    }
    $porDia[$dia][] = $inst;
}

// Estatisticas do mes
$totalMes = count($instalacoes);
$qtdConcluido = 0;
$qtdProducao = 0;
$qtdAprovado = 0;
$valorTotalMes = 0.0;
foreach ($instalacoes as $inst) {
    if ($inst['status'] === 'concluido')   { $qtdConcluido++; }
    if ($inst['status'] === 'em_producao') { $qtdProducao++; }
    if ($inst['status'] === 'aprovado')    { $qtdAprovado++; }
    $valorTotalMes += (float) $inst['valor_total'];
}

// Estrutura do calendario
$primeiroTs      = strtotime($primeiroDia);
$diasNoMes       = (int) date('t', $primeiroTs);
$diaSemanaInicio = (int) date('w', $primeiroTs); // 0 = domingo, 6 = sabado

// Nome do mes
$mesesNome = [
    1 => 'Janeiro', 2 => 'Fevereiro', 3 => 'Marco', 4 => 'Abril',
    5 => 'Maio', 6 => 'Junho', 7 => 'Julho', 8 => 'Agosto',
    9 => 'Setembro', 10 => 'Outubro', 11 => 'Novembro', 12 => 'Dezembro',
];
$mesNum = (int) date('n', $primeiroTs);
$anoNum = (int) date('Y', $primeiroTs);
$tituloMes = $mesesNome[$mesNum] . ' de ' . $anoNum;

// Cores por status (mesmas usadas no resto do sistema)
$coresStatus = [
    'aprovado'    => 'var(--ambar-500)',
    'em_producao' => 'var(--roxo-600)',
    'concluido'   => 'var(--verde-500)',
];

$titulo_pagina = 'Agenda';
$pagina_ativa  = 'agenda';
require_once __DIR__ . '/inclui/cabecalho.php';
?>

<div class="pagina-topo">
    <div>
        <h1 class="pagina-titulo">Agenda de instalacoes</h1>
        <p class="pagina-subtitulo">
            <?= $totalMes ?> instalacao(oes) em <?= e($tituloMes) ?>
        </p>
    </div>
    <div class="pagina-acoes">
        <button onclick="window.print()" class="botao botao-neutro">Imprimir</button>
    </div>
</div>

<!-- INDICADORES DO MES -->
<?php if ($totalMes > 0): ?>
    <div class="grade-indicadores">
        <div class="indicador ambar">
            <div class="indicador-rotulo">Aguardando inicio</div>
            <div class="indicador-valor"><?= $qtdAprovado ?></div>
            <div class="indicador-nota">Aprovadas, sem producao iniciada</div>
        </div>
        <div class="indicador roxo">
            <div class="indicador-rotulo">Em producao</div>
            <div class="indicador-valor"><?= $qtdProducao ?></div>
            <div class="indicador-nota">Pecas sendo fabricadas</div>
        </div>
        <div class="indicador verde">
            <div class="indicador-rotulo">Concluidas</div>
            <div class="indicador-valor"><?= $qtdConcluido ?></div>
            <div class="indicador-nota">Servicos entregues no mes</div>
        </div>
        <?php if ($verFinanceiro): ?>
            <div class="indicador">
                <div class="indicador-rotulo">Valor do mes</div>
                <div class="indicador-valor" style="font-size:23px"><?= moeda($valorTotalMes) ?></div>
                <div class="indicador-nota">Soma das instalacoes programadas</div>
            </div>
        <?php endif; ?>
    </div>
<?php endif; ?>

<!-- CALENDARIO (escondido na impressao, que mostra so a lista) -->
<div class="cartao nao-imprimir">
    <div class="cartao-cabecalho">
        <div class="flex alinha-centro g3">
            <a href="?mes=<?= e($mesAnterior) ?>" class="botao botao-neutro botao-p"
               title="Mes anterior">&larr;</a>
            <h3 style="min-width:200px;text-align:center"><?= e($tituloMes) ?></h3>
            <a href="?mes=<?= e($mesProximo) ?>" class="botao botao-neutro botao-p"
               title="Proximo mes">&rarr;</a>
        </div>
        <?php if (!$ehMesAtual): ?>
            <a href="agenda.php" class="botao botao-contorno botao-p">Ir para hoje</a>
        <?php endif; ?>
    </div>

    <div class="cartao-corpo" style="padding:var(--s-4)">
        <div class="calendario">
            <!-- Cabecalho dos dias da semana -->
            <div class="calendario-semana">Dom</div>
            <div class="calendario-semana">Seg</div>
            <div class="calendario-semana">Ter</div>
            <div class="calendario-semana">Qua</div>
            <div class="calendario-semana">Qui</div>
            <div class="calendario-semana">Sex</div>
            <div class="calendario-semana">Sab</div>

            <!-- Celulas vazias antes do primeiro dia -->
            <?php for ($i = 0; $i < $diaSemanaInicio; $i++): ?>
                <div class="calendario-celula vazia"></div>
            <?php endfor; ?>

            <!-- Dias do mes -->
            <?php for ($dia = 1; $dia <= $diasNoMes; $dia++): ?>
                <?php
                $dataCompleta = sprintf('%s-%02d', $mesParam, $dia);
                $ehHoje = ($dataCompleta === $hoje);
                $doDia  = $porDia[$dia] ?? [];
                $temInst = !empty($doDia);
                ?>
                <div class="calendario-celula <?= $ehHoje ? 'hoje' : '' ?> <?= $temInst ? 'tem-instalacao' : '' ?>"
                     <?= $temInst ? 'onclick="abrirDia(' . $dia . ')"' : '' ?>
                     <?= $temInst ? 'role="button" tabindex="0" onkeydown="if(event.key===\'Enter\')abrirDia(' . $dia . ')"' : '' ?>>

                    <div class="calendario-dia-numero"><?= $dia ?></div>

                    <?php if ($temInst): ?>
                        <div class="calendario-badges">
                            <?php
                            $cont = 0;
                            foreach ($doDia as $inst):
                                if ($cont >= 3) break;
                                $cor = $coresStatus[$inst['status']] ?? 'var(--texto-suave)';
                            ?>
                                <span class="calendario-badge" style="background:<?= $cor ?>"></span>
                            <?php
                                $cont++;
                            endforeach;
                            if (count($doDia) > 3):
                            ?>
                                <span class="calendario-mais">+<?= count($doDia) - 3 ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="calendario-total"><?= count($doDia) ?></div>
                    <?php endif; ?>
                </div>
            <?php endfor; ?>

            <!-- Celulas vazias depois do ultimo dia -->
            <?php
            $totalCelulas = $diaSemanaInicio + $diasNoMes;
            $restantes = (7 - ($totalCelulas % 7)) % 7;
            for ($i = 0; $i < $restantes; $i++):
            ?>
                <div class="calendario-celula vazia"></div>
            <?php endfor; ?>
        </div>

        <!-- Legenda -->
        <div class="calendario-legenda">
            <span><i style="background:var(--ambar-500)"></i> Aguardando inicio</span>
            <span><i style="background:var(--roxo-600)"></i> Em producao</span>
            <span><i style="background:var(--verde-500)"></i> Concluido</span>
            <span><i class="legenda-hoje"></i> Hoje</span>
        </div>
    </div>
</div>

<!-- LISTA DO MES (usada tambem pra impressao) -->
<div class="cartao">
    <div class="cartao-cabecalho">
        <h3>Instalacoes de <?= e($tituloMes) ?></h3>
        <span class="txt-p txt-suave"><?= $totalMes ?> registro(s)</span>
    </div>
    <?php if ($instalacoes): ?>
        <div class="tabela-rolagem">
            <table class="tabela">
                <thead>
                    <tr>
                        <th>Data</th>
                        <th>Proposta</th>
                        <th>Cliente</th>
                        <th>Endereco</th>
                        <th>Responsavel</th>
                        <th class="centro">Status</th>
                        <?php if ($verFinanceiro): ?><th class="num">Valor</th><?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($instalacoes as $inst): ?>
                    <tr>
                        <td class="negrito"><?= data_br($inst['data_entrega_prevista']) ?></td>
                        <td>
                            <a href="orcamentos_detalhes.php?id=<?= (int) $inst['id'] ?>"
                               class="mono txt-p"><?= e($inst['numero']) ?></a>
                        </td>
                        <td>
                            <div class="titulo-celula"><?= e($inst['cliente']) ?></div>
                            <div class="sub-celula"><?= e(formatar_telefone($inst['cliente_telefone'])) ?></div>
                        </td>
                        <td class="txt-p">
                            <?= e($inst['endereco']) ?><?= $inst['cliente_numero'] ? ', ' . e($inst['cliente_numero']) : '' ?>
                            <div class="sub-celula">
                                <?= e(trim($inst['bairro'] . ' - ' . $inst['cidade'] . '/' . $inst['uf'], ' -/')) ?>
                            </div>
                        </td>
                        <td class="txt-p"><?= e($inst['responsavel']) ?></td>
                        <td class="centro"><?= selo_status($inst['status']) ?></td>
                        <?php if ($verFinanceiro): ?>
                            <td class="num negrito"><?= moeda($inst['valor_total']) ?></td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="cartao-corpo">
            <div class="vazio">
                <div class="vazio-icone">&#128197;</div>
                <h4>Nenhuma instalacao neste mes</h4>
                <p>Quando uma proposta aprovada tiver data prevista de instalacao
                   para <?= e($tituloMes) ?>, ela aparece aqui.</p>
            </div>
        </div>
    <?php endif; ?>
</div>

<!-- MODAL DE DETALHES DO DIA -->
<dialog id="modalDia" class="modal-dia">
    <header class="modal-dia-cabecalho">
        <h3 id="modalDiaTitulo">Instalacoes do dia</h3>
        <button type="button" onclick="document.getElementById('modalDia').close()"
                class="modal-dia-fechar" aria-label="Fechar">&times;</button>
    </header>
    <div id="modalDiaCorpo" class="modal-dia-corpo"></div>
</dialog>

<!-- Dados das instalacoes por dia (JSON, usado pelo JS do modal) -->
<script>
window.INSTALACOES_DIA = <?= json_encode($porDia, JSON_UNESCAPED_UNICODE) ?>;
window.MES_ATUAL_AGENDA = <?= json_encode($mesParam) ?>;
</script>

<style>
    /* Estilos do calendario - so usados nesta tela */
    .calendario {
        display: grid;
        grid-template-columns: repeat(7, 1fr);
        gap: 4px;
    }
    .calendario-semana {
        padding: 8px 4px;
        text-align: center;
        font-size: 11px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: .5px;
        color: var(--texto-suave);
    }
    .calendario-celula {
        position: relative;
        min-height: 82px;
        padding: 8px;
        background: var(--superficie);
        border: 1px solid var(--borda);
        border-radius: var(--r-sm);
        transition: var(--transicao);
    }
    .calendario-celula.vazia {
        background: transparent;
        border-color: transparent;
    }
    .calendario-celula.hoje {
        border-color: var(--laranja-600);
        background: var(--laranja-50);
        box-shadow: 0 0 0 2px var(--laranja-100);
    }
    .calendario-celula.tem-instalacao {
        cursor: pointer;
    }
    .calendario-celula.tem-instalacao:hover {
        background: var(--laranja-50);
        border-color: var(--laranja-500);
        transform: translateY(-1px);
        box-shadow: var(--sombra-2);
    }
    .calendario-celula.tem-instalacao:focus {
        outline: 2px solid var(--laranja-500);
        outline-offset: 2px;
    }
    .calendario-dia-numero {
        font-size: 14px;
        font-weight: 700;
        color: var(--texto);
        line-height: 1;
    }
    .calendario-celula.hoje .calendario-dia-numero {
        color: var(--laranja-700);
    }
    .calendario-badges {
        display: flex;
        flex-wrap: wrap;
        gap: 3px;
        margin-top: 6px;
    }
    .calendario-badge {
        display: inline-block;
        width: 8px;
        height: 8px;
        border-radius: 50%;
    }
    .calendario-mais {
        font-size: 10px;
        font-weight: 700;
        color: var(--texto-suave);
        align-self: center;
    }
    .calendario-total {
        position: absolute;
        bottom: 4px;
        right: 6px;
        font-size: 10px;
        font-weight: 700;
        color: var(--texto-suave);
        background: var(--superficie-2);
        padding: 0 4px;
        border-radius: 3px;
    }
    .calendario-legenda {
        display: flex;
        flex-wrap: wrap;
        gap: 16px;
        margin-top: 16px;
        padding-top: 16px;
        border-top: 1px solid var(--borda);
        font-size: 12px;
        color: var(--texto-suave);
    }
    .calendario-legenda span {
        display: inline-flex;
        align-items: center;
        gap: 6px;
    }
    .calendario-legenda i {
        display: inline-block;
        width: 10px;
        height: 10px;
        border-radius: 50%;
    }
    .calendario-legenda .legenda-hoje {
        background: var(--laranja-50);
        border: 1px solid var(--laranja-600);
    }

    /* Modal */
    .modal-dia {
        border: 1px solid var(--borda);
        border-radius: var(--r-lg);
        padding: 0;
        max-width: 620px;
        width: calc(100% - 32px);
        background: var(--superficie);
        color: var(--texto);
        box-shadow: var(--sombra-3);
    }
    .modal-dia::backdrop {
        background: rgba(15, 23, 42, .55);
    }
    .modal-dia-cabecalho {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: var(--s-4) var(--s-5);
        border-bottom: 1px solid var(--borda);
        background: var(--superficie-2);
    }
    .modal-dia-cabecalho h3 {
        font-size: 16px;
        font-weight: 600;
    }
    .modal-dia-fechar {
        font-size: 24px;
        line-height: 1;
        color: var(--texto-suave);
        padding: 0 4px;
        background: none;
        border: none;
        cursor: pointer;
    }
    .modal-dia-fechar:hover {
        color: var(--vermelho-600);
    }
    .modal-dia-corpo {
        padding: var(--s-5);
        max-height: 70vh;
        overflow-y: auto;
    }
    .modal-dia-item {
        padding: 12px 0;
        border-bottom: 1px solid var(--borda);
    }
    .modal-dia-item:last-child {
        border-bottom: none;
        padding-bottom: 0;
    }
    .modal-dia-item:first-child {
        padding-top: 0;
    }
    .modal-dia-item-topo {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        margin-bottom: 6px;
        flex-wrap: wrap;
    }
    .modal-dia-item-numero {
        font-family: var(--fonte-mono);
        font-weight: 700;
        font-size: 13px;
    }
    .modal-dia-item-cliente {
        font-weight: 600;
        font-size: 14px;
    }
    .modal-dia-item-info {
        font-size: 12px;
        color: var(--texto-suave);
        margin-top: 2px;
    }
    .modal-dia-item-acoes {
        margin-top: 10px;
        display: flex;
        gap: 6px;
        flex-wrap: wrap;
    }

    /* Em telas pequenas, celulas menores */
    @media (max-width: 720px) {
        .calendario-celula {
            min-height: 62px;
            padding: 6px;
        }
        .calendario-badge {
            width: 6px;
            height: 6px;
        }
        .calendario-total {
            display: none;
        }
    }
</style>

<script>
(function () {
    'use strict';

    var MESES = ['Janeiro','Fevereiro','Marco','Abril','Maio','Junho',
                 'Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];

    // Escapa texto que vem do banco pra evitar quebrar o HTML
    function escapar(txt) {
        var div = document.createElement('div');
        div.textContent = txt || '';
        return div.innerHTML;
    }

    function rotuloStatus(s) {
        return {
            'aprovado': 'Aprovado',
            'em_producao': 'Em producao',
            'concluido': 'Concluido'
        }[s] || s;
    }

    function corStatus(s) {
        return {
            'aprovado': 'var(--ambar-500)',
            'em_producao': 'var(--roxo-600)',
            'concluido': 'var(--verde-500)'
        }[s] || 'var(--texto-suave)';
    }

    window.abrirDia = function (dia) {
        var instalacoes = (window.INSTALACOES_DIA || {})[dia] || [];
        if (!instalacoes.length) return;

        var partes = window.MES_ATUAL_AGENDA.split('-');
        var mesNome = MESES[parseInt(partes[1], 10) - 1];
        var titulo = 'Dia ' + dia + ' de ' + mesNome;
        if (instalacoes.length > 1) {
            titulo += ' &middot; ' + instalacoes.length + ' instalacoes';
        } else {
            titulo += ' &middot; 1 instalacao';
        }

        document.getElementById('modalDiaTitulo').innerHTML = titulo;

        var html = instalacoes.map(function (i) {
            var endereco = i.endereco || '';
            if (i.cliente_numero) endereco += ', ' + i.cliente_numero;
            var cidade = [i.bairro, i.cidade + '/' + i.uf].filter(Boolean).join(' - ');

            return '<div class="modal-dia-item">' +
                '<div class="modal-dia-item-topo">' +
                    '<div>' +
                        '<div class="modal-dia-item-numero">' + escapar(i.numero) + '</div>' +
                        '<div class="modal-dia-item-cliente">' + escapar(i.cliente) + '</div>' +
                    '</div>' +
                    '<span class="selo" style="background:' + corStatus(i.status) + ';color:#fff">' +
                        escapar(rotuloStatus(i.status)) +
                    '</span>' +
                '</div>' +
                '<div class="modal-dia-item-info">' +
                    escapar(endereco) +
                    (cidade ? '<br>' + escapar(cidade) : '') +
                '</div>' +
                '<div class="modal-dia-item-info">' +
                    'Responsavel: ' + escapar(i.responsavel || '-') +
                    (i.cliente_telefone ? ' &middot; ' + escapar(i.cliente_telefone) : '') +
                '</div>' +
                '<div class="modal-dia-item-acoes">' +
                    '<a href="orcamentos_detalhes.php?id=' + parseInt(i.id, 10) + '" ' +
                       'class="botao botao-primario botao-p">Ver proposta</a>' +
                '</div>' +
            '</div>';
        }).join('');

        document.getElementById('modalDiaCorpo').innerHTML = html;
        document.getElementById('modalDia').showModal();
    };
})();
</script>

<?php require_once __DIR__ . '/inclui/rodape.php'; ?>