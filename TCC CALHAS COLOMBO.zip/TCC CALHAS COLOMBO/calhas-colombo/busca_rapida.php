<?php
// endpoint chamado pelo JS da busca global no topo do sistema.
// recebe ?q=termo e devolve JSON com os resultados agrupados.
//
// Regras:
//   - exigir login (o middleware auth.php ja cuida disso)
//   - so busca com 2+ caracteres (evita trazer tudo com 1 letra)
//   - respeita permissao: quem nao pode ver clientes, nao recebe clientes
//   - limite de 5 por categoria (o dropdown nao precisa mais que isso)
//   - se o termo for vazio ou curto, devolve resposta vazia sem query

require_once __DIR__ . '/inclui/auth.php';
exigir_login();

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

$q = trim($_GET['q'] ?? '');

// Termo curto: devolve vazio sem consultar o banco
if (mb_strlen($q) < 2) {
    echo json_encode([
        'total'     => 0,
        'clientes'  => [],
        'orcamentos' => [],
        'produtos'  => [],
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$termo = '%' . $q . '%';
$pdo   = bd();

$resultado = [
    'total'      => 0,
    'clientes'   => [],
    'orcamentos' => [],
    'produtos'   => [],
];

// Clientes
if (pode('gerir_clientes')) {
    $st = $pdo->prepare(
        "SELECT id, nome, telefone, cidade
         FROM clientes
         WHERE ativo = 1
           AND (nome LIKE :q OR cpf_cnpj LIKE :q OR telefone LIKE :q OR email LIKE :q)
         ORDER BY nome
         LIMIT 5"
    );
    $st->execute([':q' => $termo]);
    $resultado['clientes'] = $st->fetchAll();
}

// Orcamentos
if (pode('gerir_orcamentos')) {
    $st = $pdo->prepare(
        "SELECT o.id, o.numero, o.status, o.valor_total,
                c.nome AS cliente
         FROM orcamentos o
         JOIN clientes c ON c.id = o.cliente_id
         WHERE o.numero LIKE :q OR c.nome LIKE :q
         ORDER BY o.id DESC
         LIMIT 5"
    );
    $st->execute([':q' => $termo]);
    $resultado['orcamentos'] = $st->fetchAll();
}

// Produtos
if (pode('gerir_produtos')) {
    $st = $pdo->prepare(
        "SELECT id, nome, unidade, preco_unitario
         FROM produtos
         WHERE ativo = 1 AND nome LIKE :q
         ORDER BY nome
         LIMIT 5"
    );
    $st->execute([':q' => $termo]);
    $resultado['produtos'] = $st->fetchAll();
}

// Total (usado pra saber se mostra "nada encontrado" no dropdown)
$resultado['total'] = count($resultado['clientes'])
                    + count($resultado['orcamentos'])
                    + count($resultado['produtos']);

echo json_encode($resultado, JSON_UNESCAPED_UNICODE);
exit;