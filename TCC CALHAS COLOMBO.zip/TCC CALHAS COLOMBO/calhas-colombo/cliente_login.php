<?php
require_once __DIR__ . '/inclui/auth_cliente.php';

if (cliente_logado()) {
    redirecionar('cliente_painel.php');
}

$erro  = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validar();

    $email = trim($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';

    if ($email === '' || $senha === '') {
        $erro = 'Informe o e-mail e a senha.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $erro = 'O e-mail informado nao e valido.';
    } else {
        $cliente = validar_credenciais_cliente($email, $senha);

        if (!$cliente) {
            $erro = 'E-mail ou senha incorretos.';
        } else {
            efetivar_login_cliente($cliente);
            log_cliente((int) $cliente['id'], 'LOGIN', 'Acessou a area do cliente');

            flash('sucesso', 'Bem-vindo, ' . $cliente['nome'] . '!');
            redirecionar('cliente_painel.php');
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Area do cliente &middot; <?= e(EMPRESA_NOME) ?></title>
<link rel="stylesheet" href="assets/css/estilo.css">
</head>
<body class="pagina-login">

<div class="caixa-login">

    <div class="login-topo">
        <img src="assets/img/logo-icone.png" alt="" class="login-logo">
        <h1>Area do cliente</h1>
        <p>Acompanhe suas propostas e orcamentos</p>
    </div>

    <div class="login-corpo">

        <?php if ($erro): ?>
            <div class="alerta alerta-erro">
                <span class="alerta-icone">&#33;</span>
                <span><?= e($erro) ?></span>
            </div>
        <?php endif; ?>

        <?= flash_exibir() ?>

        <form method="POST" autocomplete="on">
            <?= csrf_campo() ?>

            <div class="campo">
                <label for="email">E-mail</label>
                <input type="email" id="email" name="email"
                       value="<?= e($email) ?>"
                       placeholder="seu@email.com" required autofocus>
            </div>

            <div class="campo">
                <label for="senha">Senha</label>
                <input type="password" id="senha" name="senha"
                       placeholder="Digite sua senha" required>
            </div>

            <button type="submit" class="botao botao-primario botao-bloco botao-g">Entrar</button>
        </form>

        <p class="txt-p txt-suave txt-centro mt2">
            Sua senha foi enviada por e-mail. Se nao recebeu ou esqueceu,
            entre em contato com a gente pelo telefone
            <strong><?= e(EMPRESA_TELEFONE) ?></strong>.
        </p>
    </div>

    <div class="login-rodape">
        &copy; <?= date('Y') ?> <?= e(EMPRESA_NOME) ?>
    </div>
</div>

</body>
</html>