<?php
require_once __DIR__ . '/inclui/auth_cliente.php';

$cli = cliente_atual();

if ($cli['id']) {
    log_cliente((int) $cli['id'], 'LOGOUT', 'Saiu da area do cliente');
}

$_SESSION = [];

if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params['path'], $params['domain'],
        $params['secure'], $params['httponly']
    );
}

if (session_status() === PHP_SESSION_ACTIVE) {
    session_destroy();
}

header('Location: cliente_login.php');
exit;