<?php
// detalhes de uma proposta especifica, visto pelo cliente.
// se a proposta estiver aguardando resposta, ele pode aprovar
// ou recusar por aqui mesmo (mesma logica do link publico).

$id = (int) ($_GET['id'] ?? 0);

require_once __DIR__ . '/inclui/auth_cliente.php';
exigir_login_cliente();

$cli = cliente_atual();
$pdo = bd();

// Busca a proposta garantindo que pertence a este cliente
$st = $pdo->prepare(
    "SELECT o.*,
            u.nome AS responsavel_nome
     FROM orcamentos o
     JOIN usuarios u ON u.id = o.responsavel_id
     WHERE o.id = :id AND o.cliente_id = :cli"
);
$st->execute([':id' => $id, ':cli' => $cli['id']]);
$orc = $st->fetch();

if (!$orc) {
    flash('erro', 'Proposta nao encontrada.');
    redirecionar('cliente_painel.php');
}

// Se o cliente apertou aprovar ou recusar
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['resposta'])) {
    csrf_validar();

    if (in_array($orc['status'], ['rascunho', 'enviado'], true)) {
        $novoStatus = $_POST['resposta'] === 'aprovar' ? 'aprovado' : 'cancelado';

        $pdo->prepare(
            "UPDATE orcamentos SET status = :s, data_resposta = NOW() WHERE id = :id"
        )->execute([':s' => $novoStatus, ':id' => $id]);

        log_cliente((int) $cli['id'], 'RESPONDER',
            $novoStatus === 'aprovado' ? 'Aprovou a proposta ' . $orc['numero']
                                       : 'Recusou a proposta ' . $orc['numero']);

        flash('sucesso', $novoStatus === 'aprovado'
            ? 'Proposta aprovada! Nossa equipe vai entrar em contato pra agendar.'
            : 'Proposta recusada. Se mudar de ideia, e so falar com a gente.');

        redirecionar('cliente_orcamento.php?id=' . $id);
    }
}

// Itens e medidas
$st = $pdo->prepare(
    "SELECT i.*, p.nome AS produto, p.unidade
     FROM itens_orcamento i
     JOIN produtos p ON p.id = i.produto_id
     WHERE i.orcamento_id = :id ORDER BY i.id"
);
$st->execute([':id' => $id]);
$itens = $st->fetchAll();

$st = $pdo->prepare("SELECT * FROM medidas WHERE orcamento_id = :id ORDER BY id");
$st->execute([':id' => $id]);
$medidas = $st->fetchAll();

$subtotal = (float) $orc['valor_materiais'] + (float) $orc['valor_mao_obra'];
$validade = date('d/m/Y', strtotime($orc['data_orcamento'] . ' +' . (int) $orc['validade_dias'] . ' days'));
$expirada = strtotime($orc['data_orcamento'] . ' +' . (int) $orc['validade_dias'] . ' days') < time();
$aguardando = in_array($orc['status'], ['rascunho', 'enviado'], true) && !$expirada;

$titulo_pagina = 'Proposta ' . $orc['numero'];
require_once __DIR__ . '/inclui/cabecalho_cliente.php';
?>

<div class="pagina-topo">
    <div>
        <div class="trilha">
            <a href="cliente_painel.php">Minhas propostas</a> / <?= e($orc['numero']) ?>
        </div>
        <h1 class="pagina-titulo">Proposta <?= e($orc['numero']) ?></h1>
        <p class="pagina-subtitulo">
            <?= selo_status($orc['status']) ?>
            <?php if ($expirada && in_array($orc['status'], ['rascunho', 'enviado'], true)): ?>
                <span class="selo selo-ambar">Validade expirada</span>
            <?php endif; ?>
        </p>
    </div>
    <div class="pagina-acoes">
        <button onclick="window.print()" class="botao botao-neutro">Imprimir</button>
        <a href="cliente_painel.php" class="botao botao-neutro">Voltar</a>
    </div>
</div>

<!-- FOLHA DA PROPOSTA -->
<div class="folha" style="margin-bottom:var(--s-5)">

    <div class="folha-topo">
        <div class="folha-empresa">
            <div class="folha-empresa-topo">
                <img src="assets/img/logo-icone.png" alt="" class="folha-logo">
                <div>
                    <h1><?= e(EMPRESA_NOME) ?></h1>
                    <p><?= e(EMPRESA_SLOGAN) ?></p>
                </div>
            </div>
            <p><?= e(EMPRESA_ENDERECO) ?></p>
            <p><?= e(EMPRESA_TELEFONE) ?> &middot; <?= e(EMPRESA_EMAIL) ?></p>
            <p>CNPJ <?= e(EMPRESA_CNPJ) ?></p>
        </div>
        <div class="folha-numero">
            <div class="rotulo">Proposta comercial</div>
            <div class="valor"><?= e($orc['numero']) ?></div>
            <div class="rotulo mt1">Emitida em <?= data_br($orc['data_orcamento']) ?></div>
            <div class="rotulo">Valida ate <?= e($validade) ?></div>
        </div>
    </div>

    <div class="folha-blocos">
        <div class="folha-bloco">
            <h3>Dados do cliente</h3>
            <p><strong>Nome:</strong> <?= e($cli['nome']) ?></p>
            <p><strong>E-mail:</strong> <?= e($cli['email']) ?></p>
        </div>
        <div class="folha-bloco">
            <h3>Dados do servico</h3>
            <p><strong>Responsavel:</strong> <?= e($orc['responsavel_nome']) ?></p>
            <?php if ($orc['tipo_telhado']): ?>
                <p><strong>Tipo de telhado:</strong> <?= e($orc['tipo_telhado']) ?></p>
            <?php endif; ?>
            <p><strong>Previsao de instalacao:</strong> <?= data_br($orc['data_entrega_prevista']) ?></p>
        </div>
    </div>

    <?php if ($medidas): ?>
        <h3 style="font-size:13px;text-transform:uppercase;letter-spacing:.6px;
                   color:var(--laranja-600);margin-bottom:8px">
            Medidas levantadas em campo
        </h3>
        <table>
            <thead>
                <tr>
                    <th>Descricao</th>
                    <th class="num" style="width:130px">Medida</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($medidas as $m): ?>
                    <tr>
                        <td><?= e($m['tipo']) ?></td>
                        <td class="num"><?= numero($m['valor']) ?> <?= e($m['unidade']) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>

    <h3 style="font-size:13px;text-transform:uppercase;letter-spacing:.6px;
               color:var(--laranja-600);margin-bottom:8px">
        Materiais e servicos
    </h3>
    <table>
        <thead>
            <tr>
                <th>Item</th>
                <th class="num" style="width:110px">Qtd.</th>
                <th class="num" style="width:110px">Valor unit.</th>
                <th class="num" style="width:120px">Subtotal</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($itens as $item): ?>
                <tr>
                    <td><?= e($item['produto']) ?></td>
                    <td class="num"><?= numero($item['quantidade']) ?> <?= e($item['unidade']) ?></td>
                    <td class="num"><?= moeda($item['valor_unitario']) ?></td>
                    <td class="num"><?= moeda($item['valor_total']) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div class="folha-totais">
        <div><span>Materiais</span><span><?= moeda($orc['valor_materiais']) ?></span></div>
        <div><span>Mao de obra</span><span><?= moeda($orc['valor_mao_obra']) ?></span></div>
        <?php if ((float) $orc['valor_desconto'] > 0): ?>
            <div class="desconto">
                <span>Desconto (<?= numero($orc['percentual_desconto'], 1) ?>%)</span>
                <span>- <?= moeda($orc['valor_desconto']) ?></span>
            </div>
        <?php endif; ?>
        <div><span>Pagamento</span><span><strong><?= e($orc['forma_pagamento'] ?: 'A combinar') ?></strong></span></div>
        <div class="total"><span>TOTAL</span><span><?= moeda($orc['valor_total']) ?></span></div>
    </div>

    <div class="folha-rodape">
        Documento gerado pelo sistema em <?= date('d/m/Y \a\s H:i') ?>
    </div>
</div>

<!-- PAINEL DE RESPOSTA (se estiver aguardando) -->
<?php if ($aguardando): ?>
    <div class="cartao">
        <div class="cartao-cabecalho"><h3>O que voce decide?</h3></div>
        <div class="cartao-corpo" style="text-align:center">
            <p class="txt-suave mb3">
                Sua resposta chega na hora pra nossa equipe.
            </p>
            <form method="POST" class="flex centro-h g3 quebra">
                <?= csrf_campo() ?>
                <button type="submit" name="resposta" value="aprovar"
                        class="botao botao-sucesso botao-g"
                        data-confirmar="Confirmar a aprovacao desta proposta?">
                    Aprovar proposta
                </button>
                <button type="submit" name="resposta" value="recusar"
                        class="botao botao-neutro botao-g"
                        data-confirmar="Deseja recusar esta proposta?">
                    Recusar
                </button>
            </form>
        </div>
    </div>
<?php elseif ($expirada && in_array($orc['status'], ['rascunho', 'enviado'], true)): ?>
    <div class="alerta alerta-aviso">
        <span class="alerta-icone">&#9888;</span>
        <span>Esta proposta expirou em <?= e($validade) ?>.
            Entre em contato pelo telefone <?= e(EMPRESA_TELEFONE) ?> pra atualizar os valores.</span>
    </div>
<?php endif; ?>

<?php require_once __DIR__ . '/inclui/rodape_cliente.php'; ?>