<?php
// painel inicial da area do cliente: mostra as propostas dele em
// cards com timeline de andamento, prazo estimado e botao pro WhatsApp

$titulo_pagina = 'Minhas propostas';
require_once __DIR__ . '/inclui/cabecalho_cliente.php';

$cli = cliente_atual();
$pdo = bd();

$st = $pdo->prepare(
    "SELECT o.id, o.numero, o.status, o.valor_total, o.data_orcamento,
            o.validade_dias, o.data_entrega_prevista, o.data_resposta
     FROM orcamentos o
     WHERE o.cliente_id = :id
     ORDER BY o.id DESC"
);
$st->execute([':id' => $cli['id']]);
$orcamentos = $st->fetchAll();

/* ====================================================================
   HELPERS: transformam o status do banco em informacao amigavel pro
   cliente. Tudo calculado aqui, nada de mexer no banco.
   ==================================================================== */

/**
 * Retorna informacoes de progresso a partir do status.
 *
 * As 4 etapas que o cliente ve sao:
 *   0 - Proposta
 *   1 - Aprovacao
 *   2 - Producao
 *   3 - Concluida
 */
function progresso_status(string $status): array
{
    $etapas = ['Proposta', 'Aprovacao', 'Producao', 'Concluida'];

    $mapa = [
        'rascunho'    => 0,
        'enviado'     => 0,
        'aprovado'    => 1,
        'em_producao' => 2,
        'concluido'   => 3,
        'cancelado'   => -1,
    ];

    $indice = $mapa[$status] ?? 0;

    return [
        'etapas'    => $etapas,
        'atual'     => $indice,
        'cancelado' => $indice === -1,
    ];
}

/**
 * Texto do "proximo passo" pro cliente entender o que acontece agora.
 */
function proximo_passo(string $status): string
{
    $mapa = [
        'rascunho'    => 'Aguardando envio da proposta.',
        'enviado'     => 'Aguardando sua resposta. Aprove ou recuse a proposta.',
        'aprovado'    => 'Tudo certo! Vamos iniciar a fabricacao das pecas.',
        'em_producao' => 'Estamos fabricando as pecas. Avisamos quando estiver pronto.',
        'concluido'   => 'Servico finalizado. Qualquer duvida, e so chamar.',
        'cancelado'   => 'Esta proposta foi cancelada.',
    ];

    return $mapa[$status] ?? '';
}

/**
 * Informacoes do prazo estimado. So faz sentido mostrar quando ainda
 * nao foi concluido nem cancelado.
 */
function prazo_info(?string $dataEntrega, string $status): ?array
{
    if (in_array($status, ['concluido', 'cancelado'], true)) {
        return null;
    }

    if (empty($dataEntrega)) {
        return null;
    }

    $hoje = new DateTime('today');
    $data = new DateTime($dataEntrega);
    $diff = (int) $hoje->diff($data)->format('%r%a');

    if ($diff === 0) {
        return [
            'texto' => 'Previsao: hoje (' . $data->format('d/m/Y') . ')',
            'cor'   => 'var(--laranja-600)',
        ];
    }

    if ($diff > 0) {
        return [
            'texto' => 'Previsao: ' . $data->format('d/m/Y') . ' (faltam ' . $diff . ' dia' . ($diff === 1 ? '' : 's') . ')',
            'cor'   => 'var(--verde-600)',
        ];
    }

    $atraso = abs($diff);
    return [
        'texto' => 'Previsao: ' . $data->format('d/m/Y') . ' (atrasado em ' . $atraso . ' dia' . ($atraso === 1 ? '' : 's') . ')',
        'cor'   => 'var(--ambar-600)',
    ];
}

/**
 * Data da ultima atualizacao do orcamento. Se o cliente ja respondeu,
 * usa a data_resposta. Senao, usa a data de emissao.
 */
function ultima_atualizacao(array $orc): string
{
    if (!empty($orc['data_resposta'])) {
        return 'Atualizado em ' . data_br($orc['data_resposta'], true);
    }
    return 'Emitido em ' . data_br($orc['data_orcamento'], true);
}
?>

<!-- CSS especifico da timeline - so usado nessa tela -->
<style>
    .timeline {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        margin: 18px 0 16px;
        position: relative;
    }
    .timeline-etapa {
        display: flex;
        flex-direction: column;
        align-items: center;
        flex: 1;
        position: relative;
        z-index: 1;
    }
    .timeline-bolinha {
        width: 28px;
        height: 28px;
        border-radius: 50%;
        background: var(--superficie-2);
        border: 2px solid var(--borda-forte);
        color: var(--texto-suave);
        display: grid;
        place-items: center;
        font-size: 13px;
        font-weight: 700;
        margin-bottom: 6px;
    }
    .timeline-etapa.feita .timeline-bolinha {
        background: var(--verde-500);
        border-color: var(--verde-500);
        color: #fff;
    }
    .timeline-etapa.atual .timeline-bolinha {
        background: var(--laranja-600);
        border-color: var(--laranja-600);
        color: #fff;
        box-shadow: 0 0 0 4px var(--laranja-100);
    }
    .timeline-rotulo {
        font-size: 11px;
        font-weight: 600;
        color: var(--texto-suave);
        text-align: center;
        text-transform: uppercase;
        letter-spacing: .4px;
    }
    .timeline-etapa.feita .timeline-rotulo,
    .timeline-etapa.atual .timeline-rotulo {
        color: var(--texto);
    }
    .timeline-linha {
        position: absolute;
        top: 14px;
        left: 50%;
        right: -50%;
        height: 2px;
        background: var(--borda-forte);
        z-index: 0;
    }
    .timeline-etapa.feita .timeline-linha {
        background: var(--verde-500);
    }
    .timeline-etapa:last-child .timeline-linha {
        display: none;
    }
    .orcamento-cancelado {
        opacity: .75;
    }
</style>

<div class="pagina-topo">
    <div>
        <h1 class="pagina-titulo">Minhas propostas</h1>
        <p class="pagina-subtitulo">
            <?= count($orcamentos) ?> proposta(s) &middot;
            acompanhe o andamento dos seus servicos
        </p>
    </div>
</div>

<?php if ($orcamentos): ?>
    <div class="grade-2">
        <?php foreach ($orcamentos as $o): ?>
            <?php
            $prog   = progresso_status($o['status']);
            $prazo  = prazo_info($o['data_entrega_prevista'], $o['status']);
            $passo  = proximo_passo($o['status']);
            $atual  = ultima_atualizacao($o);

            $msgZap = "Ola! Sou " . $cli['nome'] . " e estou acompanhando a proposta "
                    . $o['numero'] . " pelo portal. Gostaria de tirar uma duvida.";
            $zapLink = link_whatsapp(EMPRESA_WHATSAPP, $msgZap);
            ?>

            <div class="cartao <?= $prog['cancelado'] ? 'orcamento-cancelado' : '' ?>"
                 style="margin-bottom:0">

                <div class="cartao-cabecalho">
                    <div>
                        <h3 style="font-family:var(--fonte-mono)"><?= e($o['numero']) ?></h3>
                        <div class="txt-p txt-suave mt1"><?= e($atual) ?></div>
                    </div>
                    <?= selo_status($o['status']) ?>
                </div>

                <div class="cartao-corpo">

                    <?php if ($prog['cancelado']): ?>
                        <div class="alerta alerta-erro" style="margin-bottom:0">
                            <span class="alerta-icone">&#33;</span>
                            <span>
                                <strong>Proposta cancelada.</strong>
                                Se foi um engano ou voce quer reativar, entre em contato com a gente.
                            </span>
                        </div>

                    <?php else: ?>
                        <div class="timeline">
                            <?php foreach ($prog['etapas'] as $i => $rotulo): ?>
                                <?php
                                $classe = '';
                                if ($i < $prog['atual']) {
                                    $classe = 'feita';
                                } elseif ($i === $prog['atual']) {
                                    $classe = 'atual';
                                }
                                ?>
                                <div class="timeline-etapa <?= $classe ?>">
                                    <div class="timeline-bolinha">
                                        <?= $i < $prog['atual'] ? '&#10003;' : ($i + 1) ?>
                                    </div>
                                    <div class="timeline-rotulo"><?= e($rotulo) ?></div>
                                    <div class="timeline-linha"></div>
                                </div>
                            <?php endforeach; ?>
                        </div>

                        <p class="txt-p" style="margin-top:14px;color:var(--texto)">
                            <?= e($passo) ?>
                        </p>

                        <div style="display:flex;justify-content:space-between;align-items:flex-end;
                                    gap:16px;flex-wrap:wrap;margin-top:14px;padding-top:14px;
                                    border-top:1px solid var(--borda)">
                            <div>
                                <div class="txt-p txt-suave">VALOR</div>
                                <div style="font-size:22px;font-weight:700;color:var(--laranja-700)">
                                    <?= moeda($o['valor_total']) ?>
                                </div>
                            </div>

                            <?php if ($prazo): ?>
                                <div style="text-align:right">
                                    <div class="txt-p txt-suave">PRAZO</div>
                                    <div style="font-weight:600;color:<?= $prazo['cor'] ?>">
                                        <?= e($prazo['texto']) ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>

                    <?php endif; ?>

                </div>

                <div class="cartao-rodape" style="display:flex;justify-content:flex-end;
                            gap:8px;flex-wrap:wrap">
                    <?php if ($zapLink): ?>
                        <a href="<?= e($zapLink) ?>" target="_blank" rel="noopener"
                           class="botao botao-whats botao-p">
                            Falar no WhatsApp
                        </a>
                    <?php endif; ?>
                    <a href="cliente_orcamento.php?id=<?= (int) $o['id'] ?>"
                       class="botao botao-primario botao-p">
                        Ver detalhes
                    </a>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php else: ?>
    <div class="cartao">
        <div class="cartao-corpo">
            <div class="vazio">
                <div class="vazio-icone">&#9776;</div>
                <h4>Nenhuma proposta por aqui ainda</h4>
                <p>Quando a <?= e(EMPRESA_NOME) ?> criar um orcamento pra voce,
                   ele vai aparecer aqui automaticamente.</p>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php require_once __DIR__ . '/inclui/rodape_cliente.php'; ?>