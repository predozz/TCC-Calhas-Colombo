<?php
// tela simples onde o cliente troca a senha dele

$titulo_pagina = 'Meu perfil';
require_once __DIR__ . '/inclui/cabecalho_cliente.php';

$cli = cliente_atual();
$pdo = bd();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['acao'] ?? '') === 'senha') {
    csrf_validar();

    $atual    = $_POST['senha_atual'] ?? '';
    $nova     = $_POST['senha_nova'] ?? '';
    $confirma = $_POST['senha_confirma'] ?? '';

    $st = $pdo->prepare("SELECT senha FROM clientes WHERE id = :id");
    $st->execute([':id' => $cli['id']]);
    $hashAtual = $st->fetchColumn();

    if (!password_verify($atual, $hashAtual)) {
        flash('erro', 'A senha atual esta incorreta.');
    } elseif (strlen($nova) < 6) {
        flash('erro', 'A nova senha precisa ter no minimo 6 caracteres.');
    } elseif ($nova !== $confirma) {
        flash('erro', 'A confirmacao nao confere com a nova senha.');
    } else {
        $pdo->prepare("UPDATE clientes SET senha = :s WHERE id = :id")
            ->execute([':s' => password_hash($nova, PASSWORD_DEFAULT), ':id' => $cli['id']]);

        log_cliente((int) $cli['id'], 'SENHA', 'Alterou a propria senha');

        flash('sucesso', 'Senha alterada com sucesso.');
    }
    redirecionar('cliente_perfil.php');
}
?>

<div class="pagina-topo">
    <div>
        <h1 class="pagina-titulo">Meu perfil</h1>
        <p class="pagina-subtitulo"><?= e($cli['nome']) ?> &middot; <?= e($cli['email']) ?></p>
    </div>
    <div class="pagina-acoes">
        <a href="cliente_painel.php" class="botao botao-neutro">Voltar</a>
    </div>
</div>

<div class="grade-2">
    <div class="cartao">
        <div class="cartao-cabecalho"><h3>Alterar senha</h3></div>
        <div class="cartao-corpo">
            <form method="POST" class="formulario-grade">
                <?= csrf_campo() ?>
                <input type="hidden" name="acao" value="senha">

                <div class="campo col-12">
                    <label for="senha_atual">Senha atual</label>
                    <input type="password" id="senha_atual" name="senha_atual" required>
                </div>
                <div class="campo col-12">
                    <label for="senha_nova">Nova senha</label>
                    <input type="password" id="senha_nova" name="senha_nova" required minlength="6">
                    <span class="campo-dica">Minimo de 6 caracteres</span>
                </div>
                <div class="campo col-12">
                    <label for="senha_confirma">Confirmar nova senha</label>
                    <input type="password" id="senha_confirma" name="senha_confirma" required minlength="6">
                </div>

                <div class="formulario-acoes">
                    <button type="submit" class="botao botao-sucesso">Alterar senha</button>
                </div>
            </form>
        </div>
    </div>

    <div class="cartao" style="align-self:start">
        <div class="cartao-cabecalho"><h3>Precisa de ajuda?</h3></div>
        <div class="cartao-corpo">
            <p class="txt-suave mb2">
                Se voce esqueceu a senha ou quer alterar seus dados cadastrais,
                entre em contato com a gente:
            </p>
            <p><strong>Telefone:</strong> <?= e(EMPRESA_TELEFONE) ?></p>
            <p><strong>E-mail:</strong> <?= e(EMPRESA_EMAIL) ?></p>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/inclui/rodape_cliente.php'; ?>