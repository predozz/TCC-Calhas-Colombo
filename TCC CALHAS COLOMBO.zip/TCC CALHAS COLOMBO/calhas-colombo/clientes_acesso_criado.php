<?php
// tela que aparece DEPOIS do admin ativar o acesso de um cliente.
// mostra a senha gerada uma unica vez e permite enviar pelo WhatsApp
// ou por e-mail com um clique.
//
// IMPORTANTE: a senha so existe aqui porque foi passada via sessao
// pela pagina anterior. Se o admin sair dessa tela sem enviar, a
// senha se perde - depois so da pra gerar outra (botao "Reenviar acesso").

require_once __DIR__ . '/inclui/auth.php';
exigir_permissao('gerir_clientes');

$u = usuario_logado();

if (!in_array($u['perfil'], ['admin', 'gerente'], true)) {
    flash('erro', 'Voce nao tem permissao para acessar esta area.');
    redirecionar('index.php');
}

$dados = $_SESSION['novo_acesso'] ?? null;

if (!$dados || empty($dados['cliente_id']) || empty($dados['senha'])) {
    flash('aviso', 'A senha so aparece logo apos ser gerada. Use o botao "Reenviar acesso" na listagem pra criar uma nova.');
    redirecionar('clientes_listar.php');
}

$clienteId = (int) $dados['cliente_id'];
$senha     = $dados['senha'];
$primeiro  = !empty($dados['primeira_ativacao']);

$pdo = bd();

$st = $pdo->prepare("SELECT * FROM clientes WHERE id = :id");
$st->execute([':id' => $clienteId]);
$cli = $st->fetch();

if (!$cli) {
    unset($_SESSION['novo_acesso']);
    flash('erro', 'Cliente nao encontrado.');
    redirecionar('clientes_listar.php');
}

/* Monta o link do portal */
$baseUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http')
         . '://' . $_SERVER['HTTP_HOST']
         . rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
$linkPortal = $baseUrl . '/cliente_login.php';

/* Mensagem pronta pro WhatsApp */
$msgWhats = ($primeiro
    ? "Ola " . $cli['nome'] . ", tudo bem? Aqui e da " . EMPRESA_NOME . "!\n\n"
    : "Ola " . $cli['nome'] . ", aqui e da " . EMPRESA_NOME . " de novo.\n\n")

    . "Criamos um acesso pra voce acompanhar suas propostas online, aprovar "
    . "direto pelo celular e ver o andamento das obras.\n\n"

    . "*SEUS DADOS DE ACESSO:*\n"
    . "E-mail: " . $cli['email'] . "\n"
    . "Senha: " . $senha . "\n\n"

    . "Acesse por aqui:\n" . $linkPortal . "\n\n"

    . "Recomendamos trocar a senha no primeiro acesso, no menu \"Meu perfil\". "
    . "Se tiver qualquer duvida, e so responder essa mensagem.";

$whatsLink = link_whatsapp($cli['whatsapp'] ?: $cli['telefone'], $msgWhats);

/* Processa o "Concluir" ou "Enviar por e-mail" */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validar();

    $acao = $_POST['acao'] ?? '';

    if ($acao === 'enviar_email') {
        require_once __DIR__ . '/inclui/email.php';

        $corpo = "
            <div style='font-family:sans-serif;max-width:520px;margin:0 auto;
                        padding:20px;background:#f4f6fa;border-radius:12px'>
                <div style='background:#fff;padding:32px;border-radius:10px'>
                    <h2 style='color:#e07c12;margin:0 0 20px'>" . e(EMPRESA_NOME) . "</h2>
                    <p style='color:#334155'>Ola " . e($cli['nome']) . ",</p>
                    <p style='color:#334155'>Seu acesso a nossa area do cliente foi criado.
                       Seus dados pra entrar sao:</p>
                    <div style='background:#fdf3e4;padding:16px;border-radius:8px;margin:20px 0'>
                        <p style='margin:0 0 8px;font-size:14px;color:#b35f0d'>
                            <strong>E-mail:</strong> " . e($cli['email']) . "
                        </p>
                        <p style='margin:0;font-size:14px;color:#b35f0d'>
                            <strong>Senha:</strong> <span style='font-family:monospace;
                            font-size:18px;background:#fff;padding:4px 10px;border-radius:4px;
                            display:inline-block;letter-spacing:2px'>$senha</span>
                        </p>
                    </div>
                    <p style='text-align:center;margin:32px 0'>
                        <a href='$linkPortal'
                           style='display:inline-block;padding:14px 32px;background:#e07c12;
                                  color:#fff;text-decoration:none;border-radius:8px;
                                  font-weight:bold;font-size:16px'>
                            Acessar minha area
                        </a>
                    </p>
                    <p style='color:#64748b;font-size:13px'>
                        Recomendamos trocar a senha no primeiro acesso.
                        Se voce nao reconhece esse cadastro, ignore este e-mail.
                    </p>
                </div>
            </div>
        ";

        if (enviar_email($cli['email'], 'Seu acesso - ' . EMPRESA_NOME, $corpo)) {
            flash('sucesso', 'E-mail enviado para ' . $cli['email']);
        } else {
            flash('erro', 'Nao foi possivel enviar o e-mail. Tente pelo WhatsApp.');
        }

        redirecionar('clientes_acesso_criado.php');
    }

    if ($acao === 'concluir') {
        unset($_SESSION['novo_acesso']);
        flash('sucesso', 'Acesso do cliente configurado.');
        redirecionar('clientes_listar.php');
    }
}

$titulo_pagina = 'Acesso criado';
$pagina_ativa  = 'clientes_listar';
require_once __DIR__ . '/inclui/cabecalho.php';
?>

<div class="pagina-topo">
    <div>
        <div class="trilha"><a href="clientes_listar.php">Clientes</a> / Acesso criado</div>
        <h1 class="pagina-titulo">Acesso do cliente pronto</h1>
        <p class="pagina-subtitulo">Envie os dados de acesso agora pelo WhatsApp ou e-mail</p>
    </div>
</div>

<div class="alerta alerta-aviso" style="font-size:15px">
    <span class="alerta-icone">&#9888;</span>
    <span>
        <strong>Atencao:</strong> por seguranca, essa senha so aparece uma vez.
        Copie ou envie agora. Depois so da pra gerar uma nova pela listagem de clientes.
    </span>
</div>

<div class="grade-2">

    <!-- DADOS DO ACESSO -->
    <div class="cartao">
        <div class="cartao-cabecalho">
            <h3>Dados de acesso</h3>
            <span class="selo selo-verde"><?= $primeiro ? 'Novo acesso' : 'Senha redefinida' ?></span>
        </div>
        <div class="cartao-corpo">

            <div class="campo" style="margin-bottom:var(--s-4)">
                <label>Cliente</label>
                <div style="padding:10px 12px;background:var(--superficie-2);
                            border:1px solid var(--borda);border-radius:var(--r-sm);
                            font-weight:600">
                    <?= e($cli['nome']) ?>
                </div>
            </div>

            <div class="campo" style="margin-bottom:var(--s-4)">
                <label>E-mail de login</label>
                <div style="display:flex;gap:6px;align-items:stretch">
                    <input type="text" id="emailAcesso"
                           value="<?= e($cli['email']) ?>" readonly
                           style="flex:1;font-family:var(--fonte-mono)">
                    <button type="button" class="botao botao-neutro"
                            onclick="copiarCampo('emailAcesso')"
                            title="Copiar e-mail">
                        Copiar
                    </button>
                </div>
            </div>

            <div class="campo" style="margin-bottom:var(--s-4)">
                <label>Senha</label>
                <div style="display:flex;gap:6px;align-items:stretch">
                    <input type="text" id="senhaAcesso"
                           value="<?= e($senha) ?>" readonly
                           style="flex:1;font-family:var(--fonte-mono);font-size:18px;
                                  letter-spacing:3px;text-align:center;font-weight:700;
                                  color:var(--laranja-700)">
                    <button type="button" class="botao botao-neutro"
                            onclick="copiarCampo('senhaAcesso')"
                            title="Copiar senha">
                        Copiar
                    </button>
                </div>
            </div>

            <div class="campo">
                <label>Link do portal</label>
                <div style="display:flex;gap:6px;align-items:stretch">
                    <input type="text" id="linkAcesso"
                           value="<?= e($linkPortal) ?>" readonly
                           style="flex:1;font-family:var(--fonte-mono);font-size:12px">
                    <button type="button" class="botao botao-neutro"
                            onclick="copiarCampo('linkAcesso')"
                            title="Copiar link">
                        Copiar
                    </button>
                </div>
            </div>

        </div>
    </div>

    <!-- ACOES -->
    <div class="cartao" style="align-self:start">
        <div class="cartao-cabecalho"><h3>Enviar pro cliente</h3></div>
        <div class="cartao-corpo">

            <p class="txt-suave mb3">
                Escolha como quer mandar os dados. A mensagem ja vem pronta com
                e-mail, senha e link.
            </p>

            <?php if ($whatsLink): ?>
                <a href="<?= e($whatsLink) ?>" target="_blank" rel="noopener"
                   class="botao botao-whats botao-g botao-bloco"
                   style="margin-bottom:12px">
                    Enviar no WhatsApp
                </a>
                <p class="txt-p txt-suave txt-centro" style="margin-bottom:20px">
                    Vai abrir o WhatsApp com a mensagem pronta pra
                    <strong><?= e(formatar_telefone($cli['whatsapp'] ?: $cli['telefone'])) ?></strong>.
                    É só apertar enviar.
                </p>
            <?php else: ?>
                <div class="alerta alerta-aviso" style="margin-bottom:16px">
                    <span class="alerta-icone">&#9888;</span>
                    <span>Esse cliente nao tem telefone/WhatsApp cadastrado.
                        Atualize o cadastro pra poder enviar por WhatsApp.</span>
                </div>
            <?php endif; ?>

            <?php if (!empty($cli['email'])): ?>
                <form method="POST" style="margin-bottom:20px">
                    <?= csrf_campo() ?>
                    <input type="hidden" name="acao" value="enviar_email">
                    <button type="submit" class="botao botao-contorno botao-bloco">
                        Enviar tambem por e-mail
                    </button>
                    <p class="txt-p txt-suave txt-centro mt1">
                        Vai pra <strong><?= e($cli['email']) ?></strong>
                    </p>
                </form>
            <?php endif; ?>

            <hr style="border:none;border-top:1px solid var(--borda);margin:20px 0">

            <form method="POST">
                <?= csrf_campo() ?>
                <input type="hidden" name="acao" value="concluir">
                <button type="submit" class="botao botao-sucesso botao-bloco">
                    Concluir e voltar pra lista
                </button>
                <p class="txt-p txt-suave txt-centro mt1">
                    Clique quando ja tiver enviado os dados
                </p>
            </form>

        </div>
    </div>

</div>

<script>
function copiarCampo(id) {
    var campo = document.getElementById(id);
    campo.select();
    campo.setSelectionRange(0, 99999);
    try {
        document.execCommand('copy');
        // feedback visual
        campo.style.background = 'var(--verde-100)';
        setTimeout(function () { campo.style.background = ''; }, 800);
    } catch (e) {
        // fallback
        if (navigator.clipboard) {
            navigator.clipboard.writeText(campo.value);
        }
    }
}
</script>

<?php require_once __DIR__ . '/inclui/rodape.php'; ?>