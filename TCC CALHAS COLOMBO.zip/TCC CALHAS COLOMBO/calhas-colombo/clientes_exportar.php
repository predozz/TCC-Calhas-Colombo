<?php
// exporta a lista de clientes em CSV respeitando os mesmos filtros
// da tela de listagem. O arquivo sai com BOM UTF-8 pra o Excel
// abrir os acentos corretamente e usar ponto e virgula como
// separador (padrao brasileiro do Excel).

require_once __DIR__ . '/inclui/auth.php';
exigir_permissao('gerir_clientes');

$pdo = bd();

// Mesmos filtros da listagem
$busca  = trim($_GET['busca'] ?? '');
$cidade = trim($_GET['cidade'] ?? '');
$origem = trim($_GET['origem'] ?? '');

$where  = ['c.ativo = 1'];
$params = [];

if ($busca !== '') {
    $where[] = '(c.nome LIKE :busca OR c.cpf_cnpj LIKE :busca OR c.telefone LIKE :busca OR c.email LIKE :busca)';
    $params[':busca'] = '%' . $busca . '%';
}
if ($cidade !== '') {
    $where[] = 'c.cidade = :cidade';
    $params[':cidade'] = $cidade;
}
if ($origem !== '') {
    $where[] = 'c.origem = :origem';
    $params[':origem'] = $origem;
}

$clausula = 'WHERE ' . implode(' AND ', $where);

$st = $pdo->prepare(
    "SELECT c.nome, c.tipo_pessoa, c.cpf_cnpj, c.telefone, c.whatsapp, c.email,
            c.cep, c.endereco, c.numero, c.complemento, c.bairro, c.cidade, c.uf,
            c.ponto_referencia, c.origem, c.observacoes, c.data_cadastro
     FROM clientes c
     $clausula
     ORDER BY c.nome ASC"
);
$st->execute($params);
$clientes = $st->fetchAll();

// Nome do arquivo com a data do dia
$nomeArquivo = 'clientes_' . date('Y-m-d') . '.csv';

// Cabecalhos HTTP pra forcar o download
header('Content-Type: text/csv; charset=UTF-8');
header('Content-Disposition: attachment; filename="' . $nomeArquivo . '"');
header('Pragma: no-cache');
header('Expires: 0');

$saida = fopen('php://output', 'w');

// BOM UTF-8 (tres bytes) pra o Excel reconhecer acentos
fwrite($saida, "\xEF\xBB\xBF");

// Cabecalho das colunas
fputcsv($saida, [
    'Nome', 'Tipo', 'CPF/CNPJ', 'Telefone', 'WhatsApp', 'E-mail',
    'CEP', 'Endereco', 'Numero', 'Complemento', 'Bairro', 'Cidade', 'UF',
    'Ponto de referencia', 'Origem', 'Observacoes', 'Data de cadastro',
], ';');

// Uma linha por cliente
foreach ($clientes as $c) {
    fputcsv($saida, [
        $c['nome'],
        $c['tipo_pessoa'] === 'juridica' ? 'PJ' : 'PF',
        $c['cpf_cnpj'] ?? '',
        $c['telefone'],
        $c['whatsapp'] ?? '',
        $c['email'] ?? '',
        $c['cep'] ?? '',
        $c['endereco'],
        $c['numero'] ?? '',
        $c['complemento'] ?? '',
        $c['bairro'] ?? '',
        $c['cidade'] ?? '',
        $c['uf'] ?? '',
        $c['ponto_referencia'] ?? '',
        $c['origem'] ?? '',
        $c['observacoes'] ?? '',
        data_br($c['data_cadastro'], true),
    ], ';');
}

fclose($saida);

// Registra na auditoria que alguem exportou a base
registrar_log('EXPORTAR', 'clientes', [
    'mensagem' => 'Exportou a lista de clientes em CSV',
    'total'    => count($clientes),
]);
exit;