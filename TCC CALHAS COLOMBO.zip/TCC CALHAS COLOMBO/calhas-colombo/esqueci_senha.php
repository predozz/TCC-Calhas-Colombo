<?php
// tela onde o usuario digita o email pra receber o link de redefinicao.
//
// IMPORTANTE: a resposta e SEMPRE a mesma, exista ou nao o email no
// banco. Isso evita que alguem use essa tela pra descobrir quem tem
// conta no sistema (user enumeration).
//
// Tambem tem rate limit: se o mesmo email pedir mais de 3 resets em
// 15 minutos, a gente finge que enviou mas nao faz nada.

require_once __DIR__ . '/inclui/auth.php';
require_once __DIR__ . '/inclui/email.php';

if (esta_logado()) {
    redirecionar('index.php');
}

$enviado = false;
$email   = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validar();

    $email = trim($_POST['email'] ?? '');

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        // Mesmo com erro de formato, mostra a mensagem padrao.
        // So que nao faz nada.
        $enviado = true;
    } else {
        $st = bd()->prepare("SELECT * FROM usuarios WHERE email = :e AND ativo = 1 LIMIT 1");
        $st->execute([':e' => $email]);
        $usuario = $st->fetch();

        if ($usuario && !reset_bloqueado_por_rate_limit((int) $usuario['id'])) {
            $token = gerar_token_reset((int) $usuario['id']);

            // Monta a URL do link. Precisa ser absoluta porque o email
            // vai ser aberto em outro dispositivo.
            $base = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http')
                  . '://' . $_SERVER['HTTP_HOST']
                  . rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
            $link = $base . '/redefinir_senha.php?t=' . $token;

            $corpo = "
                <div style='font-family:sans-serif;max-width:520px;margin:0 auto;
                            padding:20px;background:#f4f6fa;border-radius:12px'>
                    <div style='background:#fff;padding:32px;border-radius:10px'>
                        <h2 style='color:#e07c12;margin:0 0 20px'>" . e(EMPRESA_NOME) . "</h2>
                        <p style='color:#334155'>Ola " . e($usuario['nome']) . ",</p>
                        <p style='color:#334155'>Recebemos um pedido pra redefinir a senha da sua conta.
                           Clique no botao abaixo pra criar uma nova senha:</p>
                        <p style='text-align:center;margin:32px 0'>
                            <a href='$link'
                               style='display:inline-block;padding:14px 32px;background:#e07c12;
                                      color:#fff;text-decoration:none;border-radius:8px;
                                      font-weight:bold;font-size:16px'>
                                Redefinir minha senha
                            </a>
                        </p>
                        <p style='color:#64748b;font-size:13px'>
                            O link vale por 30 minutos. Se voce nao pediu isso, ignore este e-mail —
                            sua senha continua a mesma.
                        </p>
                        <p style='color:#94a3b8;font-size:11px;margin-top:24px;word-break:break-all'>
                            Se o botao nao funcionar, cole este endereco no navegador:<br>
                            $link
                        </p>
                    </div>
                </div>
            ";

            enviar_email($usuario['email'], 'Redefinir senha - ' . EMPRESA_NOME, $corpo);

            registrar_log('EDITAR', 'usuarios', [
                'mensagem' => 'Solicitou redefinicao de senha',
                'email'    => $usuario['email'],
            ], null, 'Reset de senha solicitado', (int) $usuario['id']);
        }

        // Sempre mostra a mesma resposta, exista ou nao o email
        $enviado = true;
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Esqueci a senha &middot; <?= e(EMPRESA_NOME) ?></title>
<link rel="stylesheet" href="assets/css/estilo.css">
</head>
<body class="pagina-login">

<div class="caixa-login">

    <div class="login-topo">
        <img src="assets/img/logo-icone.png" alt="" class="login-logo">
        <h1>Esqueci a senha</h1>
        <p>Vamos te mandar um link pra criar uma senha nova</p>
    </div>

    <div class="login-corpo">

        <?php if ($enviado): ?>

            <div class="alerta alerta-sucesso">
                <span class="alerta-icone">&#10003;</span>
                <span>
                    <strong>Pronto.</strong> Se <em><?= e($email) ?></em> estiver cadastrado
                    no sistema, voce vai receber um e-mail com o link pra redefinir a senha.
                </span>
            </div>

            <p class="txt-p txt-suave" style="margin-top:20px">
                Nao chegou? Confere a caixa de spam. O link vale por 30 minutos.
            </p>

            <a href="login.php" class="botao botao-neutro botao-bloco" style="margin-top:20px">
                Voltar pro login
            </a>

        <?php else: ?>

            <p class="txt-p txt-suave" style="margin-bottom:20px">
                Digite o e-mail cadastrado na sua conta. Enviamos um link pra criar uma nova senha.
            </p>

            <form method="POST" autocomplete="on">
                <?= csrf_campo() ?>

                <div class="campo">
                    <label for="email">E-mail</label>
                    <input type="email" id="email" name="email"
                           value="<?= e($email) ?>"
                           placeholder="seu@email.com" required autofocus>
                </div>

                <button type="submit" class="botao botao-primario botao-bloco botao-g">
                    Enviar link de redefinicao
                </button>
            </form>

            <p style="text-align:center;margin-top:20px;font-size:13px">
                <a href="login.php">Voltar pro login</a>
            </p>

        <?php endif; ?>

    </div>

    <div class="login-rodape">
        &copy; <?= date('Y') ?> <?= e(EMPRESA_NOME) ?>
    </div>
</div>

</body>
</html>