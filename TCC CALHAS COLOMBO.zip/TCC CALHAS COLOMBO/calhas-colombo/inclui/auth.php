<?php
// login, sessao e permissao por perfil. toda pagina que exige
// login inclui esse arquivo la em cima

require_once __DIR__ . '/funcoes.php';

// Sessao segura
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

// Funcoes de autenticacao

/**
 * Valida email e senha. Retorna os dados do usuario se as credenciais
 * estiverem certas, ou null se estiverem erradas. NAO cria sessao ainda
 * porque se o 2FA tiver ativo, a sessao so e criada depois do codigo.
 */
function validar_credenciais(string $email, string $senha): ?array
{
    $st = bd()->prepare("SELECT * FROM usuarios WHERE email = :email AND ativo = 1 LIMIT 1");
    $st->execute([':email' => $email]);
    $usuario = $st->fetch();

    if (!$usuario || !password_verify($senha, $usuario['senha'])) {
        return null;
    }

    // Se o hash foi gerado com um algoritmo antigo, regrava atualizado.
    if (password_needs_rehash($usuario['senha'], PASSWORD_DEFAULT)) {
        $novo = password_hash($senha, PASSWORD_DEFAULT);
        bd()->prepare("UPDATE usuarios SET senha = :s WHERE id = :id")
            ->execute([':s' => $novo, ':id' => $usuario['id']]);
    }

    return $usuario;
}

/**
 * Efetiva o login de fato: cria a sessao e atualiza o ultimo acesso.
 * So deve ser chamada depois que a senha (e o 2FA, se ativo) forem validados.
 */
function efetivar_login(array $usuario): void
{
    session_regenerate_id(true);

    $_SESSION['usuario_id']       = (int) $usuario['id'];
    $_SESSION['usuario_nome']     = $usuario['nome'];
    $_SESSION['usuario_email']    = $usuario['email'];
    $_SESSION['usuario_perfil']   = $usuario['perfil'];
    $_SESSION['usuario_telefone'] = $usuario['telefone'];
    $_SESSION['usuario_2fa']      = (int) ($usuario['two_factor_ativo'] ?? 0);

    bd()->prepare("UPDATE usuarios SET ultimo_acesso = NOW() WHERE id = :id")
        ->execute([':id' => $usuario['id']]);
}

/**
 * Compatibilidade: faz o login de uma vez (sem 2FA). Nao e mais usado
 * pelo login.php, mas fica aqui pra nao quebrar nada que dependa dela.
 */
function tentar_login(string $email, string $senha): bool
{
    $u = validar_credenciais($email, $senha);
    if (!$u) {
        return false;
    }
    efetivar_login($u);
    return true;
}

// ---------------------------------------------------------------------
// 2FA - autenticacao em duas etapas por e-mail
// ---------------------------------------------------------------------

/** Gera um codigo de 6 digitos pro usuario e salva no banco (vale 10 min). */
function gerar_codigo_2fa(int $usuarioId): string
{
    // Limpa tokens antigos deste usuario (ja usados ou expirados)
    bd()->prepare(
        "DELETE FROM two_factor_tokens
         WHERE usuario_id = :id AND (usado = 1 OR expira_em < NOW())"
    )->execute([':id' => $usuarioId]);

    $codigo = str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);

    bd()->prepare(
        "INSERT INTO two_factor_tokens (usuario_id, codigo, expira_em)
         VALUES (:u, :c, DATE_ADD(NOW(), INTERVAL 10 MINUTE))"
    )->execute([':u' => $usuarioId, ':c' => $codigo]);

    return $codigo;
}

/** Verifica se o codigo digitado bate com algum token valido do usuario. */
function validar_codigo_2fa(int $usuarioId, string $codigo): bool
{
    $st = bd()->prepare(
        "SELECT id FROM two_factor_tokens
         WHERE usuario_id = :u AND codigo = :c
           AND usado = 0 AND expira_em > NOW()
         ORDER BY id DESC LIMIT 1"
    );
    $st->execute([':u' => $usuarioId, ':c' => $codigo]);
    $token = $st->fetch();

    if (!$token) {
        return false;
    }

    // Marca como usado pra nao dar pra reutilizar
    bd()->prepare("UPDATE two_factor_tokens SET usado = 1 WHERE id = :id")
        ->execute([':id' => $token['id']]);

    return true;
}

// Funcoes de sessao

function fazer_logout(): void
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        setcookie(session_name(), '', time() - 42000, '/');
    }
    session_destroy();
}

function esta_logado(): bool
{
    return isset($_SESSION['usuario_id']);
}

function usuario_logado(): array
{
    return [
        'id'       => $_SESSION['usuario_id']       ?? 0,
        'nome'     => $_SESSION['usuario_nome']     ?? '',
        'email'    => $_SESSION['usuario_email']    ?? '',
        'perfil'   => $_SESSION['usuario_perfil']   ?? '',
        'telefone' => $_SESSION['usuario_telefone'] ?? '',
        '2fa'      => $_SESSION['usuario_2fa']      ?? 0,
    ];
}

// Controle de permissao

/**
 * Matriz de permissoes por perfil.
 * Cada chave e uma "capacidade" verificada com pode('capacidade').
 */
function permissoes(): array
{
    return [
        'admin' => [
            'ver_dashboard', 'ver_financeiro', 'gerir_clientes', 'excluir_clientes',
            'gerir_orcamentos', 'excluir_orcamentos', 'gerir_produtos', 'gerir_insumos',
            'gerir_fornecedores', 'gerir_usuarios', 'ver_relatorios',
        ],
        'gerente' => [
            'ver_dashboard', 'ver_financeiro', 'gerir_clientes',
            'gerir_orcamentos', 'gerir_produtos', 'gerir_insumos',
            'gerir_fornecedores', 'ver_relatorios',
        ],
        'calheiro' => [
            'ver_dashboard', 'gerir_clientes', 'gerir_orcamentos', 'gerir_insumos',
        ],
        'campo' => [
            'ver_dashboard', 'gerir_clientes', 'gerir_orcamentos',
        ],
    ];
}

// Verifica se o usuario logado possui determinada capacidade.
function pode(string $capacidade): bool
{
    $perfil = $_SESSION['usuario_perfil'] ?? '';
    $mapa = permissoes();
    return in_array($capacidade, $mapa[$perfil] ?? [], true);
}

function rotulo_perfil(string $perfil): string
{
    $mapa = [
        'admin'    => 'Administrador',
        'gerente'  => 'Gerente',
        'calheiro' => 'Calheiro',
        'campo'    => 'Tecnico de Campo',
    ];
    return $mapa[$perfil] ?? ucfirst($perfil);
}

// "Porteiros" - chame no inicio das paginas

// Bloqueia quem nao esta logado.
function exigir_login(): void
{
    if (!esta_logado()) {
        flash('aviso', 'Faca login para acessar o sistema.');
        redirecionar('login.php');
    }
}

/** Bloqueia quem nao tem a capacidade informada. */
function exigir_permissao(string $capacidade): void
{
    exigir_login();
    if (!pode($capacidade)) {
        flash('erro', 'Voce nao tem permissao para acessar esta area.');
        redirecionar('index.php');
    }
}

// ---------------------------------------------------------------------
// Redefinicao de senha por e-mail
// ---------------------------------------------------------------------
//
// Fluxo: o usuario pede reset, o sistema gera um token aleatorio de
// 64 caracteres, manda por e-mail e salva no banco com validade de
// 30 minutos. Quando o usuario clica no link e define a nova senha,
// o token e marcado como usado (uso unico). Pedir um novo reset
// invalida os anteriores.
//
// Detalhe de seguranca: a funcao que inicia o reset NUNCA revela se
// o e-mail existe ou nao. Sempre devolve a mesma resposta, pra evitar
// que alguem use a tela pra descobrir quem tem conta no sistema.

/** Gera um token de reset e salva no banco. Retorna o token puro. */
function gerar_token_reset(int $usuarioId): string
{
    // Invalida tokens anteriores deste usuario que ainda nao foram usados
    bd()->prepare(
        "UPDATE password_resets SET usado = 1
         WHERE usuario_id = :id AND usado = 0"
    )->execute([':id' => $usuarioId]);

    // Limpa tokens antigos (usados ou expirados) pra tabela nao crescer demais
    bd()->prepare(
        "DELETE FROM password_resets
         WHERE usuario_id = :id AND (usado = 1 OR expira_em < NOW())"
    )->execute([':id' => $usuarioId]);

    // Gera 64 caracteres hexadecimais (32 bytes aleatorios)
    $token = bin2hex(random_bytes(32));

    $ip = $_SERVER['REMOTE_ADDR'] ?? null;

    bd()->prepare(
        "INSERT INTO password_resets (usuario_id, token, expira_em, ip_solicitante)
         VALUES (:u, :t, DATE_ADD(NOW(), INTERVAL 30 MINUTE), :ip)"
    )->execute([':u' => $usuarioId, ':t' => $token, ':ip' => $ip]);

    return $token;
}

/**
 * Verifica se um token e valido. Retorna os dados do usuario dono
 * do token, ou null se nao existir / estiver expirado / ja foi usado.
 */
function validar_token_reset(string $token): ?array
{
    if (!preg_match('/^[a-f0-9]{64}$/', $token)) {
        return null;
    }

    $st = bd()->prepare(
        "SELECT u.*
         FROM password_resets r
         JOIN usuarios u ON u.id = r.usuario_id
         WHERE r.token = :t
           AND r.usado = 0
           AND r.expira_em > NOW()
         LIMIT 1"
    );
    $st->execute([':t' => $token]);
    $usuario = $st->fetch();

    return $usuario ?: null;
}

/** Marca o token como usado (nao pode ser reutilizado). */
function consumir_token_reset(string $token): void
{
    bd()->prepare(
        "UPDATE password_resets SET usado = 1 WHERE token = :t"
    )->execute([':t' => $token]);
}

/**
 * Rate limit simples: quantos resets foram pedidos pro mesmo usuario
 * nos ultimos 15 minutos. Acima de 3, ignora o pedido (mas ainda
 * devolve a mensagem padrao pro usuario).
 */
function reset_bloqueado_por_rate_limit(int $usuarioId): bool
{
    $st = bd()->prepare(
        "SELECT COUNT(*) FROM password_resets
         WHERE usuario_id = :id
           AND data_criacao > DATE_SUB(NOW(), INTERVAL 15 MINUTE)"
    );
    $st->execute([':id' => $usuarioId]);
    return (int) $st->fetchColumn() >= 3;
}