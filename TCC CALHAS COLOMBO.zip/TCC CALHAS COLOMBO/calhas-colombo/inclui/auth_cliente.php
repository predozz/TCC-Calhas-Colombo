<?php
// autenticacao dos clientes (area logada do portal).
// separado do auth.php de funcionarios de proposito: cliente nao
// tem perfil, nao tem permissao, nao mexe em nada administrativo.
//
// a sessao usa chaves diferentes (cliente_id, cliente_nome, ...)
// pra nao confundir com a sessao de funcionario.

require_once __DIR__ . '/funcoes.php';

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

/**
 * Valida email e senha do cliente. Retorna os dados se ok, ou null.
 */
function validar_credenciais_cliente(string $email, string $senha): ?array
{
    $st = bd()->prepare(
        "SELECT * FROM clientes
         WHERE email = :e AND acesso_ativo = 1 AND ativo = 1
         LIMIT 1"
    );
    $st->execute([':e' => $email]);
    $cliente = $st->fetch();

    if (!$cliente || empty($cliente['senha'])) {
        return null;
    }

    if (!password_verify($senha, $cliente['senha'])) {
        return null;
    }

    if (password_needs_rehash($cliente['senha'], PASSWORD_DEFAULT)) {
        $novo = password_hash($senha, PASSWORD_DEFAULT);
        bd()->prepare("UPDATE clientes SET senha = :s WHERE id = :id")
            ->execute([':s' => $novo, ':id' => $cliente['id']]);
    }

    return $cliente;
}

/** Efetiva o login do cliente: cria a sessao e atualiza o ultimo acesso. */
function efetivar_login_cliente(array $cliente): void
{
    session_regenerate_id(true);

    $_SESSION['cliente_id']       = (int) $cliente['id'];
    $_SESSION['cliente_nome']     = $cliente['nome'];
    $_SESSION['cliente_email']    = $cliente['email'];

    bd()->prepare("UPDATE clientes SET ultimo_acesso_cliente = NOW() WHERE id = :id")
        ->execute([':id' => $cliente['id']]);
}

function cliente_logado(): bool
{
    return isset($_SESSION['cliente_id']);
}

function cliente_atual(): array
{
    return [
        'id'    => $_SESSION['cliente_id']    ?? 0,
        'nome'  => $_SESSION['cliente_nome']  ?? '',
        'email' => $_SESSION['cliente_email'] ?? '',
    ];
}

function exigir_login_cliente(): void
{
    if (!cliente_logado()) {
        flash('aviso', 'Faca login para acessar sua area.');
        redirecionar('cliente_login.php');
    }
}

/** Gera uma senha aleatoria de 8 caracteres (letras + numeros). */
function gerar_senha_cliente(): string
{
    $letras   = 'abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ';
    $numeros  = '23456789';
    $todos    = $letras . $numeros;

    $senha = '';
    // Garante pelo menos 2 numeros pra atender politica minima
    for ($i = 0; $i < 2; $i++) {
        $senha .= $numeros[random_int(0, strlen($numeros) - 1)];
    }
    for ($i = 0; $i < 6; $i++) {
        $senha .= $todos[random_int(0, strlen($todos) - 1)];
    }

    return str_shuffle($senha);
}

/** Registra uma acao do cliente no log especifico dele. */
function log_cliente(int $clienteId, string $acao, string $descricao = ''): void
{
    try {
        bd()->prepare(
            "INSERT INTO clientes_logs (cliente_id, acao, descricao, ip_endereco)
             VALUES (:c, :a, :d, :ip)"
        )->execute([
            ':c'  => $clienteId,
            ':a'  => $acao,
            ':d'  => $descricao,
            ':ip' => $_SERVER['REMOTE_ADDR'] ?? null,
        ]);
    } catch (Exception $e) {
        // silencia
    }
}