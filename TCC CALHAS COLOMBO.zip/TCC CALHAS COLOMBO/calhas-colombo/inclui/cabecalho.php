<?php
// topo + menu lateral, compartilhado entre as paginas.
// antes de dar include aqui, define $titulo_pagina e $pagina_ativa

if (!defined('SISTEMA_INICIADO')) {
    define('SISTEMA_INICIADO', true);
}

require_once __DIR__ . '/auth.php';
exigir_login();

$u = usuario_logado();
$titulo_pagina = $titulo_pagina ?? 'Painel';
$pagina_ativa  = $pagina_ativa  ?? '';

/* Alerta de estoque baixo mostrado no sino do topo */
$alertas_estoque = bd()->query(
    "SELECT nome, estoque_atual, estoque_minimo, unidade
     FROM produtos
     WHERE ativo = 1 AND estoque_atual <= estoque_minimo
     ORDER BY (estoque_minimo - estoque_atual) DESC
     LIMIT 8"
)->fetchAll();

/* Alerta de propostas expirando (nos proximos 3 dias ou hoje).
   Mesma regra do dashboard: so rascunho/enviado, e o perfil
   "campo" so ve as proprias propostas. */
$paramsExp = [];
$filtroExp = '';
if (!pode('ver_financeiro')) {
    $filtroExp = ' AND o.responsavel_id = :meu_id';
    $paramsExp[':meu_id'] = $u['id'];
}

$stExp = bd()->prepare(
    "SELECT o.id, o.numero, c.nome AS cliente,
            DATEDIFF(
                DATE_ADD(o.data_orcamento, INTERVAL o.validade_dias DAY),
                CURDATE()
            ) AS dias_restantes
     FROM orcamentos o
     JOIN clientes c ON c.id = o.cliente_id
     WHERE o.status IN ('rascunho', 'enviado')
       AND DATE_ADD(o.data_orcamento, INTERVAL o.validade_dias DAY)
           BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 3 DAY)
       $filtroExp
     ORDER BY dias_restantes ASC
     LIMIT 5"
);
$stExp->execute($paramsExp);
$alertas_expirando = $stExp->fetchAll();

$totalAlertas = count($alertas_estoque) + count($alertas_expirando);

$menu = [
    ['Painel',        'index.php',              '&#9632;', 'ver_dashboard'],
    ['Mural',         'mural.php',              '&#9993;', 'ver_dashboard'],
    ['Orcamentos',    'orcamentos_listar.php',  '&#9776;', 'gerir_orcamentos'],
    ['Clientes',      'clientes_listar.php',    '&#9679;', 'gerir_clientes'],
    ['Produtos',      'produtos.php',           '&#9670;', 'gerir_produtos'],
    ['Insumos',       'insumos.php',            '&#9635;', 'gerir_insumos'],
    ['Fornecedores',  'fornecedores.php',       '&#9650;', 'gerir_fornecedores'],
    ['Relatorios',    'relatorios.php',         '&#9653;', 'ver_relatorios'],
    ['Funcionarios',  'funcionarios.php',       '&#9786;', 'gerir_usuarios'],

];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($titulo_pagina) ?> &middot; <?= e(EMPRESA_NOME) ?></title>
<link rel="stylesheet" href="assets/css/estilo.css">
<link rel="icon" href="assets/img/logo-icone.png">
</head>
<body>

<!-- TOPO -->
<header class="topo">
    <button class="botao-menu" id="botaoMenu" aria-label="Abrir menu">&#9776;</button>

    <a href="index.php" class="marca">
        <img src="assets/img/logo-icone.png" alt="" class="marca-icone">
        <span class="marca-texto">
            <strong><?= e(EMPRESA_NOME) ?></strong>
            <small>Gestao de Orcamentos</small>
        </span>
    </a>

    <div class="topo-direita">
        <!-- Sino de alertas -->
        <div class="sino" id="sinoAlertas">
            <button class="sino-botao" aria-label="Alertas">
                &#9888;
                <?php if ($totalAlertas > 0): ?>
                    <span class="sino-contador"><?= $totalAlertas ?></span>
                <?php endif; ?>
            </button>
            <div class="sino-painel" id="sinoPainel" style="max-height:480px;overflow-y:auto">

                <?php if ($alertas_estoque): ?>
                    <h4>Estoque baixo</h4>
                    <ul>
                        <?php foreach ($alertas_estoque as $a): ?>
                            <li>
                                <span><?= e($a['nome']) ?></span>
                                <strong><?= numero($a['estoque_atual']) ?> <?= e($a['unidade']) ?></strong>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                    <a href="produtos.php" class="sino-link">Ver produtos</a>
                <?php endif; ?>

                <?php if ($alertas_expirando): ?>
                    <?php if ($alertas_estoque): ?>
                        <hr style="border:none;border-top:1px solid var(--borda);margin:var(--s-3) 0">
                    <?php endif; ?>
                    <h4 style="color:var(--ambar-600)">Propostas expirando</h4>
                    <ul>
                        <?php foreach ($alertas_expirando as $exp): ?>
                            <li>
                                <span><?= e($exp['numero']) ?> &middot; <?= e($exp['cliente']) ?></span>
                                <strong style="color:var(--ambar-600)">
                                    <?php if ((int) $exp['dias_restantes'] === 0): ?>
                                        hoje
                                    <?php elseif ((int) $exp['dias_restantes'] === 1): ?>
                                        amanha
                                    <?php else: ?>
                                        <?= (int) $exp['dias_restantes'] ?>d
                                    <?php endif; ?>
                                </strong>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                    <a href="orcamentos_listar.php" class="sino-link">Ver orcamentos</a>
                <?php endif; ?>

                <?php if (!$alertas_estoque && !$alertas_expirando): ?>
                    <p class="vazio-mini">Nenhum alerta no momento.</p>
                <?php endif; ?>

            </div>
        </div>

        <!-- Alternador de tema claro/escuro -->
        <button class="botao-tema" id="botaoTema" aria-label="Alternar tema">&#9789;</button>
<!-- Menu do usuario -->
<div class="usuario" id="menuUsuario">
    <button class="usuario-botao">
        <span class="avatar"><?= e(mb_strtoupper(mb_substr($u['nome'], 0, 1))) ?></span>
        <span class="usuario-info">
            <strong>
                <?= e($u['nome']) ?>
                <?php if ((int) ($_SESSION['usuario_2fa'] ?? 0) === 1): ?>
                    <span class="selo selo-verde"
                          style="font-size:9px;padding:1px 6px;margin-left:4px;vertical-align:middle"
                          title="Verificacao em duas etapas ativa">2FA</span>
                <?php endif; ?>
            </strong>
            <small><?= e(rotulo_perfil($u['perfil'])) ?></small>
        </span>
    </button>
    <div class="usuario-painel" id="usuarioPainel">
        <a href="perfil.php">Meu perfil</a>
        <a href="logout.php" class="sair">Sair do sistema</a>
    </div>
</div>
        </div>
    </div>
</header>

<div class="layout">

    <!-- MENU LATERAL -->
    <aside class="lateral" id="menuLateral">
        <nav>
            <ul>
                <?php foreach ($menu as [$rotulo, $arquivo, $icone, $capacidade]): ?>
                    <?php if (!pode($capacidade)) continue; ?>
                    <?php $chave = pathinfo($arquivo, PATHINFO_FILENAME); ?>
                    <li>
                        <a href="<?= e($arquivo) ?>"
                           class="lateral-item <?= $pagina_ativa === $chave ? 'ativo' : '' ?>">
                            <span class="lateral-icone"><?= $icone ?></span>
                            <span><?= e($rotulo) ?></span>
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>
        </nav>

        <div class="lateral-rodape">
            <p><?= e(EMPRESA_NOME) ?></p>
            <small>Versao 2.0</small>
        </div>
    </aside>

    <!-- CONTEUDO -->
    <main class="conteudo">
        <?= flash_exibir() ?>