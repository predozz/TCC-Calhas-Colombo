<?php
// cabecalho das paginas da area do cliente (sem menu lateral, sem
// sino de estoque, sem tema escuro - é uma area mais simples, so
// pra o cliente consultar as propostas dele)

require_once __DIR__ . '/auth_cliente.php';
exigir_login_cliente();

$cli = cliente_atual();
$titulo_pagina = $titulo_pagina ?? 'Minhas propostas';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($titulo_pagina) ?> &middot; <?= e(EMPRESA_NOME) ?></title>
<link rel="stylesheet" href="assets/css/estilo.css">
<link rel="icon" href="assets/img/logo-icone.png">
<style>
    /* Pequenos ajustes so da area do cliente */
    .portal-topo {
        background: var(--laranja-700);
        color: #fff;
        padding: 14px 0;
        box-shadow: var(--sombra-1);
        margin-bottom: var(--s-6);
    }
    .portal-topo .container {
        max-width: 980px;
        margin: 0 auto;
        padding: 0 var(--s-5);
        display: flex;
        align-items: center;
        gap: var(--s-3);
    }
    .portal-topo .logo {
        width: 38px; height: 38px;
        object-fit: cover;
        border-radius: var(--r-md);
        background: #fff;
        padding: 3px;
    }
    .portal-topo .nome-empresa {
        display: flex; flex-direction: column; line-height: 1.2;
    }
    .portal-topo .nome-empresa strong { font-size: 15px; }
    .portal-topo .nome-empresa small  { font-size: 11px; opacity: .85; }
    .portal-topo .direita {
        margin-left: auto;
        display: flex; align-items: center; gap: var(--s-3);
    }
    .portal-topo .direita .cliente-nome {
        font-size: 13px; text-align: right;
    }
    .portal-topo .direita .cliente-nome small {
        display: block; font-size: 11px; opacity: .85;
    }
    .portal-topo .btn-sair {
        color: #fff;
        padding: 6px 12px;
        border: 1px solid rgba(255,255,255,.4);
        border-radius: var(--r-sm);
        font-size: 12px;
        font-weight: 600;
        transition: var(--transicao);
    }
    .portal-topo .btn-sair:hover { background: rgba(255,255,255,.15); }
    .conteudo-portal {
        max-width: 980px;
        margin: 0 auto;
        padding: 0 var(--s-5) var(--s-6);
    }
</style>
</head>
<body style="background:var(--fundo)">

<header class="portal-topo">
    <div class="container">
        <img src="assets/img/logo-icone.png" alt="" class="logo">
        <div class="nome-empresa">
            <strong><?= e(EMPRESA_NOME) ?></strong>
            <small>Area do cliente</small>
        </div>
        <div class="direita">
     <div class="cliente-nome">
        <?= e($cli['nome']) ?>
         <small><?= e($cli['email']) ?></small>
     </div>
          <a href="cliente_logout.php" class="btn-sair">Sair</a>
        </div>
    </div>
</header>

<main class="conteudo-portal">
    <?= flash_exibir() ?>