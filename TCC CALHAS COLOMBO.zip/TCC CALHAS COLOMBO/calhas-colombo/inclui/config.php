<?php
// configuracoes do sistema. se for rodar em outro servidor/xampp,
// só mexer aqui (usuario e senha do banco principalmente)

// ---------- Banco de dados ----------
define('DB_HOST', 'localhost');
define('DB_NOME', 'calhas_colombo');
define('DB_USUARIO', 'root');
define('DB_SENHA', '');          // No XAMPP padrao a senha do root e vazia
define('DB_CHARSET', 'utf8mb4');

// ---------- Envio de e-mail (usado no 2FA) ----------
// Essa senha NAO e a senha normal da conta Gmail. E uma "Senha de app"
// gerada em myaccount.google.com > Seguranca > Senhas de app.
define('SMTP_HOST',    'smtp.gmail.com');
define('SMTP_PORTA',   587);
define('SMTP_USUARIO', 'calhascolombo13@gmail.com'); // <- troca por um email real
define('SMTP_SENHA',   'bpdemxfrfrzottbn');                 // <- troca pela senha de app

// ---------- Dados da empresa (aparecem na proposta impressa) ----------
define('EMPRESA_NOME', 'Calhas Colombo');
define('EMPRESA_SLOGAN', 'Calhas, Rufos e Condutores em Aluminio');
define('EMPRESA_CNPJ', '00.000.000/0001-00');
define('EMPRESA_TELEFONE', '(48) 3433-0000');
define('EMPRESA_WHATSAPP', '48000000000');
define('EMPRESA_EMAIL', 'contato@calhascolombo.com.br');
define('EMPRESA_ENDERECO', 'Rua Industrial, 250 - Centro - Criciuma/SC');

// ---------- Regras de negocio ----------
define('GARANTIA_MESES', 12);
define('VALIDADE_PADRAO_DIAS', 15);
define('DESCONTO_A_VISTA', 5.00);   // % aplicado em Pix / Dinheiro
define('MAO_OBRA_PADRAO', 150.00);

// ---------- Pagamento PIX ----------
// Chave PIX da empresa (e-mail, CNPJ, telefone ou chave aleatoria)
define('PIX_CHAVE', '14700483962'); // <- troca pela chave real
define('PIX_NOME', 'Calhas Colombo'); // Nome do recebedor (max 25 letras)
define('PIX_CIDADE', 'Criciuma');     // Cidade do recebedor (max 15 letras)

// ---------- Ambiente ----------
define('FUSO_HORARIO', 'America/Sao_Paulo');
define('MODO_DEBUG', true);        // true = mostra erros na tela (use so no desenvolvimento)

date_default_timezone_set(FUSO_HORARIO);

if (MODO_DEBUG) {
    ini_set('display_errors', '1');
    error_reporting(E_ALL & ~E_DEPRECATED);
} else {
    ini_set('display_errors', '0');
    error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED);
}