<?php
// envio de e-mail via SMTP. usa PHPMailer porque a funcao mail()
// nativa do PHP nao funciona bem no XAMPP e cai em spam em qualquer
// servidor serio. com o SMTP do Gmail fica confiavel.
//
// pra funcionar: baixar o PHPMailer do GitHub (releases), pegar os
// tres arquivos da pasta src/ (PHPMailer.php, SMTP.php, Exception.php)
// e colocar dentro de uma pasta chamada phpmailer/ na raiz do projeto.
// depois configurar SMTP_USUARIO e SMTP_SENHA no config.php

if (!defined('SMTP_HOST')) {
    die('O arquivo config.php precisa ser carregado antes do email.php.');
}

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once __DIR__ . '/../phpmailer/PHPMailer.php';
require_once __DIR__ . '/../phpmailer/SMTP.php';
require_once __DIR__ . '/../phpmailer/Exception.php';

/**
 * Envia um e-mail em HTML. Retorna true em caso de sucesso.
 */
function enviar_email(string $para, string $assunto, string $corpoHtml): bool
{
    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host       = SMTP_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = SMTP_USUARIO;
        $mail->Password   = SMTP_SENHA;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = SMTP_PORTA;
        $mail->CharSet    = 'UTF-8';

        $mail->setFrom(SMTP_USUARIO, EMPRESA_NOME);
        $mail->addAddress($para);

        $mail->isHTML(true);
        $mail->Subject = $assunto;
        $mail->Body    = $corpoHtml;
        $mail->AltBody = strip_tags($corpoHtml);

        return $mail->send();
    } catch (Exception $e) {
        if (MODO_DEBUG) {
            error_log('Erro ao enviar e-mail: ' . $mail->ErrorInfo);
        }
        return false;
    }
}