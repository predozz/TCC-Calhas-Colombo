<?php
// Gera o payload do PIX Estático (BR Code) conforme manual do Banco Central.

function gerar_payload_pix(float $valor, string $txid = '***'): string
{
    $chave = PIX_CHAVE;
    $nome = substr(preg_replace('/[^A-Za-z0-9 ]/', '', PIX_NOME), 0, 25);
    $cidade = substr(preg_replace('/[^A-Za-z0-9 ]/', '', PIX_CIDADE), 0, 15);

    // 00 - Payload Format Indicator
    $payload = '000201';

    // 26 - Merchant Account Information
    $guia = '0014br.gov.bcb.pix';
    $chaveFormatada = '01' . sprintf('%02d', strlen($chave)) . $chave;
    $merchantAccount = $guia . $chaveFormatada;
    $payload .= '26' . sprintf('%02d', strlen($merchantAccount)) . $merchantAccount;

    // 52 - Merchant Category Code
    $payload .= '52040000';

    // 53 - Transaction Currency (986 = BRL)
    $payload .= '5303986';

    // 54 - Transaction Amount
    if ($valor > 0) {
        $valorFormatado = number_format($valor, 2, '.', '');
        $payload .= '54' . sprintf('%02d', strlen($valorFormatado)) . $valorFormatado;
    }

    // 58 - Country Code
    $payload .= '5802BR';

    // 59 - Merchant Name
    $payload .= '59' . sprintf('%02d', strlen($nome)) . $nome;

    // 60 - Merchant City
    $payload .= '60' . sprintf('%02d', strlen($cidade)) . $cidade;

    // 62 - Additional Data Field (txid)
    $txid = substr(preg_replace('/[^A-Za-z0-9]/', '', $txid), 0, 25);
    if ($txid === '') $txid = '***';
    
    $txidFormatado = '05' . sprintf('%02d', strlen($txid)) . $txid;
    $payload .= '62' . sprintf('%02d', strlen($txidFormatado)) . $txidFormatado;

    // 63 - CRC16
    $payload .= '6304';
    $payload .= crc16($payload);

    return $payload;
}

function crc16(string $payload): string
{
    $polinomio = 0x1021;
    $resultado = 0xFFFF;

    for ($i = 0; $i < strlen($payload); $i++) {
        $resultado ^= (ord($payload[$i]) << 8);
        for ($j = 0; $j < 8; $j++) {
            if ($resultado & 0x8000) {
                $resultado = (($resultado << 1) ^ $polinomio) & 0xFFFF;
            } else {
                $resultado = ($resultado << 1) & 0xFFFF;
            }
        }
    }

    return strtoupper(str_pad(dechex($resultado), 4, '0', STR_PAD_LEFT));
}