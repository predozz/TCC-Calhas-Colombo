</main>

<footer style="text-align:center;padding:24px;font-size:12px;color:var(--texto-suave)">
    &copy; <?= date('Y') ?> <?= e(EMPRESA_NOME) ?> &middot; Todos os direitos reservados
</footer>

</body>
</html>