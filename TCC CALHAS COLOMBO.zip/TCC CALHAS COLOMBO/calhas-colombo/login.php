<?php
require_once __DIR__ . '/inclui/auth.php';

if (esta_logado()) {
    redirecionar('index.php');
}

$erro  = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validar();

    $email = trim($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';

    if ($email === '' || $senha === '') {
        $erro = 'Informe o e-mail e a senha.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $erro = 'O e-mail informado nao e valido.';
    } else {
        $usuario = validar_credenciais($email, $senha);

        if (!$usuario) {
            $erro = 'E-mail ou senha incorretos.';
        } elseif ((int) $usuario['two_factor_ativo'] === 1) {
            // 2FA ativo: gera codigo, envia por e-mail e redireciona
            require_once __DIR__ . '/inclui/email.php';

            $codigo = gerar_codigo_2fa((int) $usuario['id']);

            $corpo = "
                <div style='font-family:sans-serif;max-width:520px;margin:0 auto;
                            padding:20px;background:#f4f6fa;border-radius:12px'>
                    <div style='background:#fff;padding:32px;border-radius:10px'>
                        <h2 style='color:#e07c12;margin:0 0 20px'>" . e(EMPRESA_NOME) . "</h2>
                        <p style='color:#334155'>Ola " . e($usuario['nome']) . ",</p>
                        <p style='color:#334155'>Seu codigo de verificacao para entrar no sistema e:</p>
                        <div style='font-size:34px;font-weight:bold;letter-spacing:10px;
                                    text-align:center;background:#fdf3e4;padding:22px;
                                    border-radius:10px;color:#b35f0d;font-family:monospace;
                                    margin:24px 0'>$codigo</div>
                        <p style='color:#64748b;font-size:13px;margin-top:24px'>
                            O codigo vale por 10 minutos. Se voce nao tentou entrar no
                            sistema, ignore este e-mail.
                        </p>
                    </div>
                </div>
            ";

            if (enviar_email($usuario['email'], 'Codigo de verificacao - ' . EMPRESA_NOME, $corpo)) {
                $_SESSION['2fa_usuario_id'] = (int) $usuario['id'];
                $_SESSION['2fa_email']      = $usuario['email'];
                redirecionar('verificar_2fa.php');
            } else {
                $erro = 'Nao foi possivel enviar o e-mail com o codigo. Tente novamente em alguns instantes.';
            }
        } else {
            // Sem 2FA: loga direto
            efetivar_login($usuario);

            try {
                $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
                $stLog = bd()->prepare(
                    "INSERT INTO logs_sistema (usuario_id, acao, tabela_afetada, descricao, ip_endereco)
                     VALUES (?, 'LOGIN', 'login', 'Efetuou login no sistema', ?)"
                );
                $stLog->execute([$usuario['id'], $ip]);
            } catch (Exception $e) {
                // silencia
            }

            flash('sucesso', 'Bem-vindo de volta, ' . $usuario['nome'] . '!');
            redirecionar('index.php');
        }
    }
}

$contas_demo = [
    ['email' => '4553517980@estudante.sed.sc.gov.br', 'senha' => 'admin123', 'perfil' => 'Administrador'],
    ['email' => 'gerente@colombo.com', 'senha' => 'gerente123', 'perfil' => 'Gerente'],
    ['email' => 'caua@colombo.com',    'senha' => '123456',     'perfil' => 'Tecnico de Campo'],
];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Entrar &middot; <?= e(EMPRESA_NOME) ?></title>
<link rel="stylesheet" href="assets/css/estilo.css">
</head>
<body class="pagina-login">

<div class="caixa-login">

    <div class="login-topo">
        <img src="assets/img/logo-icone.png" alt="" class="login-logo">
        <h1><?= e(EMPRESA_NOME) ?></h1>
        <p>Sistema de Gestao de Orcamentos</p>
    </div>

    <div class="login-corpo">

        <?php if ($erro): ?>
            <div class="alerta alerta-erro">
                <span class="alerta-icone">&#33;</span>
                <span><?= e($erro) ?></span>
            </div>
        <?php endif; ?>

        <?= flash_exibir() ?>

        <form method="POST" autocomplete="on">
            <?= csrf_campo() ?>

            <div class="campo">
                <label for="email">E-mail</label>
                <input type="email" id="email" name="email"
                       value="<?= e($email) ?>"
                       placeholder="seu@email.com" required autofocus>
            </div>

            <div class="campo">
                <label for="senha">Senha</label>
                <input type="password" id="senha" name="senha"
                       placeholder="Digite sua senha" required>
            </div>

                        <button type="submit" class="botao botao-primario botao-bloco botao-g">Entrar</button>
        </form>

        <p style="text-align:center;margin-top:16px;font-size:13px">
            <a href="esqueci_senha.php" style="color:var(--texto-suave)">Esqueci minha senha</a>
        </p>

        <div class="contas-demo">
            <h5>Contas para teste &mdash; clique para preencher</h5>
            <?php foreach ($contas_demo as $c): ?>
                <div class="conta-demo"
                     data-demo-email="<?= e($c['email']) ?>"
                     data-demo-senha="<?= e($c['senha']) ?>">
                    <span><?= e($c['email']) ?></span>
                    <code><?= e($c['perfil']) ?></code>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="login-rodape">
        &copy; <?= date('Y') ?> <?= e(EMPRESA_NOME) ?> &middot; Todos os direitos reservados
    </div>
</div>

<script src="assets/js/app.js"></script>
</body>
</html>