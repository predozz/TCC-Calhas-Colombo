<?php
require_once __DIR__ . '/inclui/auth.php';

// Obtém os dados do usuário antes de encerrar a sessão
$u = usuario_logado();

if ($u) {
    try {
        $pdo = bd();
        $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
        $dados = json_encode(['mensagem' => 'Efetuou logout do sistema'], JSON_UNESCAPED_UNICODE);

        $stLog = $pdo->prepare(
            "INSERT INTO logs_sistema (usuario_id, acao, tabela_afetada, dados_novos, ip_endereco) 
             VALUES (?, 'LOGOUT', 'login', ?, ?)"
        );
        $stLog->execute([$u['id'], $dados, $ip]);
    } catch (Exception $e) {
        // Silencia erro se a tabela de logs falhar
    }
}

// Limpa e encerra a sessão
$_SESSION = [];

if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

if (session_status() === PHP_SESSION_ACTIVE) {
    session_destroy();
}

// Redireciona diretamente para a tela de login
header('Location: login.php');
exit;