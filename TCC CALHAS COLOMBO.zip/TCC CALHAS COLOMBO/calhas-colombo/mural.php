<?php
// mural da equipe - um feed simples onde todo mundo deixa recado.
// nao e chat em tempo real, e mais tipo um grupo interno: recado
// fica registrado, ninguem precisa sair do sistema pra combinar nada
// e da pra ver depois quem falou o que e quando
//
// Na parte de baixo tem a agenda de instalacoes do mes (calendario
// compacto com modal de detalhes e navegacao entre meses).
//
// O parametro "mes_agenda" e separado de "pagina" pra nao dar
// conflito. E os links da agenda levam "#agendaMural" no final:
// assim, quando o usuario muda de mes, o navegador ja rola direto
// pra agenda em vez de voltar pro topo da pagina.
//
// Sobre o scroll: o estilo.css global tem "scroll-behavior:smooth"
// em html. Isso e bonito nos links normais, mas aqui ficou ruim
// (a pagina deslizava a cada clique no mes). Por isso forcamos
// "auto" so nesta pagina - o pulo e instantaneo.

require_once __DIR__ . '/inclui/auth.php';
exigir_login();

$u = usuario_logado();
$pdo = bd();

$podeFixar = $u['perfil'] === 'admin' || $u['perfil'] === 'gerente';

// ---------------------------------------------------------------------
// Postar recado
// ---------------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['acao'] ?? '') === 'postar') {
    csrf_validar();

    $mensagem = trim($_POST['mensagem'] ?? '');

    if ($mensagem === '') {
        flash('erro', 'Escreve alguma coisa antes de mandar.');
    } elseif (mb_strlen($mensagem) > 2000) {
        flash('erro', 'O recado ficou grande demais. Tenta resumir em ate 2000 caracteres.');
    } else {
        $pdo->prepare(
            "INSERT INTO mural_mensagens (usuario_id, mensagem) VALUES (:u, :m)"
        )->execute([':u' => $u['id'], ':m' => $mensagem]);

        registrar_log('PUBLICAR', 'mural_mensagens',
            ['mensagem' => 'Publicou recado no mural da equipe']);

        flash('sucesso', 'Recado publicado.');
    }
    redirecionar('mural.php');
}

// ---------------------------------------------------------------------
// Fixar / desafixar (so admin e gerente)
// ---------------------------------------------------------------------
if (isset($_GET['fixar'])) {
    if (!$podeFixar) {
        flash('erro', 'So admin ou gerente pode fixar recado.');
        redirecionar('mural.php');
    }
    if (!hash_equals($_SESSION['csrf_token'] ?? '', $_GET['csrf'] ?? '')) {
        flash('erro', 'Requisicao invalida.');
        redirecionar('mural.php');
    }

    $mid = (int) $_GET['fixar'];
    $st  = $pdo->prepare("SELECT fixada, mensagem FROM mural_mensagens WHERE id = :id");
    $st->execute([':id' => $mid]);
    $msg = $st->fetch();

    if ($msg) {
        $novo = $msg['fixada'] ? 0 : 1;
        $pdo->prepare("UPDATE mural_mensagens SET fixada = :f WHERE id = :id")
            ->execute([':f' => $novo, ':id' => $mid]);

        registrar_log('EDITAR', 'mural_mensagens', [
            'mensagem' => $novo ? 'Fixou um recado no mural' : 'Desafixou um recado do mural',
            'id' => $mid,
        ]);
    }
    redirecionar('mural.php');
}

// ---------------------------------------------------------------------
// Apagar - autor apaga o proprio, admin apaga qualquer um
// ---------------------------------------------------------------------
if (isset($_GET['apagar'])) {
    if (!hash_equals($_SESSION['csrf_token'] ?? '', $_GET['csrf'] ?? '')) {
        flash('erro', 'Requisicao invalida.');
        redirecionar('mural.php');
    }

    $mid = (int) $_GET['apagar'];

    $st = $pdo->prepare("SELECT usuario_id, mensagem FROM mural_mensagens WHERE id = :id");
    $st->execute([':id' => $mid]);
    $msg = $st->fetch();

    if (!$msg) {
        flash('erro', 'Recado nao encontrado.');
        redirecionar('mural.php');
    }

    $ehDono  = (int) $msg['usuario_id'] === (int) $u['id'];
    $ehAdmin = $u['perfil'] === 'admin';

    if (!$ehDono && !$ehAdmin) {
        flash('erro', 'Voce so pode apagar os seus proprios recados.');
        redirecionar('mural.php');
    }

    $pdo->prepare("DELETE FROM mural_mensagens WHERE id = :id")->execute([':id' => $mid]);

    registrar_log('EXCLUIR', 'mural_mensagens', [
        'mensagem' => 'Apagou um recado do mural',
        'trecho' => mb_substr($msg['mensagem'], 0, 80),
    ]);

    flash('sucesso', 'Recado apagado.');
    redirecionar('mural.php');
}

// ---------------------------------------------------------------------
// Listagem (fixadas sempre em cima)
// ---------------------------------------------------------------------
$pagina    = max(1, (int) ($_GET['pagina'] ?? 1));
$porPagina = 5;

$total = (int) $pdo->query("SELECT COUNT(*) FROM mural_mensagens")->fetchColumn();
$totalPaginas = max(1, (int) ceil($total / $porPagina));
$pagina = min($pagina, $totalPaginas);
$inicio = ($pagina - 1) * $porPagina;

$st = $pdo->prepare(
    "SELECT m.*, us.nome AS autor, us.perfil AS autor_perfil
     FROM mural_mensagens m
     JOIN usuarios us ON us.id = m.usuario_id
     ORDER BY m.fixada DESC, m.data_postagem DESC
     LIMIT $porPagina OFFSET $inicio"
);
$st->execute();
$mensagens = $st->fetchAll();

// ---------------------------------------------------------------------
// Agenda de instalacoes do mes (mostrada no fim da pagina)
// ---------------------------------------------------------------------
$agMesParam = $_GET['mes_agenda'] ?? date('Y-m');
if (!preg_match('/^\d{4}-\d{2}$/', $agMesParam)) {
    $agMesParam = date('Y-m');
}

$agPrimeiro = $agMesParam . '-01';
$agUltimo   = date('Y-m-t', strtotime($agPrimeiro));
$agHoje     = date('Y-m-d');

$agMesAnterior = date('Y-m', strtotime($agPrimeiro . ' -1 month'));
$agMesProximo  = date('Y-m', strtotime($agPrimeiro . ' +1 month'));
$agEhMesAtual  = $agMesParam === date('Y-m');

$agParams = [':de' => $agPrimeiro, ':ate' => $agUltimo];
$agFiltro = '';
if (!pode('ver_financeiro')) {
    $agFiltro = ' AND o.responsavel_id = :meu_id';
    $agParams[':meu_id'] = $u['id'];
}

$stAg = $pdo->prepare(
    "SELECT o.id, o.numero, o.status, o.data_entrega_prevista,
            c.nome AS cliente, c.telefone AS cliente_telefone,
            c.endereco, c.numero AS cliente_numero, c.bairro, c.cidade, c.uf,
            us.nome AS responsavel
     FROM orcamentos o
     JOIN clientes c ON c.id = o.cliente_id
     JOIN usuarios us ON us.id = o.responsavel_id
     WHERE o.data_entrega_prevista BETWEEN :de AND :ate
       AND o.status IN ('aprovado', 'em_producao', 'concluido')
       $agFiltro
     ORDER BY o.data_entrega_prevista ASC"
);
$stAg->execute($agParams);
$agInstalacoes = $stAg->fetchAll();

$agPorDia = [];
foreach ($agInstalacoes as $inst) {
    $dia = (int) date('j', strtotime($inst['data_entrega_prevista']));
    $agPorDia[$dia][] = $inst;
}

$agDiasNoMes = (int) date('t', strtotime($agPrimeiro));
$agDiaInicio = (int) date('w', strtotime($agPrimeiro));

$agMesesNome = [
    1 => 'Janeiro', 2 => 'Fevereiro', 3 => 'Marco', 4 => 'Abril',
    5 => 'Maio', 6 => 'Junho', 7 => 'Julho', 8 => 'Agosto',
    9 => 'Setembro', 10 => 'Outubro', 11 => 'Novembro', 12 => 'Dezembro',
];
$agTitulo = $agMesesNome[(int) date('n', strtotime($agPrimeiro))]
          . ' de ' . date('Y', strtotime($agPrimeiro));

$agCores = [
    'aprovado'    => 'var(--ambar-500)',
    'em_producao' => 'var(--roxo-600)',
    'concluido'   => 'var(--verde-500)',
];

$titulo_pagina = 'Mural da equipe';
$pagina_ativa  = 'mural';
require_once __DIR__ . '/inclui/cabecalho.php';
?>

<style>
    /* Desabilita o scroll suave so nesta pagina.
       O estilo.css global tem "scroll-behavior:smooth" em html,
       o que fazia a pagina deslizar a cada clique no mes. Aqui
       forcamos "auto" pra o pulo ser instantaneo. */
    html { scroll-behavior: auto !important; }

    /* Calendario compacto - usado so na agenda do mural */
    .calendario { display:grid; grid-template-columns:repeat(7,1fr); gap:3px; }
    .calendario-semana {
        padding:6px 2px; text-align:center;
        font-size:10px; font-weight:700;
        text-transform:uppercase; letter-spacing:.4px;
        color:var(--texto-suave);
    }
    .calendario-celula {
        position:relative; min-height:60px; padding:5px;
        background:var(--superficie); border:1px solid var(--borda);
        border-radius:var(--r-sm); transition:var(--transicao);
    }
    .calendario-celula.vazia { background:transparent; border-color:transparent; }
    .calendario-celula.hoje {
        border-color:var(--laranja-600); background:var(--laranja-50);
        box-shadow:0 0 0 2px var(--laranja-100);
    }
    .calendario-celula.tem-instalacao { cursor:pointer; }
    .calendario-celula.tem-instalacao:hover {
        background:var(--laranja-50); border-color:var(--laranja-500);
        transform:translateY(-1px); box-shadow:var(--sombra-2);
    }
    .calendario-dia-numero {
        font-size:12px; font-weight:700; color:var(--texto); line-height:1;
    }
    .calendario-celula.hoje .calendario-dia-numero { color:var(--laranja-700); }
    .calendario-badges { display:flex; flex-wrap:wrap; gap:3px; margin-top:4px; }
    .calendario-badge {
        display:inline-block; width:7px; height:7px; border-radius:50%;
    }
    .calendario-mais {
        font-size:9px; font-weight:700; color:var(--texto-suave); align-self:center;
    }
    .calendario-total {
        position:absolute; bottom:3px; right:5px;
        font-size:9px; font-weight:700; color:var(--texto-suave);
        background:var(--superficie-2); padding:0 3px; border-radius:3px;
    }
    .calendario-legenda {
        display:flex; flex-wrap:wrap; gap:14px; margin-top:14px;
        padding-top:14px; border-top:1px solid var(--borda);
        font-size:11px; color:var(--texto-suave);
    }
    .calendario-legenda span { display:inline-flex; align-items:center; gap:5px; }
    .calendario-legenda i {
        display:inline-block; width:9px; height:9px; border-radius:50%;
    }
    .calendario-legenda .legenda-hoje {
        background:var(--laranja-50); border:1px solid var(--laranja-600);
    }

    /* Navegacao de mes */
    .agenda-nav {
        display:flex; align-items:center; gap:8px; flex-wrap:wrap;
    }
    .agenda-nav-titulo {
        min-width:170px; text-align:center;
        font-size:14px; font-weight:600;
    }

    /* Margem pro scroll da ancora nao esconder o titulo embaixo do
       header fixo (que tem 64px de altura) */
    #agendaMural { scroll-margin-top: 80px; }

    /* Modal do dia */
    .modal-dia {
        border:1px solid var(--borda); border-radius:var(--r-lg); padding:0;
        max-width:560px; width:calc(100% - 32px);
        background:var(--superficie); color:var(--texto);
        box-shadow:var(--sombra-3);
    }
    .modal-dia::backdrop { background:rgba(15,23,42,.55); }
    .modal-dia-cabecalho {
        display:flex; align-items:center; justify-content:space-between;
        padding:var(--s-4) var(--s-5); border-bottom:1px solid var(--borda);
        background:var(--superficie-2);
    }
    .modal-dia-cabecalho h3 { font-size:15px; font-weight:600; }
    .modal-dia-fechar {
        font-size:22px; line-height:1; color:var(--texto-suave);
        padding:0 4px; background:none; border:none; cursor:pointer;
    }
    .modal-dia-fechar:hover { color:var(--vermelho-600); }
    .modal-dia-corpo {
        padding:var(--s-5); max-height:65vh; overflow-y:auto;
    }
    .modal-dia-item {
        padding:12px 0; border-bottom:1px solid var(--borda);
    }
    .modal-dia-item:last-child { border-bottom:none; padding-bottom:0; }
    .modal-dia-item:first-child { padding-top:0; }
    .modal-dia-item-topo {
        display:flex; align-items:center; justify-content:space-between;
        gap:12px; margin-bottom:6px; flex-wrap:wrap;
    }
    .modal-dia-item-numero {
        font-family:var(--fonte-mono); font-weight:700; font-size:13px;
    }
    .modal-dia-item-cliente { font-weight:600; font-size:14px; }
    .modal-dia-item-info {
        font-size:12px; color:var(--texto-suave); margin-top:2px;
    }
    .modal-dia-item-acoes { margin-top:10px; display:flex; gap:6px; flex-wrap:wrap; }

    @media (max-width:560px) {
        .calendario-celula { min-height:52px; padding:4px; }
        .calendario-badge { width:6px; height:6px; }
        .calendario-total { display:none; }
    }
</style>

<div class="pagina-topo">
    <div>
        <h1 class="pagina-titulo">Mural da equipe</h1>
        <p class="pagina-subtitulo">
            <?= $total ?> recado(s) &middot; aqui a equipe combina as coisas do dia a dia
        </p>
    </div>
</div>

<div class="grade-2">

    <!-- FORM DE NOVO RECADO -->
    <div class="cartao" style="align-self:start">
        <div class="cartao-cabecalho"><h3>Deixar um recado</h3></div>
        <div class="cartao-corpo">
            <form method="POST">
                <?= csrf_campo() ?>
                <input type="hidden" name="acao" value="postar">

                <div class="campo col-12">
                    <textarea name="mensagem" rows="5" maxlength="2000" required
                              placeholder="Ex: Amanha vou passar na obra da dona Cida as 8h. Se alguem tiver alguma duvida sobre a medida da calha lateral, me chama antes."></textarea>
                    <span class="campo-dica">Fica registrado com seu nome e a hora. Maximo 2000 caracteres.</span>
                </div>

                <div class="formulario-acoes">
                    <button type="submit" class="botao botao-sucesso">Publicar recado</button>
                </div>
            </form>
        </div>
    </div>

    <!-- FEED -->
    <div class="cartao">
        <div class="cartao-cabecalho">
            <h3>Recados recentes</h3>
        </div>
        <div class="cartao-corpo">
            <?php if ($mensagens): ?>
                <?php foreach ($mensagens as $m): ?>
                    <?php
                    $ehDono  = (int) $m['usuario_id'] === (int) $u['id'];
                    $ehAdmin = $u['perfil'] === 'admin';
                    $podeApagar = $ehDono || $ehAdmin;
                    $corPerfil = [
                        'admin' => 'var(--vermelho-500)', 'gerente' => 'var(--roxo-600)',
                        'calheiro' => 'var(--laranja-600)', 'campo' => 'var(--texto-suave)',
                    ][$m['autor_perfil']] ?? 'var(--texto-suave)';
                    ?>
                    <div style="display:flex;gap:12px;padding:14px 0;border-bottom:1px solid var(--borda);
                                <?= $m['fixada'] ? 'background:var(--laranja-50);margin:0 -20px;padding:14px 20px;border-radius:var(--r-md);border-bottom:none;margin-bottom:10px' : '' ?>">

                        <span class="avatar" style="background:<?= $corPerfil ?>">
                            <?= e(mb_strtoupper(mb_substr($m['autor'], 0, 1))) ?>
                        </span>

                        <div style="flex:1;min-width:0">
                            <div style="display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap;align-items:center">
                                <div>
                                    <strong style="font-size:14px"><?= e($m['autor']) ?></strong>
                                    <span class="txt-p txt-suave"> &middot; <?= e(rotulo_perfil($m['autor_perfil'])) ?></span>
                                    <?php if ($m['fixada']): ?>
                                        <span class="selo selo-laranja" style="margin-left:6px">Fixado</span>
                                    <?php endif; ?>
                                </div>
                                <div class="txt-p txt-suave" style="white-space:nowrap">
                                    <?= data_br($m['data_postagem'], true) ?>
                                </div>
                            </div>

                            <p style="margin-top:6px;font-size:14px;white-space:pre-wrap;word-wrap:break-word"><?= e($m['mensagem']) ?></p>

                            <div style="margin-top:8px;display:flex;gap:6px;flex-wrap:wrap">
                                <?php if ($podeFixar): ?>
                                    <a href="?fixar=<?= (int) $m['id'] ?>&csrf=<?= csrf_token() ?>"
                                       class="botao botao-neutro botao-p">
                                        <?= $m['fixada'] ? 'Desafixar' : 'Fixar' ?>
                                    </a>
                                <?php endif; ?>
                                <?php if ($podeApagar): ?>
                                    <a href="?apagar=<?= (int) $m['id'] ?>&csrf=<?= csrf_token() ?>"
                                       class="botao botao-perigo botao-p"
                                       data-confirmar="Apagar este recado?">Apagar</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="vazio">
                    <div class="vazio-icone">&#9993;</div>
                    <h4>Nenhum recado ainda</h4>
                    <p>Seja o primeiro a deixar um recado para a equipe.</p>
                </div>
            <?php endif; ?>

            <?php if ($totalPaginas > 1): ?>
                <div class="flex entre alinha-centro quebra g3 mt3">
                    <span class="txt-p txt-suave">Pagina <?= $pagina ?> de <?= $totalPaginas ?></span>
                    <div class="flex g2">
                        <?php if ($pagina > 1): ?>
                            <a href="?pagina=<?= $pagina - 1 ?>&mes_agenda=<?= e($agMesParam) ?>"
                               class="botao botao-neutro botao-p">Mais recentes</a>
                        <?php endif; ?>
                        <?php if ($pagina < $totalPaginas): ?>
                            <a href="?pagina=<?= $pagina + 1 ?>&mes_agenda=<?= e($agMesParam) ?>"
                               class="botao botao-neutro botao-p">Mais antigos</a>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- AGENDA DE INSTALACOES -->
<div class="cartao" id="agendaMural" style="margin-top:var(--s-5)">
    <div class="cartao-cabecalho">
        <div>
            <h3>Agenda de instalacoes</h3>
            <div class="txt-p txt-suave mt1">
                <?= count($agInstalacoes) ?> instalacao(oes) no mes
            </div>
        </div>
        <div class="agenda-nav">
            <a href="?pagina=<?= $pagina ?>&mes_agenda=<?= e($agMesAnterior) ?>#agendaMural"
               class="botao botao-neutro botao-p" title="Mes anterior">&larr;</a>
            <span class="agenda-nav-titulo"><?= e($agTitulo) ?></span>
            <a href="?pagina=<?= $pagina ?>&mes_agenda=<?= e($agMesProximo) ?>#agendaMural"
               class="botao botao-neutro botao-p" title="Proximo mes">&rarr;</a>
            <?php if (!$agEhMesAtual): ?>
                <a href="?pagina=<?= $pagina ?>&mes_agenda=<?= date('Y-m') ?>#agendaMural"
                   class="botao botao-contorno botao-p">Ir para hoje</a>
            <?php endif; ?>
        </div>
    </div>
    <div class="cartao-corpo" style="padding:var(--s-4)">
        <div class="calendario">
            <div class="calendario-semana">Dom</div>
            <div class="calendario-semana">Seg</div>
            <div class="calendario-semana">Ter</div>
            <div class="calendario-semana">Qua</div>
            <div class="calendario-semana">Qui</div>
            <div class="calendario-semana">Sex</div>
            <div class="calendario-semana">Sab</div>

            <?php for ($i = 0; $i < $agDiaInicio; $i++): ?>
                <div class="calendario-celula vazia"></div>
            <?php endfor; ?>

            <?php for ($dia = 1; $dia <= $agDiasNoMes; $dia++): ?>
                <?php
                $dataCompleta = sprintf('%s-%02d', $agMesParam, $dia);
                $ehHoje  = ($dataCompleta === $agHoje);
                $doDia   = $agPorDia[$dia] ?? [];
                $temInst = !empty($doDia);
                ?>
                <div class="calendario-celula <?= $ehHoje ? 'hoje' : '' ?> <?= $temInst ? 'tem-instalacao' : '' ?>"
                     <?= $temInst ? 'onclick="abrirDia(' . $dia . ')" role="button" tabindex="0" onkeydown="if(event.key===\'Enter\')abrirDia(' . $dia . ')"' : '' ?>>

                    <div class="calendario-dia-numero"><?= $dia ?></div>

                    <?php if ($temInst): ?>
                        <div class="calendario-badges">
                            <?php
                            $cont = 0;
                            foreach ($doDia as $inst):
                                if ($cont >= 3) break;
                                $cor = $agCores[$inst['status']] ?? 'var(--texto-suave)';
                            ?>
                                <span class="calendario-badge" style="background:<?= $cor ?>"></span>
                            <?php
                                $cont++;
                            endforeach;
                            if (count($doDia) > 3):
                            ?>
                                <span class="calendario-mais">+<?= count($doDia) - 3 ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="calendario-total"><?= count($doDia) ?></div>
                    <?php endif; ?>
                </div>
            <?php endfor; ?>

            <?php
            $totalCelulas = $agDiaInicio + $agDiasNoMes;
            $restantes = (7 - ($totalCelulas % 7)) % 7;
            for ($i = 0; $i < $restantes; $i++):
            ?>
                <div class="calendario-celula vazia"></div>
            <?php endfor; ?>
        </div>

        <div class="calendario-legenda">
            <span><i style="background:var(--ambar-500)"></i> Aguardando inicio</span>
            <span><i style="background:var(--roxo-600)"></i> Em producao</span>
            <span><i style="background:var(--verde-500)"></i> Concluido</span>
            <span><i class="legenda-hoje"></i> Hoje</span>
        </div>

        <?php if (!$agInstalacoes): ?>
            <p class="txt-p txt-suave txt-centro" style="margin-top:16px">
                Nenhuma instalacao programada para este mes.
            </p>
        <?php endif; ?>
    </div>
</div>

<!-- MODAL DE DETALHES DO DIA -->
<dialog id="modalDia" class="modal-dia">
    <header class="modal-dia-cabecalho">
        <h3 id="modalDiaTitulo">Instalacoes do dia</h3>
        <button type="button" onclick="document.getElementById('modalDia').close()"
                class="modal-dia-fechar" aria-label="Fechar">&times;</button>
    </header>
    <div id="modalDiaCorpo" class="modal-dia-corpo"></div>
</dialog>

<!-- Dados das instalacoes por dia (JSON, usado pelo JS do modal) -->
<script>
window.INSTALACOES_DIA = <?= json_encode($agPorDia, JSON_UNESCAPED_UNICODE) ?>;
window.MES_ATUAL_AGENDA = <?= json_encode($agMesParam) ?>;
</script>

<script>
// Recarrega a pagina a cada 30s pra buscar recados novos, MAS:
//   - nao recarrega se o cara ta digitando
//   - nao recarrega se a aba nao ta visivel
//   - nao recarrega se ele desceu pra ver a agenda
setTimeout(function () {
    var campo = document.querySelector('textarea[name="mensagem"]');
    if (campo && campo.value.trim() !== '') return;
    if (document.hidden) return;

    var agendaBox = document.getElementById('agendaMural');
    if (agendaBox) {
        var rect = agendaBox.getBoundingClientRect();
        if (rect.top < window.innerHeight) return;
    }

    location.reload();
}, 30000);

(function () {
    'use strict';

    var MESES = ['Janeiro','Fevereiro','Marco','Abril','Maio','Junho',
                 'Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];

    function escapar(txt) {
        var div = document.createElement('div');
        div.textContent = txt || '';
        return div.innerHTML;
    }

    function rotuloStatus(s) {
        return {
            'aprovado': 'Aprovado',
            'em_producao': 'Em producao',
            'concluido': 'Concluido'
        }[s] || s;
    }

    function corStatus(s) {
        return {
            'aprovado': 'var(--ambar-500)',
            'em_producao': 'var(--roxo-600)',
            'concluido': 'var(--verde-500)'
        }[s] || 'var(--texto-suave)';
    }

    window.abrirDia = function (dia) {
        var instalacoes = (window.INSTALACOES_DIA || {})[dia] || [];
        if (!instalacoes.length) return;

        var partes = window.MES_ATUAL_AGENDA.split('-');
        var mesNome = MESES[parseInt(partes[1], 10) - 1];
        var titulo = 'Dia ' + dia + ' de ' + mesNome;
        titulo += ' &middot; ' + instalacoes.length +
                  (instalacoes.length === 1 ? ' instalacao' : ' instalacoes');

        document.getElementById('modalDiaTitulo').innerHTML = titulo;

        var html = instalacoes.map(function (i) {
            var endereco = i.endereco || '';
            if (i.cliente_numero) endereco += ', ' + i.cliente_numero;
            var cidade = [i.bairro, i.cidade + '/' + i.uf].filter(Boolean).join(' - ');

            return '<div class="modal-dia-item">' +
                '<div class="modal-dia-item-topo">' +
                    '<div>' +
                        '<div class="modal-dia-item-numero">' + escapar(i.numero) + '</div>' +
                        '<div class="modal-dia-item-cliente">' + escapar(i.cliente) + '</div>' +
                    '</div>' +
                    '<span class="selo" style="background:' + corStatus(i.status) + ';color:#fff">' +
                        escapar(rotuloStatus(i.status)) +
                    '</span>' +
                '</div>' +
                '<div class="modal-dia-item-info">' +
                    escapar(endereco) +
                    (cidade ? '<br>' + escapar(cidade) : '') +
                '</div>' +
                '<div class="modal-dia-item-info">' +
                    'Responsavel: ' + escapar(i.responsavel || '-') +
                    (i.cliente_telefone ? ' &middot; ' + escapar(i.cliente_telefone) : '') +
                '</div>' +
                '<div class="modal-dia-item-acoes">' +
                    '<a href="orcamentos_detalhes.php?id=' + parseInt(i.id, 10) + '" ' +
                       'class="botao botao-primario botao-p">Ver proposta</a>' +
                '</div>' +
            '</div>';
        }).join('');

        document.getElementById('modalDiaCorpo').innerHTML = html;
        document.getElementById('modalDia').showModal();
    };
})();
</script>

<?php require_once __DIR__ . '/inclui/rodape.php'; ?>