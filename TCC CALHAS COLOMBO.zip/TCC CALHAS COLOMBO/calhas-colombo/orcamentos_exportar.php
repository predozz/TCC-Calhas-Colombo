<?php
// exporta a lista de orcamentos em CSV respeitando os filtros
// da tela e a regra de permissao (perfil operacional so exporta
// os proprios orcamentos, igual acontece na listagem).

require_once __DIR__ . '/inclui/auth.php';
exigir_permissao('gerir_orcamentos');

$u   = usuario_logado();
$pdo = bd();
$verFinanceiro = pode('ver_financeiro');

// Mesmos filtros da listagem
$busca  = trim($_GET['busca'] ?? '');
$status = trim($_GET['status'] ?? '');
$de     = trim($_GET['de'] ?? '');
$ate    = trim($_GET['ate'] ?? '');

$where  = ['1=1'];
$params = [];

if ($busca !== '') {
    $where[] = '(o.numero LIKE :busca OR c.nome LIKE :busca OR c.telefone LIKE :busca)';
    $params[':busca'] = '%' . $busca . '%';
}
if ($status !== '' && array_key_exists($status, status_orcamento())) {
    $where[] = 'o.status = :status';
    $params[':status'] = $status;
}
if ($de !== '') {
    $where[] = 'DATE(o.data_orcamento) >= :de';
    $params[':de'] = $de;
}
if ($ate !== '') {
    $where[] = 'DATE(o.data_orcamento) <= :ate';
    $params[':ate'] = $ate;
}

/* Perfis operacionais exportam apenas os proprios orcamentos */
if (!$verFinanceiro) {
    $where[] = 'o.responsavel_id = :meu_id';
    $params[':meu_id'] = $u['id'];
}

$clausula = 'WHERE ' . implode(' AND ', $where);

$st = $pdo->prepare(
    "SELECT o.numero, o.data_orcamento, o.data_entrega_prevista,
            c.nome AS cliente, c.telefone AS cliente_telefone,
            u.nome AS responsavel, o.status,
            o.valor_materiais, o.valor_mao_obra, o.valor_desconto, o.valor_total,
            o.forma_pagamento, o.tipo_telhado, o.acabamento_cor,
            o.data_resposta, o.observacoes
     FROM orcamentos o
     JOIN clientes c ON c.id = o.cliente_id
     JOIN usuarios u ON u.id = o.responsavel_id
     $clausula
     ORDER BY o.id DESC"
);
$st->execute($params);
$orcamentos = $st->fetchAll();

$nomeArquivo = 'orcamentos_' . date('Y-m-d') . '.csv';

header('Content-Type: text/csv; charset=UTF-8');
header('Content-Disposition: attachment; filename="' . $nomeArquivo . '"');
header('Pragma: no-cache');
header('Expires: 0');

$saida = fopen('php://output', 'w');
fwrite($saida, "\xEF\xBB\xBF");

fputcsv($saida, [
    'Numero', 'Emissao', 'Previsao instalacao', 'Cliente', 'Telefone do cliente',
    'Responsavel', 'Status',
    'Materiais', 'Mao de obra', 'Desconto', 'Total',
    'Forma de pagamento', 'Tipo de telhado', 'Acabamento',
    'Data da resposta', 'Observacoes',
], ';');

foreach ($orcamentos as $o) {
    fputcsv($saida, [
        $o['numero'],
        data_br($o['data_orcamento'], true),
        data_br($o['data_entrega_prevista']),
        $o['cliente'],
        formatar_telefone($o['cliente_telefone']),
        $o['responsavel'],
        status_orcamento($o['status'])['rotulo'],
        // Valores numericos vao crus (sem "R$") pra dar pra somar no Excel
        number_format((float) $o['valor_materiais'], 2, ',', ''),
        number_format((float) $o['valor_mao_obra'], 2, ',', ''),
        number_format((float) $o['valor_desconto'], 2, ',', ''),
        number_format((float) $o['valor_total'], 2, ',', ''),
        $o['forma_pagamento'] ?? '',
        $o['tipo_telhado'] ?? '',
        $o['acabamento_cor'] ?? '',
        data_br($o['data_resposta'], true),
        $o['observacoes'] ?? '',
    ], ';');
}

fclose($saida);

registrar_log('EXPORTAR', 'orcamentos', [
    'mensagem' => 'Exportou a lista de orcamentos em CSV',
    'total'    => count($orcamentos),
]);
exit;