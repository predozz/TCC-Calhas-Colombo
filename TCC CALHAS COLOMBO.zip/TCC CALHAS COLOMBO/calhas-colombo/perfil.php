<?php
// tela de perfil: o usuario ve os proprios dados e troca a senha

require_once __DIR__ . '/inclui/auth.php';
exigir_login();

$u = usuario_logado();
$pdo = bd();

// Carrega os dados completos do usuario ANTES dos handlers porque a
// verificacao de senha (usada no wizard de 2FA) precisa do hash
$st = $pdo->prepare("SELECT * FROM usuarios WHERE id = :id");
$st->execute([':id' => $u['id']]);
$usuario = $st->fetch();

/* ====================================================================
   HANDLER: atualizar dados pessoais
   ==================================================================== */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['acao'] ?? '') === 'dados') {
    csrf_validar();

    $nome     = trim($_POST['nome'] ?? '');
    $telefone = trim($_POST['telefone'] ?? '');

    if (mb_strlen($nome) < 3) {
        flash('erro', 'Informe o nome completo.');
    } else {
        $pdo->prepare("UPDATE usuarios SET nome = :n, telefone = :t WHERE id = :id")
            ->execute([':n' => $nome, ':t' => $telefone ?: null, ':id' => $u['id']]);

        $_SESSION['usuario_nome']     = $nome;
        $_SESSION['usuario_telefone'] = $telefone;

        flash('sucesso', 'Dados atualizados.');
    }
    redirecionar('perfil.php');
}

/* ====================================================================
   HANDLER: trocar senha
   ==================================================================== */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['acao'] ?? '') === 'senha') {
    csrf_validar();

    $atual    = $_POST['senha_atual'] ?? '';
    $nova     = $_POST['senha_nova'] ?? '';
    $confirma = $_POST['senha_confirma'] ?? '';

    if (!password_verify($atual, $usuario['senha'])) {
        flash('erro', 'A senha atual esta incorreta.');
    } elseif (strlen($nova) < 6) {
        flash('erro', 'A nova senha precisa ter no minimo 6 caracteres.');
    } elseif ($nova !== $confirma) {
        flash('erro', 'A confirmacao nao confere com a nova senha.');
    } else {
        $pdo->prepare("UPDATE usuarios SET senha = :s WHERE id = :id")
            ->execute([':s' => password_hash($nova, PASSWORD_DEFAULT), ':id' => $u['id']]);

        flash('sucesso', 'Senha alterada com sucesso.');
    }
    redirecionar('perfil.php');
}

/* ====================================================================
   2FA - fluxo de ativacao em 3 etapas
   ====================================================================
   Ativar 2FA e uma decisao seria: se o usuario ativar e o email
   estiver errado, ele se tranca fora do sistema. Por isso a ativacao
   passa por tres passos:
     1. Clica em "Ativar"                    -> estado = 'senha'
     2. Confirma a senha                     -> envia codigo por email
                                             -> estado = 'codigo'
     3. Digita o codigo recebido             -> ativa de verdade
   ==================================================================== */

$setup2fa = $_SESSION['2fa_setup'] ?? null;

// ---- Iniciar ativacao ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['acao'] ?? '') === '2fa_iniciar') {
    csrf_validar();

    if ((int) $usuario['two_factor_ativo'] === 1) {
        flash('erro', 'A verificacao em duas etapas ja esta ativa.');
        redirecionar('perfil.php');
    }

    $_SESSION['2fa_setup'] = 'senha';
    redirecionar('perfil.php');
}

// ---- Cancelar wizard ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['acao'] ?? '') === '2fa_cancelar') {
    csrf_validar();
    unset($_SESSION['2fa_setup']);
    flash('info', 'Ativacao cancelada.');
    redirecionar('perfil.php');
}

// ---- Etapa 2: confirma senha -> envia codigo ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['acao'] ?? '') === '2fa_confirmar_senha') {
    csrf_validar();
    $senha = $_POST['senha'] ?? '';

    if (!password_verify($senha, $usuario['senha'])) {
        flash('erro', 'Senha incorreta. Tente de novo.');
    } else {
        require_once __DIR__ . '/inclui/email.php';

        $codigo = gerar_codigo_2fa((int) $u['id']);

        $corpo = "
            <div style='font-family:sans-serif;max-width:520px;margin:0 auto;
                        padding:20px;background:#f4f6fa;border-radius:12px'>
                <div style='background:#fff;padding:32px;border-radius:10px'>
                    <h2 style='color:#e07c12;margin:0 0 20px'>" . e(EMPRESA_NOME) . "</h2>
                    <p style='color:#334155'>Ola " . e($usuario['nome']) . ",</p>
                    <p style='color:#334155'>Voce pediu pra ativar a verificacao em duas
                       etapas. Use o codigo abaixo pra confirmar:</p>
                    <div style='font-size:34px;font-weight:bold;letter-spacing:10px;
                                text-align:center;background:#fdf3e4;padding:22px;
                                border-radius:10px;color:#b35f0d;font-family:monospace;
                                margin:24px 0'>$codigo</div>
                    <p style='color:#64748b;font-size:13px;margin-top:24px'>
                        O codigo vale por 10 minutos. Se voce nao pediu isso, ignore este e-mail.
                    </p>
                </div>
            </div>
        ";

        if (enviar_email($usuario['email'], 'Codigo de ativacao - ' . EMPRESA_NOME, $corpo)) {
            $_SESSION['2fa_setup'] = 'codigo';
            flash('sucesso', 'Enviamos um codigo para ' . $usuario['email'] . '. Digite ele abaixo.');
        } else {
            flash('erro', 'Nao foi possivel enviar o e-mail. Confira o endereco ou tente mais tarde.');
        }
    }
    redirecionar('perfil.php');
}

// ---- Etapa 2.5: reenviar codigo (sem pedir senha de novo) ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['acao'] ?? '') === '2fa_reenviar') {
    csrf_validar();

    if ($setup2fa !== 'codigo') {
        flash('erro', 'Fluxo invalido.');
        redirecionar('perfil.php');
    }

    require_once __DIR__ . '/inclui/email.php';
    $codigo = gerar_codigo_2fa((int) $u['id']);

    $corpo = "
        <div style='font-family:sans-serif;max-width:520px;margin:0 auto;
                    padding:20px;background:#f4f6fa;border-radius:12px'>
            <div style='background:#fff;padding:32px;border-radius:10px'>
                <h2 style='color:#e07c12;margin:0 0 20px'>" . e(EMPRESA_NOME) . "</h2>
                <p style='color:#334155'>Ola " . e($usuario['nome']) . ",</p>
                <p style='color:#334155'>Segue um novo codigo pra ativar a verificacao em duas etapas:</p>
                <div style='font-size:34px;font-weight:bold;letter-spacing:10px;
                            text-align:center;background:#fdf3e4;padding:22px;
                            border-radius:10px;color:#b35f0d;font-family:monospace;
                            margin:24px 0'>$codigo</div>
                <p style='color:#64748b;font-size:13px;margin-top:24px'>O codigo vale por 10 minutos.</p>
            </div>
        </div>
    ";

    if (enviar_email($usuario['email'], 'Novo codigo de ativacao - ' . EMPRESA_NOME, $corpo)) {
        flash('sucesso', 'Enviamos um novo codigo para ' . $usuario['email'] . '.');
    } else {
        flash('erro', 'Nao foi possivel reenviar o e-mail. Tente mais tarde.');
    }
    redirecionar('perfil.php');
}

// ---- Etapa 3: confirma codigo -> ativa ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['acao'] ?? '') === '2fa_confirmar_codigo') {
    csrf_validar();
    $codigo = trim($_POST['codigo'] ?? '');

    if (strlen($codigo) !== 6 || !ctype_digit($codigo)) {
        flash('erro', 'Digite os 6 digitos do codigo.');
    } elseif (!validar_codigo_2fa((int) $u['id'], $codigo)) {
        flash('erro', 'Codigo invalido ou expirado. Tente novamente.');
    } else {
        $pdo->prepare(
            "UPDATE usuarios SET two_factor_ativo = 1, two_factor_ativo_em = NOW() WHERE id = :id"
        )->execute([':id' => $u['id']]);

        $_SESSION['usuario_2fa'] = 1;
        unset($_SESSION['2fa_setup']);

        registrar_log('EDITAR', 'usuarios', [
            'mensagem' => 'Ativou verificacao em duas etapas',
            'email'    => $usuario['email'],
        ], null, 'Usuario: ' . $u['nome'], $u['id']);

        flash('sucesso', 'Verificacao em duas etapas ativada! Na proxima vez que entrar, vai precisar do codigo enviado por e-mail.');
    }
    redirecionar('perfil.php');
}

// ---- Desativar (exige senha) ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['acao'] ?? '') === '2fa_desativar') {
    csrf_validar();
    $senha = $_POST['senha'] ?? '';

    if (!password_verify($senha, $usuario['senha'])) {
        flash('erro', 'Senha incorreta. A verificacao NAO foi desativada.');
    } else {
        $pdo->prepare(
            "UPDATE usuarios SET two_factor_ativo = 0, two_factor_ativo_em = NULL WHERE id = :id"
        )->execute([':id' => $u['id']]);

        $_SESSION['usuario_2fa'] = 0;

        registrar_log('EDITAR', 'usuarios', [
            'mensagem' => 'Desativou verificacao em duas etapas',
        ], null, 'Usuario: ' . $u['nome'], $u['id']);

        flash('sucesso', 'Verificacao em duas etapas desativada. Voce vai entrar apenas com a senha.');
    }
    redirecionar('perfil.php');
}

/* ====================================================================
   Dados pra tela
   ==================================================================== */
$st = $pdo->prepare(
    "SELECT COUNT(*) AS qtd,
            COALESCE(SUM(CASE WHEN status IN ('aprovado','em_producao','concluido')
                         THEN valor_total ELSE 0 END),0) AS receita
     FROM orcamentos WHERE responsavel_id = :id"
);
$st->execute([':id' => $u['id']]);
$estatisticas = $st->fetch();

$titulo_pagina = 'Meu perfil';
$pagina_ativa  = 'perfil';
require_once __DIR__ . '/inclui/cabecalho.php';
?>

<div class="pagina-topo">
    <div>
        <h1 class="pagina-titulo">Meu perfil</h1>
        <p class="pagina-subtitulo">
            <?= e(rotulo_perfil($usuario['perfil'])) ?> &middot;
            cadastrado em <?= data_br($usuario['data_cadastro']) ?>
        </p>
    </div>
</div>

<div class="grade-indicadores">
    <div class="indicador">
        <div class="indicador-rotulo">Orcamentos sob sua responsabilidade</div>
        <div class="indicador-valor"><?= (int) $estatisticas['qtd'] ?></div>
    </div>
    <?php if (pode('ver_financeiro')): ?>
        <div class="indicador verde">
            <div class="indicador-rotulo">Receita gerada</div>
            <div class="indicador-valor"><?= moeda($estatisticas['receita']) ?></div>
        </div>
    <?php endif; ?>
    <div class="indicador roxo">
        <div class="indicador-rotulo">Ultimo acesso</div>
        <div class="indicador-valor" style="font-size:19px">
            <?= data_br($usuario['ultimo_acesso'], true) ?>
        </div>
    </div>
</div>

<div class="grade-2">

    <div class="cartao">
        <div class="cartao-cabecalho"><h3>Dados pessoais</h3></div>
        <div class="cartao-corpo">
            <form method="POST" class="formulario-grade">
                <?= csrf_campo() ?>
                <input type="hidden" name="acao" value="dados">

                <div class="campo col-12">
                    <label for="nome">Nome completo</label>
                    <input type="text" id="nome" name="nome" required value="<?= e($usuario['nome']) ?>">
                </div>

                <div class="campo col-12">
                    <label for="email_ro">E-mail (login)</label>
                    <input type="email" id="email_ro" value="<?= e($usuario['email']) ?>" readonly>
                    <span class="campo-dica">Apenas o administrador pode alterar o e-mail</span>
                </div>

                <div class="campo col-12">
                    <label for="telefone">Telefone</label>
                    <input type="text" id="telefone" name="telefone" data-mascara="telefone"
                           value="<?= e($usuario['telefone'] ?? '') ?>">
                </div>

                <div class="formulario-acoes">
                    <button type="submit" class="botao botao-sucesso">Salvar dados</button>
                </div>
            </form>
        </div>
    </div>

    <div class="cartao">
        <div class="cartao-cabecalho"><h3>Alterar senha</h3></div>
        <div class="cartao-corpo">
            <form method="POST" class="formulario-grade">
                <?= csrf_campo() ?>
                <input type="hidden" name="acao" value="senha">

                <div class="campo col-12">
                    <label for="senha_atual">Senha atual</label>
                    <input type="password" id="senha_atual" name="senha_atual" required>
                </div>

                <div class="campo col-12">
                    <label for="senha_nova">Nova senha</label>
                    <input type="password" id="senha_nova" name="senha_nova" required minlength="6">
                    <span class="campo-dica">Minimo de 6 caracteres</span>
                </div>

                <div class="campo col-12">
                    <label for="senha_confirma">Confirmar nova senha</label>
                    <input type="password" id="senha_confirma" name="senha_confirma" required minlength="6">
                </div>

                <div class="formulario-acoes">
                    <button type="submit" class="botao botao-primario">Alterar senha</button>
                </div>
            </form>
        </div>
    </div>

    <!-- ====================================================================
         VERIFICACAO EM DUAS ETAPAS
         A tela tem 4 estados diferentes, dependendo de onde o usuario esta:
           - Sem wizard + 2FA off      -> mostra botao "Ativar"
           - Wizard etapa 'senha'      -> pede a senha atual
           - Wizard etapa 'codigo'     -> pede o codigo recebido por email
           - Sem wizard + 2FA on       -> mostra status + botao "Desativar"
         ==================================================================== -->
    <div class="cartao">
        <div class="cartao-cabecalho">
            <h3>Verificacao em duas etapas</h3>
            <?php if ((int) $usuario['two_factor_ativo'] === 1 && $setup2fa === null): ?>
                <span class="selo selo-verde">Ativada</span>
            <?php elseif ($setup2fa !== null): ?>
                <span class="selo selo-ambar">Configurando</span>
            <?php else: ?>
                <span class="selo selo-cinza">Desativada</span>
            <?php endif; ?>
        </div>

        <div class="cartao-corpo">

            <?php if ($setup2fa === 'senha'): ?>
                <!-- ETAPA 1: confirma a senha -->
                <div class="alerta alerta-info">
                    <span class="alerta-icone">&#8505;</span>
                    <span>
                        <strong>Passo 1 de 2.</strong> Pra ativar a verificacao em duas etapas,
                        primeiro confirmamos que e voce mesmo.
                    </span>
                </div>

                <p class="txt-p txt-suave mb2">
                    Digite sua senha atual pra continuar:
                </p>

                <form method="POST" class="formulario-grade">
                    <?= csrf_campo() ?>
                    <input type="hidden" name="acao" value="2fa_confirmar_senha">

                    <div class="campo col-12">
                        <label for="senha_2fa">Senha atual</label>
                        <input type="password" id="senha_2fa" name="senha" required autofocus>
                    </div>

                    <div class="formulario-acoes">
                        <button type="submit" class="botao botao-primario">Confirmar</button>
                    </div>
                </form>

                <form method="POST" style="margin-top:12px">
                    <?= csrf_campo() ?>
                    <input type="hidden" name="acao" value="2fa_cancelar">
                    <button type="submit" class="botao botao-neutro botao-p">Cancelar</button>
                </form>

            <?php elseif ($setup2fa === 'codigo'): ?>
                <!-- ETAPA 2: confirma o codigo do email -->
                <div class="alerta alerta-info">
                    <span class="alerta-icone">&#8505;</span>
                    <span>
                        <strong>Passo 2 de 2.</strong> Enviamos um codigo de 6 digitos
                        para <strong><?= e($usuario['email']) ?></strong>.
                    </span>
                </div>

                <p class="txt-p txt-suave mb2">
                    Digite o codigo recebido pra concluir a ativacao:
                </p>

                <form method="POST" class="formulario-grade">
                    <?= csrf_campo() ?>
                    <input type="hidden" name="acao" value="2fa_confirmar_codigo">

                    <div class="campo col-12">
                        <label for="codigo_2fa">Codigo de verificacao</label>
                        <input type="text" id="codigo_2fa" name="codigo" required autofocus
                               inputmode="numeric" pattern="[0-9]{6}" maxlength="6"
                               placeholder="000000"
                               style="font-size:24px;letter-spacing:8px;text-align:center;
                                      font-family:var(--fonte-mono)">
                        <span class="campo-dica">O codigo expira em 10 minutos</span>
                    </div>

                    <div class="formulario-acoes">
                        <button type="submit" class="botao botao-sucesso">Confirmar e ativar</button>
                    </div>
                </form>

                <div class="flex g2 mt3" style="flex-wrap:wrap">
                    <form method="POST" style="display:inline">
                        <?= csrf_campo() ?>
                        <input type="hidden" name="acao" value="2fa_reenviar">
                        <button type="submit" class="botao botao-neutro botao-p">Reenviar codigo</button>
                    </form>

                    <form method="POST" style="display:inline">
                        <?= csrf_campo() ?>
                        <input type="hidden" name="acao" value="2fa_cancelar">
                        <button type="submit" class="botao botao-neutro botao-p">Cancelar</button>
                    </form>
                </div>

            <?php elseif ((int) $usuario['two_factor_ativo'] === 1): ?>
                <!-- JA ESTA ATIVA -->
                <div class="alerta alerta-sucesso">
                    <span class="alerta-icone">&#10003;</span>
                    <span>
                        <strong>Ativada.</strong>
                        <?php if ($usuario['two_factor_ativo_em']): ?>
                            desde <?= data_br($usuario['two_factor_ativo_em'], true) ?>.
                        <?php else: ?>
                            Toda vez que voce entrar, vai receber um codigo por e-mail.
                        <?php endif; ?>
                    </span>
                </div>

                <p class="txt-p txt-suave mb2">
                    Os codigos sao enviados para <strong><?= e($usuario['email']) ?></strong>.
                    Pra desativar, confirme sua senha:
                </p>

                <form method="POST" class="formulario-grade">
                    <?= csrf_campo() ?>
                    <input type="hidden" name="acao" value="2fa_desativar">

                    <div class="campo col-12">
                        <label for="senha_desativar">Senha atual</label>
                        <input type="password" id="senha_desativar" name="senha" required>
                        <span class="campo-dica">Por seguranca, precisa confirmar a senha pra desativar</span>
                    </div>

                    <div class="formulario-acoes">
                        <button type="submit" class="botao botao-neutro"
                                data-confirmar="Tem certeza que quer desativar? Sua conta fica so com a senha.">
                            Desativar verificacao
                        </button>
                    </div>
                </form>

            <?php else: ?>
                <!-- DESATIVADA, ponto de partida -->
                <div class="alerta alerta-aviso">
                    <span class="alerta-icone">&#9888;</span>
                    <span>
                        <strong>Desativada.</strong> Adicione uma camada extra de seguranca.
                        Com ela ativa, alem da senha voce vai precisar de um codigo
                        enviado por e-mail toda vez que entrar.
                    </span>
                </div>

                <p class="txt-p txt-suave mb2">
                    Os codigos serao enviados para <strong><?= e($usuario['email']) ?></strong>.
                </p>

                <p class="txt-p txt-suave mb3">
                    Por seguranca, o processo de ativacao em 2 passos:
                    primeiro voce confirma sua senha, depois digita um codigo que
                    enviamos por e-mail — assim garantimos que o e-mail funciona
                    antes de ativar de verdade.
                </p>

                <form method="POST">
                    <?= csrf_campo() ?>
                    <input type="hidden" name="acao" value="2fa_iniciar">
                    <button type="submit" class="botao botao-sucesso">
                        Ativar verificacao em duas etapas
                    </button>
                </form>
            <?php endif; ?>

        </div>
    </div>
</div>

<?php require_once __DIR__ . '/inclui/rodape.php'; ?>