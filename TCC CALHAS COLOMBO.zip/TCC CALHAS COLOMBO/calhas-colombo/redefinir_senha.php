<?php
// tela onde o usuario define a nova senha depois de clicar no link
// que recebeu por email. O token vem na URL (?t=...).
//
// Regras:
//   - O token tem que existir, nao ter sido usado e nao ter expirado
//   - Depois de redefinir, marca o token como usado (uso unico)
//   - Manda um email de confirmacao avisando que a senha foi alterada
//   - NAO loga automaticamente: manda pro login pra ele entrar de novo

require_once __DIR__ . '/inclui/auth.php';
require_once __DIR__ . '/inclui/email.php';

if (esta_logado()) {
    redirecionar('index.php');
}

$token = $_GET['t'] ?? '';

// Valida formato do token antes de qualquer coisa
if (!preg_match('/^[a-f0-9]{64}$/', $token)) {
    flash('erro', 'Link invalido ou expirado.');
    redirecionar('login.php');
}

$usuario = validar_token_reset($token);

if (!$usuario) {
    flash('erro', 'Esse link nao e mais valido. Pode ser que ele tenha expirado ou ja tenha sido usado. Peca um novo.');
    redirecionar('login.php');
}

$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validar();

    $nova     = $_POST['senha_nova'] ?? '';
    $confirma = $_POST['senha_confirma'] ?? '';

    if (strlen($nova) < 6) {
        $erro = 'A senha precisa ter no minimo 6 caracteres.';
    } elseif ($nova !== $confirma) {
        $erro = 'As senhas nao batem. Digite de novo.';
    } else {
        $pdo = bd();

        // Atualiza a senha
        $pdo->prepare("UPDATE usuarios SET senha = :s WHERE id = :id")
            ->execute([':s' => password_hash($nova, PASSWORD_DEFAULT), ':id' => $usuario['id']]);

        // Marca o token como usado (nao pode ser reutilizado)
        consumir_token_reset($token);

        // Manda email avisando que a senha foi alterada
        $agora = date('d/m/Y \a\s H:i');
        $ip    = $_SERVER['REMOTE_ADDR'] ?? 'desconhecido';

        $corpo = "
            <div style='font-family:sans-serif;max-width:520px;margin:0 auto;
                        padding:20px;background:#f4f6fa;border-radius:12px'>
                <div style='background:#fff;padding:32px;border-radius:10px'>
                    <h2 style='color:#e07c12;margin:0 0 20px'>" . e(EMPRESA_NOME) . "</h2>
                    <p style='color:#334155'>Ola " . e($usuario['nome']) . ",</p>
                    <p style='color:#334155'>Sua senha foi alterada com sucesso em <strong>$agora</strong>.</p>
                    <p style='color:#334155'>Se foi voce, tudo certo. Pode ignorar este e-mail.</p>
                    <div style='background:#fbe6e5;border-left:4px solid #dc3545;
                                padding:16px;border-radius:6px;margin-top:24px'>
                        <p style='color:#b3261e;margin:0;font-size:14px'>
                            <strong>Se nao foi voce</strong>, alguem teve acesso a sua caixa de e-mail.
                            Entre em contato com a gente imediatamente pelo telefone
                            " . e(EMPRESA_TELEFONE) . ".
                        </p>
                    </div>
                    <p style='color:#94a3b8;font-size:11px;margin-top:20px'>
                        Detalhe tecnico: requisicao vinda do IP $ip.
                    </p>
                </div>
            </div>
        ";

        enviar_email($usuario['email'], 'Sua senha foi alterada - ' . EMPRESA_NOME, $corpo);

        // Registra na auditoria
        registrar_log('EDITAR', 'usuarios', [
            'mensagem' => 'Redefiniu a senha via link de reset',
        ], null, 'Senha redefinida: ' . $usuario['nome'], (int) $usuario['id']);

        flash('sucesso', 'Senha alterada com sucesso. Entre com a nova senha.');
        redirecionar('login.php');
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Nova senha &middot; <?= e(EMPRESA_NOME) ?></title>
<link rel="stylesheet" href="assets/css/estilo.css">
</head>
<body class="pagina-login">

<div class="caixa-login">

    <div class="login-topo">
        <img src="assets/img/logo-icone.png" alt="" class="login-logo">
        <h1>Criar nova senha</h1>
        <p>Defina uma senha nova pra sua conta</p>
    </div>

    <div class="login-corpo">

        <?php if ($erro): ?>
            <div class="alerta alerta-erro">
                <span class="alerta-icone">&#33;</span>
                <span><?= e($erro) ?></span>
            </div>
        <?php endif; ?>

        <p class="txt-p txt-suave" style="margin-bottom:20px">
            Voce esta redefinindo a senha de <strong><?= e($usuario['email']) ?></strong>.
        </p>

        <form method="POST" autocomplete="new-password">
            <?= csrf_campo() ?>

            <div class="campo">
                <label for="senha_nova">Nova senha</label>
                <input type="password" id="senha_nova" name="senha_nova"
                       required minlength="6" autofocus>
                <span class="campo-dica">Minimo de 6 caracteres</span>
            </div>

            <div class="campo">
                <label for="senha_confirma">Confirmar nova senha</label>
                <input type="password" id="senha_confirma" name="senha_confirma"
                       required minlength="6">
            </div>

            <button type="submit" class="botao botao-sucesso botao-bloco botao-g">
                Salvar nova senha
            </button>
        </form>

        <p style="text-align:center;margin-top:20px;font-size:13px">
            <a href="login.php">Voltar pro login</a>
        </p>
    </div>

    <div class="login-rodape">
        &copy; <?= date('Y') ?> <?= e(EMPRESA_NOME) ?>
    </div>
</div>

</body>
</html>