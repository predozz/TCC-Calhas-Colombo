<?php
// tela de verificacao do codigo 2FA. o usuario so chega aqui depois
// que a senha foi validada em login.php. se o codigo tiver certo,
// a sessao de verdade e criada aqui.

require_once __DIR__ . '/inclui/auth.php';

if (esta_logado()) {
    redirecionar('index.php');
}

$usuarioId = (int) ($_SESSION['2fa_usuario_id'] ?? 0);

if ($usuarioId <= 0) {
    // ninguem passou pela tela de login ainda, ou o codigo foi cancelado
    redirecionar('login.php');
}

$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validar();

    // Se o usuario clicou em "reenviar codigo"
    if (isset($_POST['reenviar'])) {
        require_once __DIR__ . '/inclui/email.php';

        $st = bd()->prepare("SELECT * FROM usuarios WHERE id = :id");
        $st->execute([':id' => $usuarioId]);
        $usuario = $st->fetch();

        if ($usuario) {
            $codigo = gerar_codigo_2fa($usuarioId);

            $corpo = "
                <div style='font-family:sans-serif;max-width:520px;margin:0 auto;
                            padding:20px;background:#f4f6fa;border-radius:12px'>
                    <div style='background:#fff;padding:32px;border-radius:10px'>
                        <h2 style='color:#e07c12;margin:0 0 20px'>" . e(EMPRESA_NOME) . "</h2>
                        <p style='color:#334155'>Ola " . e($usuario['nome']) . ",</p>
                        <p style='color:#334155'>Seu novo codigo de verificacao para entrar no sistema e:</p>
                        <div style='font-size:34px;font-weight:bold;letter-spacing:10px;
                                    text-align:center;background:#fdf3e4;padding:22px;
                                    border-radius:10px;color:#b35f0d;font-family:monospace;
                                    margin:24px 0'>$codigo</div>
                        <p style='color:#64748b;font-size:13px;margin-top:24px'>
                            O codigo vale por 10 minutos. Se voce nao tentou entrar no
                            sistema, ignore este e-mail.
                        </p>
                    </div>
                </div>
            ";

            if (enviar_email($usuario['email'], 'Novo codigo de verificacao - ' . EMPRESA_NOME, $corpo)) {
                flash('sucesso', 'Enviamos um novo codigo pro seu e-mail.');
            } else {
                flash('erro', 'Nao foi possivel enviar o e-mail. Tente de novo em alguns instantes.');
            }
        }
        redirecionar('verificar_2fa.php');
    }

    // Validacao normal do codigo
    $codigo = trim($_POST['codigo'] ?? '');

    if ($codigo === '' || strlen($codigo) !== 6 || !ctype_digit($codigo)) {
        $erro = 'Digite os 6 digitos do codigo.';
    } elseif (!validar_codigo_2fa($usuarioId, $codigo)) {
        $erro = 'Codigo invalido ou expirado. Tente novamente.';
    } else {
        $st = bd()->prepare("SELECT * FROM usuarios WHERE id = :id");
        $st->execute([':id' => $usuarioId]);
        $usuario = $st->fetch();

        if ($usuario) {
            efetivar_login($usuario);
            unset($_SESSION['2fa_usuario_id'], $_SESSION['2fa_email']);

            registrar_log('LOGIN', 'login', null, null, 'Efetuou login com 2FA');

            flash('sucesso', 'Bem-vindo de volta, ' . $usuario['nome'] . '!');
            redirecionar('index.php');
        }

        $erro = 'Usuario nao encontrado.';
    }
}

$emailMascarado = $_SESSION['2fa_email'] ?? '';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Verificacao &middot; <?= e(EMPRESA_NOME) ?></title>
<link rel="stylesheet" href="assets/css/estilo.css">
</head>
<body class="pagina-login">

<div class="caixa-login">

    <div class="login-topo">
        <img src="assets/img/logo-icone.png" alt="" class="login-logo">
        <h1>Verificacao em duas etapas</h1>
        <p>Enviamos um codigo de 6 digitos para o seu e-mail</p>
    </div>

    <div class="login-corpo">

        <?php if ($erro): ?>
            <div class="alerta alerta-erro">
                <span class="alerta-icone">&#33;</span>
                <span><?= e($erro) ?></span>
            </div>
        <?php endif; ?>

        <?= flash_exibir() ?>

        <form method="POST" autocomplete="off">
            <?= csrf_campo() ?>

            <div class="campo">
                <label for="codigo">Codigo de verificacao</label>
                <input type="text" id="codigo" name="codigo"
                       inputmode="numeric" pattern="[0-9]{6}" maxlength="6"
                       placeholder="000000" required autofocus
                       style="font-size:26px;letter-spacing:10px;text-align:center;
                              font-family:var(--fonte-mono);padding:14px 12px">
                <span class="campo-dica">O codigo expira em 10 minutos</span>
            </div>

            <button type="submit" class="botao botao-primario botao-bloco botao-g">
                Verificar e entrar
            </button>
        </form>

        <div style="margin-top:20px;padding-top:20px;border-top:1px solid var(--borda);
                    text-align:center">
            <p class="txt-p txt-suave" style="margin-bottom:10px">
                Nao recebeu o codigo?
            </p>
            <form method="POST" style="display:inline">
                <?= csrf_campo() ?>
                <button type="submit" name="reenviar" value="1"
                        class="botao botao-neutro botao-p">
                    Reenviar codigo
                </button>
            </form>
        </div>

        <p style="text-align:center;margin-top:20px;font-size:13px">
            <a href="login.php">Voltar pro login</a>
        </p>
    </div>

    <div class="login-rodape">
        &copy; <?= date('Y') ?> <?= e(EMPRESA_NOME) ?>
    </div>
</div>

</body>
</html>