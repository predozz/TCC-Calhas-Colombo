-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 20/10/2026 às 22:10
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `calhas_colombo`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `clientes`
--

CREATE TABLE `clientes` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `tipo_pessoa` enum('fisica','juridica') NOT NULL DEFAULT 'fisica',
  `cpf_cnpj` varchar(20) DEFAULT NULL,
  `telefone` varchar(20) NOT NULL,
  `whatsapp` varchar(20) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `cep` varchar(10) DEFAULT NULL,
  `endereco` varchar(150) NOT NULL,
  `numero` varchar(15) DEFAULT NULL,
  `complemento` varchar(100) DEFAULT NULL,
  `bairro` varchar(60) DEFAULT NULL,
  `cidade` varchar(60) DEFAULT NULL,
  `uf` char(2) DEFAULT 'SC',
  `ponto_referencia` varchar(150) DEFAULT NULL,
  `origem` enum('indicacao','instagram','google','fachada','outro') DEFAULT 'outro',
  `ativo` tinyint(1) NOT NULL DEFAULT 1,
  `observacoes` text DEFAULT NULL,
  `senha` varchar(255) DEFAULT NULL,
  `acesso_ativo` tinyint(1) NOT NULL DEFAULT 0,
  `acesso_criado_em` datetime DEFAULT NULL,
  `ultimo_acesso_cliente` datetime DEFAULT NULL,
  `data_cadastro` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `clientes`
--

INSERT INTO `clientes` (`id`, `nome`, `tipo_pessoa`, `cpf_cnpj`, `telefone`, `whatsapp`, `email`, `cep`, `endereco`, `numero`, `complemento`, `bairro`, `cidade`, `uf`, `ponto_referencia`, `origem`, `ativo`, `observacoes`, `senha`, `acesso_ativo`, `acesso_criado_em`, `ultimo_acesso_cliente`, `data_cadastro`) VALUES
(4, 'Roberto Constuções', 'fisica', '120.349.519-64', '(48) 99953-2840', NULL, NULL, '88817-540', 'Rua Cassimiro Pizzoni', '123', 'Casa', 'Vila Isabel', 'Criciúma', 'SC', NULL, 'outro', 1, 'cachorro bravo no quintal', NULL, 0, NULL, NULL, '2026-09-16 23:26:47'),
(5, 'Maria Oliveira', 'fisica', '012.345.678-90', '(48) 98811-2233', '(48) 98811-2233', 'maria.oliveira@email.com', '88801-000', 'Rua das Flores', '45', 'Apto 102', 'Centro', 'Criciúma', 'SC', NULL, 'instagram', 1, 'Contacto preferencial por WhatsApp', NULL, 0, NULL, NULL, '2026-09-21 08:06:18'),
(7, 'carlos henrique', 'fisica', '147.004.839-62', '(48) 98824-0332', '(23) 39290-4923', 'prgiassi00@gmail.com', NULL, 'Rua Artur Linemburger', NULL, NULL, 'Brasília', 'Criciúma', 'SC', NULL, 'indicacao', 1, NULL, NULL, 0, NULL, NULL, '2026-10-06 16:19:12'),
(8, 'João Carlos Pereira', 'fisica', '529.982.247-25', '(48) 99876-5432', '(48) 99876-5432', '4553517980@estudante.sed.sc.gov.br', '88801-000', 'Avenida Centenário', '245', 'Casa', 'Centro', 'Criciúma', 'SC', 'Próximo ao mercado central', 'instagram', 1, 'Cliente tem pressa na instalação. Vai estar em casa apenas à tarde durante a semana.', '$2y$10$8zwUn08e8WX6c06SM39bmOBa7zPsR6zonw/xqvNb5q3EWyFgYNNwG', 1, '2026-10-13 14:29:58', '2026-10-20 14:26:40', '2026-10-13 14:29:58');

-- --------------------------------------------------------

--
-- Estrutura para tabela `clientes_logs`
--

CREATE TABLE `clientes_logs` (
  `id` int(11) NOT NULL,
  `cliente_id` int(11) NOT NULL,
  `acao` varchar(30) NOT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  `ip_endereco` varchar(45) DEFAULT NULL,
  `data_hora` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `clientes_logs`
--

INSERT INTO `clientes_logs` (`id`, `cliente_id`, `acao`, `descricao`, `ip_endereco`, `data_hora`) VALUES
(1, 8, 'LOGIN', 'Acessou a area do cliente', '::1', '2026-10-13 14:30:43'),
(2, 8, 'LOGOUT', 'Saiu da area do cliente', '::1', '2026-10-13 14:36:04'),
(3, 8, 'LOGIN', 'Acessou a area do cliente', '::1', '2026-10-13 14:49:58'),
(4, 8, 'LOGOUT', 'Saiu da area do cliente', '::1', '2026-10-13 15:16:01'),
(5, 8, 'LOGIN', 'Acessou a area do cliente', '::1', '2026-10-13 15:21:24'),
(6, 8, 'LOGOUT', 'Saiu da area do cliente', '::1', '2026-10-13 15:22:43'),
(7, 8, 'LOGIN', 'Acessou a area do cliente', '::1', '2026-10-13 15:24:04'),
(8, 8, 'RESPONDER', 'Aprovou a proposta ORC-2026-0009', '::1', '2026-10-13 16:29:41'),
(9, 8, 'SENHA', 'Alterou a propria senha', '::1', '2026-10-13 16:44:01'),
(10, 8, 'LOGOUT', 'Saiu da area do cliente', '::1', '2026-10-13 16:44:03'),
(11, 8, 'LOGIN', 'Acessou a area do cliente', '::1', '2026-10-13 16:44:09'),
(12, 8, 'LOGIN', 'Acessou a area do cliente', '::1', '2026-10-13 16:46:49'),
(13, 8, 'LOGOUT', 'Saiu da area do cliente', '::1', '2026-10-13 16:59:50'),
(14, 8, 'LOGIN', 'Acessou a area do cliente', '::1', '2026-10-13 17:00:28'),
(15, 8, 'SENHA', 'Alterou a propria senha', '::1', '2026-10-13 17:00:43'),
(16, 8, 'LOGOUT', 'Saiu da area do cliente', '::1', '2026-10-13 17:00:45'),
(17, 8, 'LOGIN', 'Acessou a area do cliente', '::1', '2026-10-13 17:00:53'),
(18, 8, 'LOGOUT', 'Saiu da area do cliente', '::1', '2026-10-13 17:01:55'),
(19, 8, 'LOGIN', 'Acessou a area do cliente', '::1', '2026-10-13 17:02:20'),
(20, 8, 'LOGIN', 'Acessou a area do cliente', '::1', '2026-10-20 14:26:40');

-- --------------------------------------------------------

--
-- Estrutura para tabela `compras_insumos`
--

CREATE TABLE `compras_insumos` (
  `id` int(11) NOT NULL,
  `descricao` varchar(255) NOT NULL,
  `produto_id` int(11) DEFAULT NULL,
  `fornecedor_id` int(11) DEFAULT NULL,
  `quantidade` int(11) NOT NULL,
  `unidade` varchar(20) NOT NULL DEFAULT 'un',
  `valor_total` decimal(10,2) NOT NULL,
  `data_compra` date NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `data_registro` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `compras_insumos`
--

INSERT INTO `compras_insumos` (`id`, `descricao`, `produto_id`, `fornecedor_id`, `quantidade`, `unidade`, `valor_total`, `data_compra`, `usuario_id`, `data_registro`) VALUES
(1, 'Bobina Chapa 0,5mm', 1, 1, 50, 'metro', 1250.00, '2026-08-24', 1, '2026-09-16 20:05:28'),
(2, 'Lote de suportes', 4, 2, 100, 'peca', 650.00, '2026-08-28', 1, '2026-09-16 20:05:28'),
(3, 'Tubos de veda calha', 3, 1, 20, 'un', 160.00, '2026-09-03', 2, '2026-09-16 20:05:28');

-- --------------------------------------------------------

--
-- Estrutura para tabela `fornecedores`
--

CREATE TABLE `fornecedores` (
  `id` int(11) NOT NULL,
  `nome` varchar(150) NOT NULL,
  `cnpj` varchar(20) DEFAULT NULL,
  `telefone` varchar(20) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `cidade` varchar(60) DEFAULT NULL,
  `uf` char(2) DEFAULT NULL,
  `ativo` tinyint(1) NOT NULL DEFAULT 1,
  `observacoes` text DEFAULT NULL,
  `data_cadastro` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `fornecedores`
--

INSERT INTO `fornecedores` (`id`, `nome`, `cnpj`, `telefone`, `email`, `cidade`, `uf`, `ativo`, `observacoes`, `data_cadastro`) VALUES
(1, 'Cri Chapa Metais', '98.765.432/0001-00', '4899999999', 'vendas@crichapa.com.br', 'Criciuma', 'SC', 1, NULL, '2026-09-16 20:05:27'),
(2, 'Aluminios do Sul', '11.222.333/0001-80', '4833221100', 'comercial@aluminiosul.com.br', 'Tubarao', 'SC', 1, NULL, '2026-09-16 20:05:27');

-- --------------------------------------------------------

--
-- Estrutura para tabela `itens_orcamento`
--

CREATE TABLE `itens_orcamento` (
  `id` int(11) NOT NULL,
  `orcamento_id` int(11) NOT NULL,
  `produto_id` int(11) NOT NULL,
  `quantidade` int(11) NOT NULL,
  `valor_unitario` decimal(10,2) NOT NULL,
  `valor_total` decimal(10,2) NOT NULL,
  `custo_unitario` decimal(10,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `itens_orcamento`
--

INSERT INTO `itens_orcamento` (`id`, `orcamento_id`, `produto_id`, `quantidade`, `valor_unitario`, `valor_total`, `custo_unitario`) VALUES
(15, 6, 1, 5, 42.00, 210.00, 0.00),
(16, 6, 4, 4, 12.50, 50.00, 0.00),
(17, 6, 3, 1, 20.00, 20.00, 0.00),
(34, 8, 1, 15, 42.00, 630.00, 0.00),
(35, 8, 4, 8, 12.50, 100.00, 0.00),
(36, 8, 3, 2, 18.90, 37.80, 0.00),
(37, 8, 2, 20, 0.50, 10.00, 0.00);

-- --------------------------------------------------------

--
-- Estrutura para tabela `logs_sistema`
--

CREATE TABLE `logs_sistema` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `acao` varchar(50) NOT NULL,
  `tabela_afetada` varchar(50) NOT NULL,
  `registro_id` int(11) DEFAULT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  `dados_anteriores` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`dados_anteriores`)),
  `dados_novos` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`dados_novos`)),
  `ip_endereco` varchar(45) NOT NULL,
  `data_hora` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `logs_sistema`
--

INSERT INTO `logs_sistema` (`id`, `usuario_id`, `acao`, `tabela_afetada`, `registro_id`, `descricao`, `dados_anteriores`, `dados_novos`, `ip_endereco`, `data_hora`) VALUES
(8, 1, 'LOGOUT', 'login', NULL, NULL, NULL, '{\"mensagem\":\"Efetuou logout do sistema\"}', '::1', '2026-09-28 09:51:27'),
(9, 1, 'LOGOUT', 'login', NULL, NULL, NULL, '{\"mensagem\":\"Efetuou logout do sistema\"}', '::1', '2026-09-29 13:35:14'),
(10, 1, 'LOGOUT', 'login', NULL, NULL, NULL, '{\"mensagem\":\"Efetuou logout do sistema\"}', '::1', '2026-09-29 13:36:43'),
(11, 2, 'LOGOUT', 'login', NULL, NULL, NULL, '{\"mensagem\":\"Efetuou logout do sistema\"}', '::1', '2026-09-29 13:36:49'),
(12, 1, 'LOGOUT', 'login', NULL, NULL, NULL, '{\"mensagem\":\"Efetuou logout do sistema\"}', '::1', '2026-09-29 13:38:10'),
(13, 3, 'LOGOUT', 'login', NULL, NULL, NULL, '{\"mensagem\":\"Efetuou logout do sistema\"}', '::1', '2026-09-29 13:38:26'),
(14, 1, 'EDITAR', 'orcamentos', NULL, NULL, '{\"status\":\"rascunho\"}', '{\"mensagem\":\"Alterou o status para aprovado\",\"status\":\"aprovado\"}', '::1', '2026-09-29 13:47:59'),
(15, 1, 'EXCLUIR', 'produtos', NULL, NULL, NULL, '{\"mensagem\":\"Excluiu o produto ID: 6\"}', '::1', '2026-09-29 13:47:59'),
(17, 1, 'EDITAR', 'orcamentos', 8, 'Orcamento ORC-2026-0008', NULL, '{\"mensagem\":\"Editou o orcamento\",\"valor_total\":1127.8}', '::1', '2026-09-29 15:15:17'),
(20, 1, 'LOGIN', 'login', NULL, 'Efetuou login no sistema', NULL, NULL, '::1', '2026-09-29 16:30:35'),
(21, 1, 'LOGIN', 'login', NULL, 'Efetuou login no sistema', NULL, NULL, '::1', '2026-10-05 07:55:32'),
(22, 1, 'EDITAR', 'orcamentos', 8, 'Orcamento ORC-2026-0008', NULL, '{\"mensagem\":\"Editou o orcamento\",\"valor_total\":1810.32}', '::1', '2026-10-05 07:57:06'),
(23, 1, 'LOGOUT', 'login', NULL, NULL, NULL, '{\"mensagem\":\"Efetuou logout do sistema\"}', '::1', '2026-10-05 08:17:27'),
(24, 2, 'LOGIN', 'login', NULL, 'Efetuou login no sistema', NULL, NULL, '::1', '2026-10-05 08:17:30'),
(25, 2, 'LOGOUT', 'login', NULL, NULL, NULL, '{\"mensagem\":\"Efetuou logout do sistema\"}', '::1', '2026-10-05 08:17:44'),
(26, 3, 'LOGIN', 'login', NULL, 'Efetuou login no sistema', NULL, NULL, '::1', '2026-10-05 08:17:46'),
(27, 3, 'LOGOUT', 'login', NULL, NULL, NULL, '{\"mensagem\":\"Efetuou logout do sistema\"}', '::1', '2026-10-05 08:18:03'),
(28, 1, 'LOGIN', 'login', NULL, 'Efetuou login no sistema', NULL, NULL, '::1', '2026-10-05 08:18:07'),
(29, 1, 'LOGOUT', 'login', NULL, NULL, NULL, '{\"mensagem\":\"Efetuou logout do sistema\"}', '::1', '2026-10-05 08:53:29'),
(30, 3, 'LOGIN', 'login', NULL, 'Efetuou login no sistema', NULL, NULL, '::1', '2026-10-05 08:53:31'),
(31, 3, 'LOGOUT', 'login', NULL, NULL, NULL, '{\"mensagem\":\"Efetuou logout do sistema\"}', '::1', '2026-10-05 08:53:40'),
(32, 2, 'LOGIN', 'login', NULL, 'Efetuou login no sistema', NULL, NULL, '::1', '2026-10-05 08:53:42'),
(33, 2, 'LOGOUT', 'login', NULL, NULL, NULL, '{\"mensagem\":\"Efetuou logout do sistema\"}', '::1', '2026-10-05 08:53:51'),
(34, 1, 'LOGIN', 'login', NULL, 'Efetuou login no sistema', NULL, NULL, '::1', '2026-10-05 08:53:53'),
(35, 1, 'EXCLUIR', 'mural_mensagens', NULL, NULL, NULL, '{\"mensagem\":\"Apagou um recado do mural\",\"trecho\":\"Bem-vindos ao mural da equipe! Usem aqui pra combinar visita, avisar atraso e de\"}', '::1', '2026-10-05 08:58:37'),
(36, 1, 'LOGOUT', 'login', NULL, NULL, NULL, '{\"mensagem\":\"Efetuou logout do sistema\"}', '::1', '2026-10-05 08:58:39'),
(37, 3, 'LOGIN', 'login', NULL, 'Efetuou login no sistema', NULL, NULL, '::1', '2026-10-05 08:58:41'),
(38, 3, 'LOGOUT', 'login', NULL, NULL, NULL, '{\"mensagem\":\"Efetuou logout do sistema\"}', '::1', '2026-10-05 08:58:48'),
(39, 2, 'LOGIN', 'login', NULL, 'Efetuou login no sistema', NULL, NULL, '::1', '2026-10-05 08:58:50'),
(40, 2, 'LOGOUT', 'login', NULL, NULL, NULL, '{\"mensagem\":\"Efetuou logout do sistema\"}', '::1', '2026-10-05 08:58:54'),
(41, 1, 'LOGIN', 'login', NULL, 'Efetuou login no sistema', NULL, NULL, '::1', '2026-10-05 08:58:56'),
(42, 1, 'EXCLUIR', 'mural_mensagens', NULL, NULL, NULL, '{\"mensagem\":\"Apagou um recado do mural\",\"trecho\":\"Bem-vindos ao mural da equipe! Usem aqui pra combinar visita, avisar atraso e de\"}', '::1', '2026-10-05 08:59:01'),
(43, 1, 'PUBLICAR', 'mural_mensagens', NULL, NULL, NULL, '{\"mensagem\":\"Publicou recado no mural da equipe\"}', '::1', '2026-10-05 09:00:09'),
(44, 1, 'PUBLICAR', 'mural_mensagens', NULL, NULL, NULL, '{\"mensagem\":\"Publicou recado no mural da equipe\"}', '::1', '2026-10-05 09:00:39'),
(45, 1, 'LOGOUT', 'login', NULL, NULL, NULL, '{\"mensagem\":\"Efetuou logout do sistema\"}', '::1', '2026-10-05 09:00:42'),
(46, 3, 'LOGIN', 'login', NULL, 'Efetuou login no sistema', NULL, NULL, '::1', '2026-10-05 09:00:44'),
(47, 3, 'PUBLICAR', 'mural_mensagens', NULL, NULL, NULL, '{\"mensagem\":\"Publicou recado no mural da equipe\"}', '::1', '2026-10-05 09:11:49'),
(48, 3, 'LOGOUT', 'login', NULL, NULL, NULL, '{\"mensagem\":\"Efetuou logout do sistema\"}', '::1', '2026-10-05 09:11:51'),
(49, 1, 'LOGIN', 'login', NULL, 'Efetuou login no sistema', NULL, NULL, '::1', '2026-10-05 09:11:53'),
(50, 1, 'PUBLICAR', 'mural_mensagens', NULL, NULL, NULL, '{\"mensagem\":\"Publicou recado no mural da equipe\"}', '::1', '2026-10-05 09:12:10'),
(51, 1, 'PUBLICAR', 'mural_mensagens', NULL, NULL, NULL, '{\"mensagem\":\"Publicou recado no mural da equipe\"}', '::1', '2026-10-05 09:12:17'),
(52, 1, 'PUBLICAR', 'mural_mensagens', NULL, NULL, NULL, '{\"mensagem\":\"Publicou recado no mural da equipe\"}', '::1', '2026-10-05 09:12:24'),
(53, 1, 'LOGOUT', 'login', NULL, NULL, NULL, '{\"mensagem\":\"Efetuou logout do sistema\"}', '::1', '2026-10-05 09:14:01'),
(54, 1, 'LOGIN', 'login', NULL, 'Efetuou login no sistema', NULL, NULL, '::1', '2026-10-05 09:18:16'),
(55, 1, 'LOGIN', 'login', NULL, 'Efetuou login no sistema', NULL, NULL, '::1', '2026-10-06 13:49:29'),
(56, 1, 'LOGOUT', 'login', NULL, NULL, NULL, '{\"mensagem\":\"Efetuou logout do sistema\"}', '::1', '2026-10-06 13:50:08'),
(57, 3, 'LOGIN', 'login', NULL, 'Efetuou login no sistema', NULL, NULL, '::1', '2026-10-06 13:50:12'),
(58, 3, 'EDITAR', 'usuarios', 3, 'Usuario: Caua Mauricio', NULL, '{\"mensagem\":\"Ativou verificacao em duas etapas\"}', '::1', '2026-10-06 14:04:33'),
(59, 3, 'LOGOUT', 'login', NULL, NULL, NULL, '{\"mensagem\":\"Efetuou logout do sistema\"}', '::1', '2026-10-06 14:05:38'),
(60, 1, 'LOGIN', 'login', NULL, 'Efetuou login no sistema', NULL, NULL, '::1', '2026-10-06 14:05:48'),
(61, 1, 'LOGOUT', 'login', NULL, NULL, NULL, '{\"mensagem\":\"Efetuou logout do sistema\"}', '::1', '2026-10-06 14:09:38'),
(62, 5, 'LOGIN', 'login', NULL, 'Efetuou login no sistema', NULL, NULL, '::1', '2026-10-06 14:09:57'),
(63, 5, 'EDITAR', 'usuarios', 5, 'Usuario: Murilo Studzinski', NULL, '{\"mensagem\":\"Ativou verificacao em duas etapas\"}', '::1', '2026-10-06 14:10:11'),
(64, 5, 'LOGOUT', 'login', NULL, NULL, NULL, '{\"mensagem\":\"Efetuou logout do sistema\"}', '::1', '2026-10-06 14:11:28'),
(65, 5, 'LOGIN', 'login', NULL, 'Efetuou login no sistema', NULL, NULL, '::1', '2026-10-06 14:11:35'),
(66, 5, 'EDITAR', 'usuarios', 5, 'Usuario: Murilo Studzinski', NULL, '{\"mensagem\":\"Desativou verificacao em duas etapas\"}', '::1', '2026-10-06 14:12:20'),
(67, 5, 'EDITAR', 'usuarios', 5, 'Usuario: Murilo Studzinski', NULL, '{\"mensagem\":\"Ativou verificacao em duas etapas\"}', '::1', '2026-10-06 14:12:22'),
(68, 5, 'LOGOUT', 'login', NULL, NULL, NULL, '{\"mensagem\":\"Efetuou logout do sistema\"}', '::1', '2026-10-06 14:12:27'),
(69, 5, 'LOGIN', 'login', NULL, 'Efetuou login no sistema', NULL, NULL, '::1', '2026-10-06 14:12:33'),
(70, 5, 'LOGOUT', 'login', NULL, NULL, NULL, '{\"mensagem\":\"Efetuou logout do sistema\"}', '::1', '2026-10-06 14:12:46'),
(71, 1, 'LOGIN', 'login', NULL, 'Efetuou login no sistema', NULL, NULL, '::1', '2026-10-06 14:21:10'),
(72, 1, 'EDITAR', 'usuarios', 1, 'Usuario: Chefe Colombo', NULL, '{\"mensagem\":\"Ativou verificacao em duas etapas\"}', '::1', '2026-10-06 14:21:15'),
(73, 1, 'LOGOUT', 'login', NULL, NULL, NULL, '{\"mensagem\":\"Efetuou logout do sistema\"}', '::1', '2026-10-06 14:30:18'),
(74, 1, 'LOGIN', 'login', NULL, 'Efetuou login no sistema', NULL, NULL, '::1', '2026-10-06 14:30:20'),
(75, 1, 'LOGOUT', 'login', NULL, NULL, NULL, '{\"mensagem\":\"Efetuou logout do sistema\"}', '::1', '2026-10-06 14:35:41'),
(76, 5, 'LOGIN', 'login', NULL, 'Efetuou login no sistema', NULL, NULL, '::1', '2026-10-06 14:35:49'),
(77, 5, 'LOGOUT', 'login', NULL, NULL, NULL, '{\"mensagem\":\"Efetuou logout do sistema\"}', '::1', '2026-10-06 14:43:46'),
(78, 5, 'LOGIN', 'login', NULL, 'Efetuou login com 2FA', NULL, NULL, '::1', '2026-10-06 14:52:31'),
(79, 5, 'LOGOUT', 'login', NULL, NULL, NULL, '{\"mensagem\":\"Efetuou logout do sistema\"}', '::1', '2026-10-06 14:52:41'),
(80, 5, 'LOGIN', 'login', NULL, 'Efetuou login com 2FA', NULL, NULL, '::1', '2026-10-06 14:53:05'),
(81, 5, 'LOGOUT', 'login', NULL, NULL, NULL, '{\"mensagem\":\"Efetuou logout do sistema\"}', '::1', '2026-10-06 14:53:19'),
(82, 5, 'LOGIN', 'login', NULL, 'Efetuou login no sistema', NULL, NULL, '::1', '2026-10-06 14:53:25'),
(83, 5, 'LOGOUT', 'login', NULL, NULL, NULL, '{\"mensagem\":\"Efetuou logout do sistema\"}', '::1', '2026-10-06 14:53:42'),
(84, 5, 'LOGIN', 'login', NULL, 'Efetuou login com 2FA', NULL, NULL, '::1', '2026-10-06 14:54:21'),
(85, 5, 'LOGOUT', 'login', NULL, NULL, NULL, '{\"mensagem\":\"Efetuou logout do sistema\"}', '::1', '2026-10-06 14:54:24'),
(86, 1, 'LOGIN', 'login', NULL, 'Efetuou login com 2FA', NULL, NULL, '::1', '2026-10-06 14:56:15'),
(87, 1, 'CRIAR', 'clientes', 7, 'Cliente: carlos henrique', NULL, '{\"mensagem\":\"Cadastrou novo cliente\",\"nome\":\"carlos henrique\"}', '::1', '2026-10-06 16:19:12'),
(88, 1, 'LOGOUT', 'login', NULL, NULL, NULL, '{\"mensagem\":\"Efetuou logout do sistema\"}', '::1', '2026-10-06 16:38:44'),
(91, 5, 'LOGIN', 'login', NULL, 'Efetuou login com 2FA', NULL, NULL, '::1', '2026-10-06 16:41:02'),
(92, 5, 'LOGIN', 'login', NULL, 'Efetuou login com 2FA', NULL, NULL, '::1', '2026-10-06 16:41:35'),
(93, 5, 'LOGOUT', 'login', NULL, NULL, NULL, '{\"mensagem\":\"Efetuou logout do sistema\"}', '::1', '2026-10-06 16:46:12'),
(94, 1, 'LOGIN', 'login', NULL, 'Efetuou login com 2FA', NULL, NULL, '::1', '2026-10-06 16:57:27'),
(95, 1, 'LOGOUT', 'login', NULL, NULL, NULL, '{\"mensagem\":\"Efetuou logout do sistema\"}', '::1', '2026-10-06 16:58:15'),
(96, 1, 'LOGIN', 'login', NULL, 'Efetuou login com 2FA', NULL, NULL, '::1', '2026-10-13 13:23:32'),
(97, 1, 'PUBLICAR', 'mural_mensagens', NULL, NULL, NULL, '{\"mensagem\":\"Publicou recado no mural da equipe\"}', '::1', '2026-10-13 13:31:22'),
(98, 1, 'CRIAR', 'clientes', 8, 'Cliente: João Carlos Pereira', NULL, '{\"mensagem\":\"Cadastrou novo cliente\",\"nome\":\"João Carlos Pereira\"}', '::1', '2026-10-13 14:29:58'),
(99, 1, 'CRIAR', 'clientes', 8, 'Cliente: João Carlos Pereira', NULL, '{\"mensagem\":\"Ativou acesso ao portal do cliente\",\"email\":\"4553517980@estudante.sed.sc.gov.br\"}', '::1', '2026-10-13 14:30:03'),
(100, 1, 'EDITAR', 'clientes', 8, 'Cliente: João Carlos Pereira', NULL, '{\"mensagem\":\"Reenviou o acesso ao portal do cliente\",\"email\":\"4553517980@estudante.sed.sc.gov.br\"}', '::1', '2026-10-13 15:13:10'),
(101, 1, 'EDITAR', 'clientes', 8, 'Cliente: João Carlos Pereira', NULL, '{\"mensagem\":\"Reenviou o acesso ao portal do cliente\",\"email\":\"4553517980@estudante.sed.sc.gov.br\"}', '::1', '2026-10-13 15:13:35'),
(102, 1, 'EDITAR', 'clientes', 8, 'Cliente: João Carlos Pereira', NULL, '{\"mensagem\":\"Reenviou o acesso ao portal do cliente\",\"email\":\"4553517980@estudante.sed.sc.gov.br\"}', '::1', '2026-10-13 15:14:32'),
(103, 1, 'LOGIN', 'login', NULL, 'Efetuou login com 2FA', NULL, NULL, '::1', '2026-10-13 15:23:09'),
(104, 1, 'CRIAR', 'orcamentos', 9, 'Orcamento ID 9', NULL, '{\"mensagem\":\"Criou orcamento\",\"valor_total\":142.5}', '::1', '2026-10-13 15:23:31'),
(105, 1, 'EDITAR', 'clientes', 8, 'Cliente: João Carlos Pereira', NULL, '{\"mensagem\":\"Reenviou o acesso ao portal do cliente\",\"email\":\"4553517980@estudante.sed.sc.gov.br\"}', '::1', '2026-10-13 15:23:53'),
(106, 1, 'EDITAR', 'orcamentos', 9, 'Orcamento ORC-2026-0009', NULL, '{\"mensagem\":\"Editou o orcamento\",\"valor_total\":142.5}', '::1', '2026-10-13 16:35:12'),
(107, 1, 'EDITAR', 'clientes', 8, 'Cliente: João Carlos Pereira', NULL, '{\"mensagem\":\"Reenviou o acesso ao portal do cliente\",\"email\":\"4553517980@estudante.sed.sc.gov.br\"}', '::1', '2026-10-13 16:43:13'),
(108, 1, 'LOGIN', 'login', NULL, 'Efetuou login com 2FA', NULL, NULL, '::1', '2026-10-13 16:44:33'),
(109, 1, 'EDITAR', 'clientes', 8, 'Cliente: João Carlos Pereira', NULL, '{\"mensagem\":\"Reenviou o acesso ao portal do cliente\",\"email\":\"4553517980@estudante.sed.sc.gov.br\"}', '::1', '2026-10-13 16:44:38'),
(110, 1, 'EDITAR', 'clientes', 8, 'Cliente: João Carlos Pereira', NULL, '{\"mensagem\":\"Reenviou o acesso ao portal do cliente\",\"email\":\"4553517980@estudante.sed.sc.gov.br\"}', '::1', '2026-10-13 17:01:22'),
(111, 1, 'LOGIN', 'login', NULL, 'Efetuou login com 2FA', NULL, NULL, '::1', '2026-10-19 07:57:30'),
(112, 1, 'LOGIN', 'login', NULL, 'Efetuou login com 2FA', NULL, NULL, '::1', '2026-10-20 13:41:20'),
(113, 1, 'EXCLUIR', 'mural_mensagens', NULL, NULL, NULL, '{\"mensagem\":\"Apagou um recado do mural\",\"trecho\":\"sfvsfds\"}', '::1', '2026-10-20 13:43:21'),
(114, 1, 'EXCLUIR', 'mural_mensagens', NULL, NULL, NULL, '{\"mensagem\":\"Apagou um recado do mural\",\"trecho\":\"bla\"}', '::1', '2026-10-20 13:43:23'),
(115, 1, 'EXCLUIR', 'mural_mensagens', NULL, NULL, NULL, '{\"mensagem\":\"Apagou um recado do mural\",\"trecho\":\"bla\"}', '::1', '2026-10-20 13:43:24'),
(116, 1, 'EXCLUIR', 'mural_mensagens', NULL, NULL, NULL, '{\"mensagem\":\"Apagou um recado do mural\",\"trecho\":\"bla\"}', '::1', '2026-10-20 13:43:26'),
(117, 1, 'LOGOUT', 'login', NULL, NULL, NULL, '{\"mensagem\":\"Efetuou logout do sistema\"}', '::1', '2026-10-20 13:44:56'),
(118, 0, 'LOGOUT', 'login', NULL, NULL, NULL, '{\"mensagem\":\"Efetuou logout do sistema\"}', '::1', '2026-10-20 13:47:57'),
(119, 3, 'LOGIN', 'login', NULL, 'Efetuou login com 2FA', NULL, NULL, '::1', '2026-10-20 13:48:52'),
(120, 3, 'LOGOUT', 'login', NULL, NULL, NULL, '{\"mensagem\":\"Efetuou logout do sistema\"}', '::1', '2026-10-20 13:49:12'),
(121, 1, 'LOGIN', 'login', NULL, 'Efetuou login com 2FA', NULL, NULL, '::1', '2026-10-20 13:49:29'),
(122, 1, 'LOGOUT', 'login', NULL, NULL, NULL, '{\"mensagem\":\"Efetuou logout do sistema\"}', '::1', '2026-10-20 13:50:06'),
(123, 2, 'LOGIN', 'login', NULL, 'Efetuou login no sistema', NULL, NULL, '::1', '2026-10-20 13:50:13'),
(124, 2, 'LOGOUT', 'login', NULL, NULL, NULL, '{\"mensagem\":\"Efetuou logout do sistema\"}', '::1', '2026-10-20 13:50:49'),
(125, 1, 'LOGIN', 'login', NULL, 'Efetuou login com 2FA', NULL, NULL, '::1', '2026-10-20 13:51:06'),
(126, 1, 'EXPORTAR', 'orcamentos', NULL, NULL, NULL, '{\"mensagem\":\"Exportou a lista de orcamentos em CSV\",\"total\":4}', '::1', '2026-10-20 14:20:39'),
(127, 1, 'EDITAR', 'clientes', 8, 'Cliente: João Carlos Pereira', NULL, '{\"mensagem\":\"Reenviou o acesso ao portal do cliente\",\"email\":\"4553517980@estudante.sed.sc.gov.br\"}', '::1', '2026-10-20 14:25:35'),
(128, 1, 'PUBLICAR', 'mural_mensagens', NULL, NULL, NULL, '{\"mensagem\":\"Publicou recado no mural da equipe\"}', '::1', '2026-10-20 14:40:31'),
(129, 1, 'PUBLICAR', 'mural_mensagens', NULL, NULL, NULL, '{\"mensagem\":\"Publicou recado no mural da equipe\"}', '::1', '2026-10-20 14:40:35'),
(130, 1, 'PUBLICAR', 'mural_mensagens', NULL, NULL, NULL, '{\"mensagem\":\"Publicou recado no mural da equipe\"}', '::1', '2026-10-20 14:40:40'),
(131, 1, 'PUBLICAR', 'mural_mensagens', NULL, NULL, NULL, '{\"mensagem\":\"Publicou recado no mural da equipe\"}', '::1', '2026-10-20 14:40:42'),
(132, 1, 'PUBLICAR', 'mural_mensagens', NULL, NULL, NULL, '{\"mensagem\":\"Publicou recado no mural da equipe\"}', '::1', '2026-10-20 14:40:44'),
(133, 1, 'PUBLICAR', 'mural_mensagens', NULL, NULL, NULL, '{\"mensagem\":\"Publicou recado no mural da equipe\"}', '::1', '2026-10-20 14:40:45'),
(134, 1, 'PUBLICAR', 'mural_mensagens', NULL, NULL, NULL, '{\"mensagem\":\"Publicou recado no mural da equipe\"}', '::1', '2026-10-20 14:40:46'),
(135, 1, 'PUBLICAR', 'mural_mensagens', NULL, NULL, NULL, '{\"mensagem\":\"Publicou recado no mural da equipe\"}', '::1', '2026-10-20 14:40:48'),
(136, 1, 'PUBLICAR', 'mural_mensagens', NULL, NULL, NULL, '{\"mensagem\":\"Publicou recado no mural da equipe\"}', '::1', '2026-10-20 14:40:50'),
(137, 1, 'EXCLUIR', 'mural_mensagens', NULL, NULL, NULL, '{\"mensagem\":\"Apagou um recado do mural\",\"trecho\":\"teste\"}', '::1', '2026-10-20 14:41:55'),
(138, 1, 'EXCLUIR', 'mural_mensagens', NULL, NULL, NULL, '{\"mensagem\":\"Apagou um recado do mural\",\"trecho\":\"teste\"}', '::1', '2026-10-20 14:41:56'),
(139, 1, 'EXCLUIR', 'mural_mensagens', NULL, NULL, NULL, '{\"mensagem\":\"Apagou um recado do mural\",\"trecho\":\"teste\"}', '::1', '2026-10-20 14:41:58'),
(140, 1, 'CRIAR', 'orcamentos', 12, 'Orcamento ID 12', NULL, '{\"mensagem\":\"Criou orcamento\",\"valor_total\":0}', '::1', '2026-10-20 16:45:29'),
(141, 1, 'EDITAR', 'orcamentos', 12, 'Orcamento ORC-2026-0010', NULL, '{\"mensagem\":\"Editou o orcamento\",\"valor_total\":0.95}', '::1', '2026-10-20 16:45:43');

-- --------------------------------------------------------

--
-- Estrutura para tabela `medidas`
--

CREATE TABLE `medidas` (
  `id` int(11) NOT NULL,
  `orcamento_id` int(11) NOT NULL,
  `tipo` varchar(50) NOT NULL,
  `valor` decimal(10,2) NOT NULL,
  `unidade` varchar(10) NOT NULL DEFAULT 'm',
  `observacao` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `medidas`
--

INSERT INTO `medidas` (`id`, `orcamento_id`, `tipo`, `valor`, `unidade`, `observacao`) VALUES
(26, 6, 'Comprimento Calha Frontal', 5.00, 'm', 'Medição efetuada no local'),
(27, 6, 'Altura Condutor', 3.00, 'm', 'Lado esquerdo do imóvel'),
(40, 8, 'Calha Lateral', 3.50, 'm', 'Lado esquerdo do imóvel'),
(41, 8, 'Calha frontal', 8.50, 'm', 'Face voltada para a rua'),
(42, 8, 'altura do condutor', 3.00, 'm', NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `mural_mensagens`
--

CREATE TABLE `mural_mensagens` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `mensagem` text NOT NULL,
  `fixada` tinyint(1) NOT NULL DEFAULT 0,
  `data_postagem` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `mural_mensagens`
--

INSERT INTO `mural_mensagens` (`id`, `usuario_id`, `mensagem`, `fixada`, `data_postagem`) VALUES
(3, 1, 'fala tropa, amanha é na casa da Matilde na rua das flores', 0, '2026-10-05 09:00:09'),
(4, 1, 'Pedro tbm não esquece, de comprar bobina animal', 0, '2026-10-05 09:00:39'),
(5, 3, 'tabom to indo la pae', 0, '2026-10-05 09:11:49'),
(10, 1, 'teste', 0, '2026-10-20 14:40:31'),
(11, 1, 'teste', 0, '2026-10-20 14:40:35'),
(12, 1, 'teste', 0, '2026-10-20 14:40:40'),
(13, 1, 'teste', 0, '2026-10-20 14:40:42'),
(14, 1, 'teste', 0, '2026-10-20 14:40:44'),
(15, 1, 'teste', 0, '2026-10-20 14:40:45');

-- --------------------------------------------------------

--
-- Estrutura para tabela `orcamentos`
--

CREATE TABLE `orcamentos` (
  `id` int(11) NOT NULL,
  `numero` varchar(20) NOT NULL,
  `token` char(32) NOT NULL,
  `cliente_id` int(11) NOT NULL,
  `responsavel_id` int(11) NOT NULL,
  `data_orcamento` datetime NOT NULL DEFAULT current_timestamp(),
  `data_entrega_prevista` date DEFAULT NULL,
  `validade_dias` int(11) NOT NULL DEFAULT 15,
  `status` enum('rascunho','enviado','aprovado','em_producao','concluido','cancelado') NOT NULL DEFAULT 'rascunho',
  `tipo_telhado` varchar(50) DEFAULT NULL,
  `corte_chapa` varchar(30) DEFAULT NULL,
  `condicao_acesso` varchar(50) DEFAULT NULL,
  `acabamento_cor` varchar(50) DEFAULT NULL,
  `inclui_rufos` tinyint(1) NOT NULL DEFAULT 0,
  `inclui_condutores` tinyint(1) NOT NULL DEFAULT 0,
  `inclui_veda_calha` tinyint(1) NOT NULL DEFAULT 0,
  `inclui_cabeceiras` tinyint(1) NOT NULL DEFAULT 0,
  `valor_materiais` decimal(10,2) NOT NULL DEFAULT 0.00,
  `valor_mao_obra` decimal(10,2) NOT NULL DEFAULT 0.00,
  `percentual_desconto` decimal(5,2) NOT NULL DEFAULT 0.00,
  `valor_desconto` decimal(10,2) NOT NULL DEFAULT 0.00,
  `valor_total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `custo_estimado` decimal(10,2) NOT NULL DEFAULT 0.00,
  `forma_pagamento` varchar(40) DEFAULT NULL,
  `observacoes` text DEFAULT NULL,
  `visualizacoes` int(11) NOT NULL DEFAULT 0,
  `data_visualizacao` datetime DEFAULT NULL,
  `data_resposta` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `orcamentos`
--

INSERT INTO `orcamentos` (`id`, `numero`, `token`, `cliente_id`, `responsavel_id`, `data_orcamento`, `data_entrega_prevista`, `validade_dias`, `status`, `tipo_telhado`, `corte_chapa`, `condicao_acesso`, `acabamento_cor`, `inclui_rufos`, `inclui_condutores`, `inclui_veda_calha`, `inclui_cabeceiras`, `valor_materiais`, `valor_mao_obra`, `percentual_desconto`, `valor_desconto`, `valor_total`, `custo_estimado`, `forma_pagamento`, `observacoes`, `visualizacoes`, `data_visualizacao`, `data_resposta`) VALUES
(6, 'ORC-2026-0006', 'b464b86aa55c0750b5fb02aaf64717be', 4, 1, '2026-09-21 08:06:19', NULL, 15, 'aprovado', 'Telha Ceramica', '33cm', 'Escada Simples', 'Branco', 1, 1, 1, 1, 280.00, 150.00, 5.00, 21.50, 408.50, 0.00, 'Pix', 'Instalação agendada para o período da manhã', 0, NULL, NULL),
(7, 'ORC-2026-0007', '5fc64ac79c363a17eb3a87cc258706ed', 5, 3, '2026-09-21 09:18:51', '2026-10-21', 15, 'em_producao', NULL, NULL, 'Escada Simples', 'Natural', 1, 1, 1, 0, 0.00, 150.00, 5.00, 7.50, 142.50, 0.00, 'Pix', NULL, 0, NULL, NULL),
(8, 'ORC-2026-0008', '0f4c873522766a0a727e1c0675096485', 4, 4, '2026-09-29 15:14:59', '2026-10-29', 15, 'rascunho', 'Telha Ceramica', '33cm', 'Escada Simples', 'Branco', 1, 1, 1, 0, 777.80, 350.00, 5.00, 56.39, 1071.41, 0.00, 'Pix', 'Entrada de 50% na aprovação e saldo na conclusão do serviço.', 0, NULL, NULL),
(9, 'ORC-2026-0009', 'b06ea3d183456890017b94e20b53d5be', 8, 1, '2026-10-13 15:23:31', '2026-11-12', 15, 'em_producao', NULL, NULL, 'Escada Simples', 'Natural', 1, 1, 1, 0, 0.00, 150.00, 5.00, 7.50, 142.50, 0.00, 'Pix', NULL, 0, NULL, '2026-10-13 16:29:41'),
(12, 'ORC-2026-0010', 'd3a964508c3c79806c4d9d770ecafc1d', 7, 1, '2026-10-20 16:45:29', '2026-11-19', 15, 'rascunho', NULL, NULL, 'Escada Simples', 'Natural', 1, 1, 1, 0, 0.00, 1.00, 5.00, 0.05, 0.95, 0.00, 'Pix', NULL, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `password_resets`
--

CREATE TABLE `password_resets` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `token` char(64) NOT NULL,
  `expira_em` datetime NOT NULL,
  `usado` tinyint(1) NOT NULL DEFAULT 0,
  `ip_solicitante` varchar(45) DEFAULT NULL,
  `data_criacao` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `password_resets`
--

INSERT INTO `password_resets` (`id`, `usuario_id`, `token`, `expira_em`, `usado`, `ip_solicitante`, `data_criacao`) VALUES
(1, 5, 'a80cc536f47bc851adba913804f71958e585ae4fbdb055b19b89be672f3ab481', '2026-10-06 17:08:59', 1, '::1', '2026-10-06 16:38:59');

-- --------------------------------------------------------

--
-- Estrutura para tabela `produtos`
--

CREATE TABLE `produtos` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `categoria` varchar(50) DEFAULT 'Geral',
  `unidade` enum('metro','kg','un','peca','rolo') NOT NULL DEFAULT 'un',
  `preco_custo` decimal(10,2) NOT NULL DEFAULT 0.00,
  `preco_unitario` decimal(10,2) NOT NULL DEFAULT 0.00,
  `estoque_atual` decimal(10,2) NOT NULL DEFAULT 0.00,
  `estoque_minimo` decimal(10,2) NOT NULL DEFAULT 0.00,
  `ativo` tinyint(1) NOT NULL DEFAULT 1,
  `data_cadastro` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `produtos`
--

INSERT INTO `produtos` (`id`, `nome`, `categoria`, `unidade`, `preco_custo`, `preco_unitario`, `estoque_atual`, `estoque_minimo`, `ativo`, `data_cadastro`) VALUES
(1, 'Calha de Aluminio 0,5mm', 'Calhas', 'metro', 25.00, 42.00, 40.00, 50.00, 1, '2026-09-16 20:05:27'),
(2, 'Parafuso de Fixacao', 'Fixacao', 'un', 0.15, 0.50, 480.00, 100.00, 1, '2026-09-16 20:05:27'),
(3, 'Veda Calha (Tubo)', 'Vedacao', 'un', 8.00, 18.90, 21.00, 20.00, 1, '2026-09-16 20:05:27'),
(4, 'Suporte para Calha', 'Fixacao', 'peca', 6.50, 12.50, 90.00, 30.00, 1, '2026-09-16 20:05:27'),
(5, 'Pingadeira', 'Acabamento', 'un', 3.00, 8.00, 55.00, 15.00, 1, '2026-09-16 20:05:27'),
(7, 'Rufo Galvanizado', 'Acabamento', 'metro', 18.00, 32.00, 60.00, 25.00, 1, '2026-09-16 20:05:27'),
(8, 'Condutor Retangular', 'Condutores', 'metro', 20.00, 38.00, 45.00, 20.00, 1, '2026-09-16 20:05:27'),
(9, 'Calha Galvanizada 0,43mm', 'Calhas', 'metro', 18.50, 32.00, 85.00, 30.00, 1, '2026-09-21 08:06:19'),
(10, 'Bocal de Escoamento 100mm', 'Acabamento', 'un', 5.20, 12.00, 40.00, 10.00, 1, '2026-09-21 08:06:19');

-- --------------------------------------------------------

--
-- Estrutura para tabela `two_factor_tokens`
--

CREATE TABLE `two_factor_tokens` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `codigo` varchar(6) NOT NULL,
  `expira_em` datetime NOT NULL,
  `usado` tinyint(1) NOT NULL DEFAULT 0,
  `data_criacao` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `two_factor_tokens`
--

INSERT INTO `two_factor_tokens` (`id`, `usuario_id`, `codigo`, `expira_em`, `usado`, `data_criacao`) VALUES
(8, 5, '855256', '2026-10-06 16:51:18', 1, '2026-10-06 16:41:18'),
(19, 3, '352174', '2026-10-20 13:55:00', 0, '2026-10-20 13:45:00'),
(20, 3, '888626', '2026-10-20 13:58:35', 1, '2026-10-20 13:48:35'),
(22, 1, '342820', '2026-10-20 14:00:51', 1, '2026-10-20 13:50:51'),
(23, 1, '520214', '2026-10-20 14:00:56', 0, '2026-10-20 13:50:56');

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `perfil` enum('admin','gerente','calheiro','campo') NOT NULL DEFAULT 'campo',
  `telefone` varchar(20) DEFAULT NULL,
  `ativo` tinyint(1) NOT NULL DEFAULT 1,
  `two_factor_ativo` tinyint(1) NOT NULL DEFAULT 0,
  `two_factor_ativo_em` datetime DEFAULT NULL,
  `ultimo_acesso` datetime DEFAULT NULL,
  `data_cadastro` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `nome`, `email`, `senha`, `perfil`, `telefone`, `ativo`, `two_factor_ativo`, `two_factor_ativo_em`, `ultimo_acesso`, `data_cadastro`) VALUES
(1, 'Chefe Colombo', '4553517980@estudante.sed.sc.gov.br', '$2y$10$ReBGIYAYWK4cUWfg0UXOOO6jXLq0VrAyjEvuU6MKXP1gM6bxFg1.2', 'admin', '48000000000', 1, 1, NULL, '2026-10-20 13:51:06', '2026-07-20 09:00:00'),
(2, 'Gerente Vendas', 'gerente@colombo.com', '$2y$10$vPY2c9PGe.DDpD8xoCPjT.Lq07A3LREYZZqCVOG5BKUB5ouhkRoHS', 'gerente', '48988888888', 1, 0, NULL, '2026-10-20 13:50:13', '2026-07-20 09:10:00'),
(3, 'Caua Mauricio', '4553683783@estudante.sed.sc.gov.br', '$2y$10$ekQ8kbMqPdKhdQcEmV8H8e0XpUL1kzYpaAKRp91viURaBf21LIKdG', 'campo', '48999999999', 1, 1, NULL, '2026-10-20 13:48:52', '2026-07-26 00:21:07'),
(4, 'Pedro Renato', 'pedro@colombo.com', '$2a$10$VIRleujJb7GdErd0Fyskn.Dse40kSHfYpnQ2IF4grt92uSUDIbDD.', 'calheiro', '48676999888', 1, 0, NULL, NULL, '2026-08-19 21:54:42'),
(5, 'Murilo Studzinski', 'prgiassi00@gmail.com', '$2y$10$AixWvarhxr8k7VDGR6988u9hR9w5weEN7NgMxDmx4ELdw8p6Tgddq', 'calheiro', '(48) 98824-0332', 1, 1, NULL, '2026-10-06 16:41:35', '2026-10-06 14:07:31');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_nome` (`nome`),
  ADD KEY `idx_cpf_cnpj` (`cpf_cnpj`),
  ADD KEY `idx_cidade` (`cidade`);

--
-- Índices de tabela `clientes_logs`
--
ALTER TABLE `clientes_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_cliente` (`cliente_id`),
  ADD KEY `idx_data` (`data_hora`);

--
-- Índices de tabela `compras_insumos`
--
ALTER TABLE `compras_insumos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_data` (`data_compra`),
  ADD KEY `idx_produto` (`produto_id`),
  ADD KEY `idx_fornecedor` (`fornecedor_id`);

--
-- Índices de tabela `fornecedores`
--
ALTER TABLE `fornecedores`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_nome` (`nome`);

--
-- Índices de tabela `itens_orcamento`
--
ALTER TABLE `itens_orcamento`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_orcamento` (`orcamento_id`),
  ADD KEY `idx_produto` (`produto_id`);

--
-- Índices de tabela `logs_sistema`
--
ALTER TABLE `logs_sistema`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `medidas`
--
ALTER TABLE `medidas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_orcamento` (`orcamento_id`);

--
-- Índices de tabela `mural_mensagens`
--
ALTER TABLE `mural_mensagens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_data` (`data_postagem`),
  ADD KEY `idx_fixada` (`fixada`),
  ADD KEY `fk_mural_usuario` (`usuario_id`);

--
-- Índices de tabela `orcamentos`
--
ALTER TABLE `orcamentos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_numero` (`numero`),
  ADD UNIQUE KEY `uk_token` (`token`),
  ADD KEY `idx_cliente` (`cliente_id`),
  ADD KEY `idx_responsavel` (`responsavel_id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_data` (`data_orcamento`);

--
-- Índices de tabela `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_token` (`token`),
  ADD KEY `idx_usuario` (`usuario_id`),
  ADD KEY `idx_expira` (`expira_em`);

--
-- Índices de tabela `produtos`
--
ALTER TABLE `produtos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_ativo` (`ativo`),
  ADD KEY `idx_categoria` (`categoria`);

--
-- Índices de tabela `two_factor_tokens`
--
ALTER TABLE `two_factor_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_usuario` (`usuario_id`),
  ADD KEY `idx_codigo` (`codigo`);

--
-- Índices de tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_email` (`email`),
  ADD KEY `idx_perfil` (`perfil`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de tabela `clientes_logs`
--
ALTER TABLE `clientes_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de tabela `compras_insumos`
--
ALTER TABLE `compras_insumos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `fornecedores`
--
ALTER TABLE `fornecedores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `itens_orcamento`
--
ALTER TABLE `itens_orcamento`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT de tabela `logs_sistema`
--
ALTER TABLE `logs_sistema`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=142;

--
-- AUTO_INCREMENT de tabela `medidas`
--
ALTER TABLE `medidas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT de tabela `mural_mensagens`
--
ALTER TABLE `mural_mensagens`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT de tabela `orcamentos`
--
ALTER TABLE `orcamentos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de tabela `password_resets`
--
ALTER TABLE `password_resets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `produtos`
--
ALTER TABLE `produtos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de tabela `two_factor_tokens`
--
ALTER TABLE `two_factor_tokens`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `clientes_logs`
--
ALTER TABLE `clientes_logs`
  ADD CONSTRAINT `fk_cliente_log` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `compras_insumos`
--
ALTER TABLE `compras_insumos`
  ADD CONSTRAINT `fk_compra_fornecedor` FOREIGN KEY (`fornecedor_id`) REFERENCES `fornecedores` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_compra_produto` FOREIGN KEY (`produto_id`) REFERENCES `produtos` (`id`) ON DELETE SET NULL;

--
-- Restrições para tabelas `itens_orcamento`
--
ALTER TABLE `itens_orcamento`
  ADD CONSTRAINT `fk_item_orcamento` FOREIGN KEY (`orcamento_id`) REFERENCES `orcamentos` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_item_produto` FOREIGN KEY (`produto_id`) REFERENCES `produtos` (`id`);

--
-- Restrições para tabelas `medidas`
--
ALTER TABLE `medidas`
  ADD CONSTRAINT `fk_medida_orcamento` FOREIGN KEY (`orcamento_id`) REFERENCES `orcamentos` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `mural_mensagens`
--
ALTER TABLE `mural_mensagens`
  ADD CONSTRAINT `fk_mural_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `orcamentos`
--
ALTER TABLE `orcamentos`
  ADD CONSTRAINT `fk_orc_cliente` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`),
  ADD CONSTRAINT `fk_orc_responsavel` FOREIGN KEY (`responsavel_id`) REFERENCES `usuarios` (`id`);

--
-- Restrições para tabelas `password_resets`
--
ALTER TABLE `password_resets`
  ADD CONSTRAINT `fk_reset_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `two_factor_tokens`
--
ALTER TABLE `two_factor_tokens`
  ADD CONSTRAINT `fk_2fa_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
